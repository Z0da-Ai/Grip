package com.grip.app.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import com.grip.app.ui.theme.GripTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.grip.app.HomeScreen
import com.grip.app.ui.screens.SplashScreen
import com.grip.app.util.GripAlarmScheduler
import com.grip.app.util.GripPermission
import com.grip.app.util.PermissionSteps

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDark = isSystemInDarkTheme()
            GripTheme(darkTheme = isDark) {
                // rememberSaveable: do not replay the splash when Android recreates the activity
                // (rotation, theme change, or coming back from a system settings screen).
                var showSplash by rememberSaveable { mutableStateOf(true) }
                if (showSplash) {
                    SplashScreen(onAnimationEnd = { showSplash = false })
                } else {
                    Column(Modifier.fillMaxSize().statusBarsPadding()) {
                        PermissionsCard()
                        Box(Modifier.weight(1f)) { HomeScreen() }
                    }
                }
            }
        }
    }
}

private const val PERMISSION_PREFS = "grip_permissions"
private const val KEY_NOTIF_REQUESTED = "notif_requested"

private fun skipKey(p: GripPermission) = "skipped_${p.name}"

private tailrec fun Context.findActivity(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun isGranted(context: Context, p: GripPermission): Boolean = when (p) {
    // areNotificationsEnabled() is false both when POST_NOTIFICATIONS is denied (Android 13+)
    // and when the user switched notifications off for Grip in system settings.
    GripPermission.NOTIFICATIONS -> NotificationManagerCompat.from(context).areNotificationsEnabled()
    GripPermission.EXACT_ALARMS -> GripAlarmScheduler.canScheduleExact(context)
    GripPermission.OVERLAY -> Settings.canDrawOverlays(context)
    GripPermission.DND ->
        context.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true
}

private fun grantedSet(context: Context): Set<GripPermission> =
    GripPermission.values().filter { isGranted(context, it) }.toSet()

private fun readSkipped(context: Context): Set<GripPermission> {
    val prefs = context.getSharedPreferences(PERMISSION_PREFS, Context.MODE_PRIVATE)
    return GripPermission.values().filter { prefs.getBoolean(skipKey(it), false) }.toSet()
}

/**
 * Opens a system settings screen. Some phone makers do not ship every settings screen, which used to
 * crash the app with ActivityNotFoundException; fall back to Grip's app-details page, then to a message.
 */
private fun openSettings(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            )
        } catch (_: Exception) {
            Toast.makeText(
                context,
                "افتح إعدادات الهاتف ثم التطبيقات ثم Grip وفعّل الإذن يدويًا",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

private fun shortName(p: GripPermission): String = when (p) {
    GripPermission.NOTIFICATIONS -> "الإشعارات"
    GripPermission.EXACT_ALARMS -> "المنبهات الدقيقة"
    GripPermission.OVERLAY -> "الظهور فوق التطبيقات"
    GripPermission.DND -> "عدم الإزعاج"
}

private fun reasonFor(p: GripPermission): String = when (p) {
    GripPermission.NOTIFICATIONS -> "الإشعارات: لتنبيهك بموعد المهام."
    GripPermission.EXACT_ALARMS -> "المنبهات الدقيقة: لتبدأ المهمة في ثانيتها بالضبط."
    GripPermission.OVERLAY -> "الظهور فوق التطبيقات: لعرض شاشة التذكير عند موعد المهمة."
    GripPermission.DND ->
        "عدم الإزعاج (اختياري): يسمح لـ Grip بتفعيل Do Not Disturb تلقائيًا أثناء جلسة التركيز، " +
            "ثم يحاول إعادة وضع الهاتف السابق عند انتهائها."
}

private fun allowLabel(p: GripPermission): String = when (p) {
    GripPermission.NOTIFICATIONS -> "السماح بالإشعارات"
    GripPermission.EXACT_ALARMS -> "السماح بالمنبهات الدقيقة"
    GripPermission.OVERLAY -> "تفعيل شاشة التذكير"
    GripPermission.DND -> "السماح بوضع عدم الإزعاج"
}

/** What the user loses by skipping a core permission (shown before the skip is accepted). */
private fun consequenceOfSkipping(p: GripPermission): String = when (p) {
    GripPermission.NOTIFICATIONS ->
        "لن يظهر لك إشعار التذكير بموعد المهام."
    GripPermission.EXACT_ALARMS ->
        "سيستخدم Grip منبهات تقريبية، فقد تبدأ المهمة متأخرة عن موعدها بدقائق."
    GripPermission.OVERLAY ->
        "لن تظهر شاشة التذكير فوق التطبيقات عند موعد المهمة، وهي الميزة الأساسية في Grip. " +
            "ستبقى المهام والجدول متاحة داخل التطبيق."
    GripPermission.DND ->
        "لن يفعّل Grip وضع عدم الإزعاج أثناء جلسات التركيز."
}

/**
 * Asks for the special permissions Grip needs, one step at a time, each with a plain-language reason
 * (Google Play requires a clear in-app disclosure before sending people to the overlay setting).
 *
 * Nothing can trap the user here: every step has a skip button. Skipping a core permission needs an
 * explicit confirmation that states what will stop working, and a slim reminder with an "enable"
 * button stays visible afterwards. The card is height-capped and scrollable so it can never push the
 * home screen out of view on small phones or with large font sizes.
 */
@Composable
private fun PermissionsCard() {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences(PERMISSION_PREFS, Context.MODE_PRIVATE) }
    var granted by remember { mutableStateOf(grantedSet(context)) }
    var skipped by remember { mutableStateOf(readSkipped(context)) }
    var showOverlayDisclosure by remember { mutableStateOf(false) }
    var confirmSkip by remember { mutableStateOf<GripPermission?>(null) }
    var notifNeedsSettings by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = grantedSet(context)
    }

    // Re-check every permission when the user comes back from a system settings screen
    // (notifications used to be missing from this check, so the card could never disappear).
    val activity = remember(context) { context.findActivity() }
    DisposableEffect(activity) {
        val lifecycle = activity?.lifecycle
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = grantedSet(context)
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    fun skip(p: GripPermission) {
        prefs.edit().putBoolean(skipKey(p), true).apply()
        skipped = skipped + p
    }

    fun askAgainForCore() {
        val editor = prefs.edit()
        GripPermission.values().filter { it.isCore }.forEach { editor.remove(skipKey(it)) }
        editor.apply()
        skipped = skipped.filterNot { it.isCore }.toSet()
    }

    fun request(p: GripPermission) {
        when (p) {
            GripPermission.NOTIFICATIONS -> {
                // After two denials Android stops showing the system dialog, so the button used to do
                // nothing. In that case (or when notifications are switched off) go to system settings.
                val askedBefore = prefs.getBoolean(KEY_NOTIF_REQUESTED, false)
                val canShowDialog = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    (!askedBefore ||
                        activity?.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) == true)
                if (canShowDialog) {
                    prefs.edit().putBoolean(KEY_NOTIF_REQUESTED, true).apply()
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    notifNeedsSettings = true
                    openSettings(
                        context,
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    )
                }
            }
            GripPermission.EXACT_ALARMS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    openSettings(
                        context,
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                    )
                }
            }
            GripPermission.OVERLAY -> showOverlayDisclosure = true
            GripPermission.DND -> openSettings(context, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    val current = PermissionSteps.pending(granted, skipped).firstOrNull()
    val showBanner = PermissionSteps.needsBanner(granted, skipped)
    val maxCardHeight = (LocalConfiguration.current.screenHeightDp * 0.5f).dp

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (current != null) {
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column(
                    Modifier
                        .heightIn(max = maxCardHeight)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "خطوات التفعيل — ${current.ordinal + 1} من ${GripPermission.values().size}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(reasonFor(current))
                    if (current == GripPermission.NOTIFICATIONS && notifNeedsSettings) {
                        Text(
                            "تم رفض الإذن سابقًا، لذلك يفتح Grip إعدادات الإشعارات لتفعيله يدويًا. " +
                                "ارجع للتطبيق بعد التفعيل.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(onClick = { request(current) }) { Text(allowLabel(current)) }
                        TextButton(onClick = {
                            if (current.isCore) confirmSkip = current else skip(current)
                        }) { Text(if (current.isCore) "تخطي هذه الخطوة" else "ليس الآن") }
                    }
                }
            }
        } else if (showBanner) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(
                    Modifier.padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "صلاحيات أساسية غير مفعّلة: " +
                            PermissionSteps.missingCore(granted).joinToString("، ") { shortName(it) },
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { askAgainForCore() }) { Text("تفعيل") }
                }
            }
        }

        confirmSkip?.let { permission ->
            AlertDialog(
                onDismissRequest = { confirmSkip = null },
                title = { Text("تخطي «${shortName(permission)}»؟") },
                text = {
                    Text(
                        consequenceOfSkipping(permission) +
                            "\n\nيمكنك تفعيلها لاحقًا من الشريط الظاهر أعلى الشاشة أو من إعدادات الهاتف."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        skip(permission)
                        confirmSkip = null
                    }) { Text("تخطي رغم ذلك") }
                },
                dismissButton = { TextButton(onClick = { confirmSkip = null }) { Text("رجوع") } }
            )
        }

        if (showOverlayDisclosure) {
            AlertDialog(
                onDismissRequest = { showOverlayDisclosure = false },
                title = { Text("إذن الظهور فوق التطبيقات") },
                text = {
                    Text(
                        "Grip يعرض شاشة تذكير كاملة فوق التطبيقات الأخرى عند بدء مهمة مجدولة، " +
                            "لمساعدتك على البدء بدل التسويف. لا يقرأ التطبيق ما تفعله في تطبيقات أخرى ولا يجمع " +
                            "أي بيانات من خلال هذا الإذن. يمكنك سحب الإذن من إعدادات الهاتف متى شئت."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showOverlayDisclosure = false
                        openSettings(
                            context,
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                        )
                    }) { Text("موافق، افتح الإعدادات") }
                },
                dismissButton = { TextButton(onClick = { showOverlayDisclosure = false }) { Text("لاحقاً") } }
            )
        }
    }
}
