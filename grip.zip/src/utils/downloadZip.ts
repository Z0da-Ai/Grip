/**
 * Helper to reliably download the project zip file across iframes,
 * mobile browsers, and desktop environments.
 */
export async function downloadProjectZip(onProgress?: (status: string) => void): Promise<boolean> {
  if (onProgress) onProgress('جاري بدء التحميل...');
  
  // Try blob download first (most reliable within iframes)
  try {
    const endpoints = ['/grip-complete-project.zip', '/api/download-project-zip'];
    let response: Response | null = null;
    
    for (const url of endpoints) {
      try {
        const res = await fetch(url);
        if (res.ok) {
          response = res;
          break;
        }
      } catch (_) {
        // try next
      }
    }

    if (response && response.ok) {
      if (onProgress) onProgress('جاري حفظ الملف (560KB)...');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'grip-complete-project.zip';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 15000);
      if (onProgress) onProgress('تم التحميل بنجاح!');
      return true;
    }
  } catch (err) {
    console.warn('Blob fetch failed, falling back to direct navigation:', err);
  }

  // Fallback: direct window location
  try {
    window.open('/api/download-project-zip', '_blank');
    if (onProgress) onProgress('تم فتح رابط التحميل المباشر');
    return true;
  } catch (_) {
    window.location.href = '/api/download-project-zip';
    return true;
  }
}
