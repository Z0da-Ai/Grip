# Add project specific ProGuard rules here.
-keep class com.grip.app.data.local.entity.** { *; }
-keep class com.grip.app.budget.** { *; }
-dontwarn com.google.gson.**
