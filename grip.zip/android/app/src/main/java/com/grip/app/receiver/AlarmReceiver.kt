package com.grip.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.grip.app.data.local.AppDatabase
import com.grip.app.service.EnforcementOverlayService
import com.grip.app.util.GripAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Exact Alarm Receiver
 * Fires at exact task start time to display the full screen overlay.
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(EnforcementOverlayService.EXTRA_TASK_ID)
        if (taskId != null) {
            EnforcementOverlayService.startEnforcement(context, taskId)
        }
    }
}

/**
 * Boot Receiver
 * Survives device reboots by querying Room database and rescheduling all alarms.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getInstance(context)
                val currentTime = System.currentTimeMillis()
                val tasks = db.taskDao().getTasksForDay(currentTime, currentTime + 7 * 86400000L)

                for (task in tasks) {
                    if (task.startTimeEpochMs > currentTime && task.status == com.grip.app.data.local.entity.TaskStatus.PENDING) {
                        GripAlarmScheduler.scheduleExactTaskAlarm(context, task)
                    }
                }
            }
        }
    }
}
