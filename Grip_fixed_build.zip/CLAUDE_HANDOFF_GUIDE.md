# Grip — Developer & Claude Handoff Guide (UI LOCKED)

> **CRITICAL RULE #1 — DO NOT ALTER, REDESIGN, OR REPLACE THE UI**
>
> The user has explicitly approved the current web UI in `src/` (compiled into `android/app/src/main/assets/dist/`).
> - **DO NOT** switch `MainActivity.kt` to `GripHomeScreen.kt` or rewrite the UI in Jetpack Compose.
> - **DO NOT** change the color palette, bottom navigation tab colors, typography (`Cairo` + `Plus Jakarta Sans`), icons (`lucide-react`), official logo (`/icon.svg` on `#2A2D34`), or remove any of the 5 core tabs.
> - **DO NOT** add emojis anywhere in the app — Lucide SVG icons are used exclusively.
> - **DO NOT** re-introduce developer/demo buttons (`تحميل ZIP`, `Android` header pill, fake Google account picker, `محاكاة مكالمة`, `إغلاق المعاينة`, or hardcoded emails/keys).

---

## 1. Architecture Overview

Grip is an **Offline-First Arabic RTL behavioral-therapy (CBT) & ADHD focus enforcement Android app** using a hybrid architecture:

1. **Locked Production UI Layer (`src/` → `android/app/src/main/assets/dist/`)**:
   - Built with **React 19 + TypeScript + Tailwind CSS v4 + Vite**.
   - Embedded inside `MainActivity.kt` via `WebViewAssetLoader` mounted at root `"/"` → `assets/dist/`, loading `https://appassets.androidplatform.net/index.html`.
   - **Important**: Always keep `distPathHandler` mapped to `"/"` in `MainActivity.kt` so Vite absolute asset paths (`/assets/*.js`, `/assets/*.css`, `/icon.svg`, `/grip-onboarding.html`) resolve cleanly offline.

2. **5 Core Color-Coded Navigation Tabs (Always Visible)**:
   - **التقويم (Calendar)** — Blue (`blue-600`)
   - **الدراسة (Study Hierarchy)** — Purple (`#6D28D9`)
   - **العادات (Trackers & Habits)** — Orange (`orange-500`)
   - **الميزانية (Budget & Expenses)** — Green (`emerald-600`)
   - **النوايا (Intentions & Brain Dump)** — Yellow/Amber (`amber-500`)

3. **CBT / Behavioral Enforcement Mechanics Already Implemented in UI**:
   - **Escalating Friction Hold Ring** (`EnforcementOverlay.tsx`): Continuous press required to postpone (Strictness Presets in Settings: `مرن` 5/10/15s + 5m, `متوازن` 10/20/30s + 4m, `صارم` 15/25/30s + 3m). Lifting finger early resets progress to 0 with haptic warning.
   - **5-Minute Micro-Start Rule** (`EnforcementOverlay.tsx`): One-tap CBT initiation-paralysis breaker ("ابدأ بـ 5 دقائق فقط") with live countdown inside the enforcement screen.
   - **Compassionate CBT Reframe**: After 3+ postpones on the same task, shifts copy from pushy to empathetic guidance to prevent shame spirals.
   - **Grace Shield (Streak Protection)** (`streakService.ts` + `StreakModal.tsx`): 1 automatic grace day protects the user's streak from collapsing to 0 after a single difficult day.
   - **One-Shot Wake-Up Alarm** (`WakeUpAlarmModal.tsx`): Zero-snooze morning wake-up requiring a 5-second continuous hold, transitioning into `MorningFocusModal`.
   - **Discrete Emergency Exit**: 60-second continuous hold tucked behind a subtle top-corner lock icon.

---

## 2. JS ↔ Android Native Bridge Contract (`window.AndroidBridge`)

Defined in `src/services/nativeBridge.ts` and exposed in `android/app/src/main/java/com/grip/app/ui/MainActivity.kt`:

| Bridge Method | Parameters | Purpose |
|---|---|---|
| `isNativeAndroid()` | none | Returns `true` inside Android APK |
| `hasOverlayPermission()` | none | Checks `Settings.canDrawOverlays(context)` |
| `requestOverlayPermission()` | none | Opens Android "Display over other apps" settings screen |
| `triggerHaptic(type)` | `String` | Triggers native `VibrationEffect` |
| `scheduleTaskAlarm(taskId, taskTitle, startEpochMs, isWakeUpAlarm)` | `String, String, Long, Boolean` | Schedules exact `AlarmManager` alarm (`setExactAndAllowWhileIdle`) targeting `AlarmReceiver` |
| `cancelTaskAlarm(taskId)` | `String` | Cancels scheduled `PendingIntent` |
| `startEnforcementOverlay(taskId, taskTitle, durationMinutes)` | `String, String, Int` | Starts `EnforcementOverlayService` foreground service over all apps |

---

## 3. What Claude / Android Specialist Should Complete (Backend & Native Android ONLY)

Keep the UI untouched and focus strictly on these native Android & release tasks:

1. **Verify & Harden `EnforcementOverlayService.kt`**:
   - Ensure `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` displays reliably over other apps on Android 10–15 (API 29–35).
   - Match the exact light/lavender styling (`#F8F9FA`, `#E9E3FB`, `#6D28D9`, official logo) and the 10s→20s→30s hold ring + 5-minute micro-start behavior when triggered outside the app.
   - Respect `READ_PHONE_STATE` to automatically pause/hide the overlay during active incoming or outgoing phone calls.

2. **Exact Alarms & Reboot Persistence (`AlarmReceiver.kt` + `BootReceiver.kt`)**:
   - Persist scheduled task alarms from `scheduleTaskAlarm(...)` into Room / SharedPreferences so `BootReceiver` re-schedules all future alarms after device reboot.
   - Handle Android 12+ (`SCHEDULE_EXACT_ALARM` / `canScheduleExactAlarms()`) permission gracefully with fallback to `setAndAllowWhileIdle` if denied.

3. **First-Run Native Android Permission Flow**:
   - Prompt the user cleanly (only inside native Android) for:
     - `POST_NOTIFICATIONS` (Android 13+)
     - `SYSTEM_ALERT_WINDOW` (Display over other apps)
     - `SCHEDULE_EXACT_ALARM`
     - `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`
     - `RECORD_AUDIO` (on-demand when user taps the Voice Assistant microphone)

4. **Build & Release Pipeline (`.github/workflows/build-android.yml`)**:
   - Already configured to build web assets (`npm ci && npm run build`), copy `dist/*` to `android/app/src/main/assets/dist/`, and run `./gradlew assembleDebug bundleRelease`.
   - For Google Play release: add release keystore signing config via GitHub Actions secrets (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) in `android/app/build.gradle.kts`.
   - Note: `server.ts` Gemini AI endpoints (`/api/ai/*`) require setting `GEMINI_API_KEY` on a hosted backend URL if online AI parsing is desired inside the standalone APK; otherwise local offline parsing already works automatically.

---

## 4. Quick Build Commands

```bash
# 1. Build locked web UI and copy into Android assets
npm install
npm run build
rm -rf android/app/src/main/assets/dist
mkdir -p android/app/src/main/assets/dist
cp -r dist/* android/app/src/main/assets/dist/

# 2. Build Android Debug APK
cd android
./gradlew assembleDebug
```
