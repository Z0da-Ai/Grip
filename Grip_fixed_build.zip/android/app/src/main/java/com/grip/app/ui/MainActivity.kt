package com.grip.app.ui

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import com.grip.app.receiver.AlarmReceiver
import com.grip.app.service.EnforcementOverlayService
import java.net.URLConnection

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        // Serve the complete built Vite dist/ directly from root "/" so all
        // absolute paths (/assets/*, /icon.svg, /grip-onboarding.html) resolve cleanly offline.
        val distPathHandler = WebViewAssetLoader.PathHandler { path ->
            val cleanPath = path.trimStart('/').ifEmpty { "index.html" }
            val assetPath = "dist/$cleanPath"
            try {
                val inputStream = assets.open(assetPath)
                val mimeType = when {
                    cleanPath.endsWith(".html") -> "text/html"
                    cleanPath.endsWith(".js") || cleanPath.endsWith(".mjs") -> "application/javascript"
                    cleanPath.endsWith(".css") -> "text/css"
                    cleanPath.endsWith(".svg") -> "image/svg+xml"
                    cleanPath.endsWith(".png") -> "image/png"
                    cleanPath.endsWith(".jpg") || cleanPath.endsWith(".jpeg") -> "image/jpeg"
                    cleanPath.endsWith(".webp") -> "image/webp"
                    cleanPath.endsWith(".json") || cleanPath.endsWith(".webmanifest") -> "application/json"
                    cleanPath.endsWith(".woff2") -> "font/woff2"
                    cleanPath.endsWith(".woff") -> "font/woff"
                    else -> URLConnection.guessContentTypeFromName(cleanPath) ?: "application/octet-stream"
                }
                WebResourceResponse(mimeType, "UTF-8", inputStream)
            } catch (_: Exception) {
                null
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/", distPathHandler)
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                if (url.startsWith("https://appassets.androidplatform.net") ||
                    url.startsWith("file://")
                ) {
                    return false
                }
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                } catch (_: Exception) {}
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    request.grant(request.resources)
                }
            }
        }

        // Add Android Native Bridge
        webView.addJavascriptInterface(GripNativeBridge(this), "AndroidBridge")

        // Support Android hardware back button
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Load the embedded full Grip Application from root
        webView.loadUrl("https://appassets.androidplatform.net/index.html")
    }

    inner class GripNativeBridge(private val context: Context) {
        @JavascriptInterface
        fun isNativeAndroid(): Boolean = true

        @JavascriptInterface
        fun hasOverlayPermission(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
        }

        @JavascriptInterface
        fun requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(intent)
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun triggerHaptic(type: String) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    val vibrator = vibratorManager.defaultVibrator
                    vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
                } else {
                    @Suppress("DEPRECATION")
                    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(40)
                    }
                }
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun scheduleTaskAlarm(taskId: String, taskTitle: String, startEpochMs: Long, isWakeUpAlarm: Boolean) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    action = "com.grip.app.ACTION_TRIGGER_TASK"
                    putExtra(EnforcementOverlayService.EXTRA_TASK_ID, taskId)
                    putExtra("TASK_TITLE", taskTitle)
                    putExtra("IS_WAKE_UP_ALARM", isWakeUpAlarm)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    taskId.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, startEpochMs, pendingIntent)
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, startEpochMs, pendingIntent)
                }
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun cancelTaskAlarm(taskId: String) {
            try {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    action = "com.grip.app.ACTION_TRIGGER_TASK"
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    taskId.hashCode(),
                    intent,
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pendingIntent != null) {
                    alarmManager.cancel(pendingIntent)
                }
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun startEnforcementOverlay(taskId: String, taskTitle: String, durationMinutes: Int) {
            try {
                val intent = Intent(context, EnforcementOverlayService::class.java).apply {
                    putExtra(EnforcementOverlayService.EXTRA_TASK_ID, taskId)
                    putExtra("TASK_ID", taskId)
                    putExtra("TASK_TITLE", taskTitle)
                    putExtra("DURATION_MINUTES", durationMinutes)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {}
        }
    }
}
