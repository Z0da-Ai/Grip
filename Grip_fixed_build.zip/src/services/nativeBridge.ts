import { GripTask } from '../types/grip';

interface AndroidBridgeApi {
  isNativeAndroid?: () => boolean;
  hasOverlayPermission?: () => boolean;
  requestOverlayPermission?: () => void;
  triggerHaptic?: (type: string) => void;
  startEnforcementOverlay?: (taskId: string, taskTitle: string, durationMinutes: number) => void;
  scheduleTaskAlarm?: (taskId: string, taskTitle: string, startEpochMs: number, isWakeUpAlarm: boolean) => void;
  cancelTaskAlarm?: (taskId: string) => void;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeApi;
  }
}

function getBridge(): AndroidBridgeApi | null {
  if (typeof window === 'undefined') return null;
  return window.AndroidBridge ?? null;
}

export const nativeBridge = {
  isNativeAndroid(): boolean {
    try {
      return Boolean(getBridge()?.isNativeAndroid?.());
    } catch {
      return false;
    }
  },

  hasOverlayPermission(): boolean {
    try {
      return Boolean(getBridge()?.hasOverlayPermission?.());
    } catch {
      return false;
    }
  },

  requestOverlayPermission(): void {
    try {
      getBridge()?.requestOverlayPermission?.();
    } catch {
      // no-op on web
    }
  },

  scheduleTaskAlarm(task: GripTask): void {
    try {
      const bridge = getBridge();
      if (!bridge?.scheduleTaskAlarm) return;
      const startMs = new Date(task.startTime).getTime();
      if (Number.isNaN(startMs) || startMs <= Date.now()) return;
      bridge.scheduleTaskAlarm(
        task.id,
        task.title,
        startMs,
        Boolean(task.isWakeUpAlarm || task.category === 'wake_up')
      );
    } catch {
      // no-op on web
    }
  },

  cancelTaskAlarm(taskId: string): void {
    try {
      getBridge()?.cancelTaskAlarm?.(taskId);
    } catch {
      // no-op on web
    }
  },

  startEnforcementOverlay(task: GripTask): void {
    try {
      const bridge = getBridge();
      if (!bridge?.startEnforcementOverlay) return;
      const startMs = new Date(task.startTime).getTime();
      const endMs = new Date(task.endTime).getTime();
      const durationMinutes = Math.max(15, Math.round((endMs - startMs) / 60000) || 30);
      bridge.startEnforcementOverlay(task.id, task.title, durationMinutes);
    } catch {
      // no-op on web
    }
  },
};
