import React, { useState } from 'react';
import { GripSettings, GripUser } from '../types/grip';
import { storage } from '../services/storage';
import {
  Settings as SettingsIcon,
  Download,
  Upload,
  Moon,
  Sun,
  X,
  Languages,
  CalendarDays,
  User as UserIcon,
  LogOut,
  HelpCircle,
  AlarmClockOff,
  ChevronDown,
  ChevronUp,
  Sliders,
  Shield,
} from 'lucide-react';
import { getHijriDateString } from '../utils/hijriCalendar';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GripSettings;
  onUpdateSettings: (settings: GripSettings) => void;
  onDataImported: () => void;
  currentUser?: GripUser | null;
  onOpenAuth?: (step?: 'walkthrough' | 'auth') => void;
  onLogout?: () => void;
  onReplaySplash?: () => void;
  onOpenAndroidInstall?: () => void;
}

type StrictnessPresetId = 'flexible' | 'balanced' | 'strict';

const STRICTNESS_PRESETS: Array<{
  id: StrictnessPresetId;
  label: string;
  summary: string;
  baseHoldSeconds: number;
  midHoldSeconds: number;
  maxHoldSeconds: number;
  freeWindowMinutes: number;
}> = [
  {
    id: 'flexible',
    label: 'مرن',
    summary: '5ث / 10ث / 15ث • نافذة 5د',
    baseHoldSeconds: 5,
    midHoldSeconds: 10,
    maxHoldSeconds: 15,
    freeWindowMinutes: 5,
  },
  {
    id: 'balanced',
    label: 'متوازن',
    summary: '10ث / 20ث / 30ث • نافذة 4د',
    baseHoldSeconds: 10,
    midHoldSeconds: 20,
    maxHoldSeconds: 30,
    freeWindowMinutes: 4,
  },
  {
    id: 'strict',
    label: 'صارم',
    summary: '15ث / 25ث / 30ث • نافذة 3د',
    baseHoldSeconds: 15,
    midHoldSeconds: 25,
    maxHoldSeconds: 30,
    freeWindowMinutes: 3,
  },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onDataImported,
  currentUser,
  onOpenAuth,
  onLogout,
}) => {
  if (!isOpen) return null;

  const [current, setCurrent] = useState<GripSettings>({ ...settings });
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [showAdvancedFriction, setShowAdvancedFriction] = useState(false);

  const activePresetId: StrictnessPresetId | null =
    STRICTNESS_PRESETS.find(
      (p) =>
        p.baseHoldSeconds === current.baseHoldSeconds &&
        p.midHoldSeconds === current.midHoldSeconds &&
        p.maxHoldSeconds === current.maxHoldSeconds &&
        p.freeWindowMinutes === current.freeWindowMinutes
    )?.id ?? null;

  const handleSelectPreset = (preset: (typeof STRICTNESS_PRESETS)[number]) => {
    setCurrent({
      ...current,
      baseHoldSeconds: preset.baseHoldSeconds,
      midHoldSeconds: preset.midHoldSeconds,
      maxHoldSeconds: preset.maxHoldSeconds,
      freeWindowMinutes: preset.freeWindowMinutes,
    });
  };

  // Export JSON backup
  const handleExportBackup = () => {
    const jsonStr = storage.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `grip-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import JSON backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const success = storage.importFullBackup(text);
        if (success) {
          setImportStatus('تم استعادة النسخة الاحتياطية بنجاح!');
          onDataImported();
          setTimeout(() => setImportStatus(null), 3000);
        } else {
          setImportStatus('خطأ: تعذر قراءة ملف النسخة الاحتياطية.');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleSave = () => {
    onUpdateSettings(current);
    storage.saveSettings(current);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md" dir="rtl">
      <div
        className={`w-full max-w-lg rounded-3xl border p-6 transition-all shadow-2xl relative ${
          current.isDarkMode ? 'bg-[#111827] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition cursor-pointer"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-[#6D28D9] flex items-center justify-center shrink-0">
            <SettingsIcon className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black">إعدادات Grip</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              صرامة الإلزام، الأقسام، منبه الصحوة، والمظهر.
            </p>
          </div>
        </div>

        <div className="space-y-4 max-h-[62vh] overflow-y-auto pr-1">
          {/* Local Profile Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#6D28D9] to-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
                  {currentUser?.name ? currentUser.name.charAt(0).toUpperCase() : <UserIcon className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black text-slate-900 dark:text-white truncate">
                      {currentUser?.name || 'مستخدم Grip'}
                    </span>
                    <span className="text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md">
                      ملف محلي
                    </span>
                  </div>
                  {currentUser?.email && currentUser.email !== 'guest@grip.app' && (
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-mono truncate" dir="ltr">
                      {currentUser.email}
                    </span>
                  )}
                </div>
              </div>

              {currentUser && onLogout && (
                <button
                  type="button"
                  onClick={() => {
                    onLogout();
                    onClose();
                  }}
                  className="p-2 rounded-xl hover:bg-rose-100 dark:hover:bg-rose-950/60 text-slate-400 hover:text-rose-600 transition cursor-pointer shrink-0"
                  title="إعادة تعيين الملف المحلي"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              )}
            </div>

            {onOpenAuth && (
              <div className="flex gap-2 pt-2.5 border-t border-slate-200/80 dark:border-slate-700/60">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAuth('auth');
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-purple-100 dark:bg-purple-900/50 text-[#6D28D9] dark:text-purple-300 text-xs font-bold hover:bg-purple-200 dark:hover:bg-purple-900/70 transition cursor-pointer text-center"
                >
                  تعديل الملف الشخصي
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAuth('walkthrough');
                  }}
                  className="py-2 px-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-600 transition cursor-pointer flex items-center gap-1.5"
                  title="إعادة عرض الجولة التعريفية"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>الجولة التعريفية</span>
                </button>
              </div>
            )}
          </div>

          {/* Enforcement Strictness Presets + Collapsible Advanced Controls */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#6D28D9] dark:text-purple-400" />
              <div>
                <span className="text-xs font-black block">مستوى صرامة الإلزام</span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  اختر مستوى الاحتكاك المناسب للتأجيل والنافذة الحرة
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {STRICTNESS_PRESETS.map((preset) => {
                const isSelected = activePresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                      isSelected
                        ? 'bg-[#6D28D9] text-white border-[#6D28D9] shadow-sm'
                        : 'bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-purple-300'
                    }`}
                  >
                    <span className="text-xs font-black block">{preset.label}</span>
                    <span
                      className={`text-[10px] block mt-0.5 tabular-nums ${
                        isSelected ? 'text-purple-100' : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {preset.baseHoldSeconds}/{preset.midHoldSeconds}/{preset.maxHoldSeconds}ث • {preset.freeWindowMinutes}د
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setShowAdvancedFriction((prev) => !prev)}
              className="w-full pt-2 border-t border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400 hover:text-[#6D28D9] dark:hover:text-purple-300 transition cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" />
                <span>إعدادات متقدمة للإلزام</span>
              </span>
              {showAdvancedFriction ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showAdvancedFriction && (
              <div className="space-y-3 pt-1">
                <div className="p-3 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold">مدة النافذة الحرة بعد التأجيل</span>
                    <span className="text-xs font-black text-[#6D28D9] dark:text-purple-400 tabular-nums">
                      {current.freeWindowMinutes} دقائق
                    </span>
                  </div>
                  <input
                    type="range"
                    min={3}
                    max={5}
                    step={1}
                    value={current.freeWindowMinutes}
                    onChange={(e) => setCurrent({ ...current, freeWindowMinutes: parseInt(e.target.value, 10) })}
                    className="w-full accent-[#6D28D9] cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 font-bold mt-1">
                    <span>3 دقائق</span>
                    <span>4 دقائق</span>
                    <span>5 دقائق</span>
                  </div>
                </div>

                <label className="p-3 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-bold block">مخرج الطوارئ المخفي (60 ثانية)</span>
                    <p className="text-[10px] text-slate-400">
                      إتاحة أيقونة القفل للضغط المستمر لدقيقة كاملة في حالات الطوارئ
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={current.allowEmergencyExit !== false}
                    onChange={(e) => setCurrent({ ...current, allowEmergencyExit: e.target.checked })}
                    className="w-5 h-5 accent-[#6D28D9] cursor-pointer shrink-0"
                  />
                </label>
              </div>
            )}
          </div>

          {/* One-Shot Wake-Up Alarm */}
          <div className="p-4 rounded-2xl bg-amber-500/10 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-700/60 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
                  <Sun className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-black text-slate-900 dark:text-white">
                      منبه الصحوة الحاسم
                    </span>
                    <span className="text-[10px] bg-amber-500/20 text-amber-800 dark:text-amber-300 font-bold px-1.5 py-0.5 rounded inline-flex items-center gap-1">
                      <AlarmClockOff className="w-3 h-3" />
                      <span>بدون غفوة</span>
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    يرن مرة واحدة صباحاً ويتطلب ضغطاً مستمراً لمدة 5 ثوانٍ لإيقافه
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={current.wakeUpEnabled !== false}
                onChange={(e) => setCurrent({ ...current, wakeUpEnabled: e.target.checked })}
                className="w-5 h-5 accent-amber-500 cursor-pointer shrink-0 mr-2"
              />
            </div>

            {current.wakeUpEnabled !== false && (
              <div className="flex items-center justify-between pt-2 border-t border-amber-200/50 dark:border-amber-900/40">
                <span className="text-xs font-bold text-amber-900 dark:text-amber-200">
                  ميعاد الاستيقاظ اليومي:
                </span>
                <input
                  type="time"
                  value={current.wakeUpTime || '06:30'}
                  onChange={(e) => setCurrent({ ...current, wakeUpTime: e.target.value })}
                  className="px-3 py-1 rounded-xl bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 text-xs font-black text-amber-900 dark:text-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            )}
          </div>

          {/* Language & FAB Position */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Languages className="w-4 h-4 text-[#6D28D9] dark:text-purple-400 shrink-0" />
              <div>
                <span className="text-xs font-black block">اللغة واتجاه الواجهة</span>
                <span className="text-[10px] text-slate-400">
                  {current.language === 'en' ? 'English (LTR)' : 'العربية (RTL)'}
                </span>
              </div>
            </div>
            <div className="flex items-center bg-slate-200 dark:bg-slate-700 p-0.5 rounded-xl shrink-0">
              <button
                type="button"
                onClick={() => setCurrent({ ...current, language: 'ar' })}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  current.language !== 'en'
                    ? 'bg-[#6D28D9] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                العربية
              </button>
              <button
                type="button"
                onClick={() => setCurrent({ ...current, language: 'en' })}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  current.language === 'en'
                    ? 'bg-[#6D28D9] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Hijri Calendar */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <CalendarDays className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-black block">التقويم الهجري</span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {current.showHijriCalendar !== false
                    ? `اليوم: ${getHijriDateString(new Date())}`
                    : 'إظهار التاريخ الهجري بجانب الميلادي'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setCurrent({ ...current, showHijriCalendar: current.showHijriCalendar === false })}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                current.showHijriCalendar !== false
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {current.showHijriCalendar !== false ? 'مفعل' : 'معطل'}
            </button>
          </div>

          {/* Dark Mode */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {current.isDarkMode ? <Moon className="w-4 h-4 text-purple-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
              <span className="text-xs font-black">الوضع الليلي</span>
            </div>
            <button
              type="button"
              onClick={() => setCurrent({ ...current, isDarkMode: !current.isDarkMode })}
              className="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold transition cursor-pointer"
            >
              {current.isDarkMode ? 'مفعل' : 'الوضع الفاتح'}
            </button>
          </div>

          {/* Local Backup and Export/Import */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="text-xs font-black block mb-1">النسخ الاحتياطي المحلي</span>
            <p className="text-[11px] text-slate-400 mb-3">
              بياناتك محفوظة على جهازك بالكامل. يمكنك تصدير نسخة احتياطية بصيغة JSON أو استعادتها:
            </p>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleExportBackup}
                className="flex-1 py-2.5 rounded-xl bg-[#6D28D9] text-white text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-[#7C3AED] transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير نسخة</span>
              </button>

              <label className="flex-1 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-slate-300 dark:hover:bg-slate-600 transition cursor-pointer text-center">
                <Upload className="w-3.5 h-3.5" />
                <span>استيراد نسخة</span>
                <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
              </label>
            </div>

            {importStatus && (
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold mt-2 text-center">
                {importStatus}
              </p>
            )}
          </div>
        </div>

        {/* Footer save */}
        <div className="mt-5 flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold cursor-pointer"
          >
            إلغاء
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-2.5 rounded-xl bg-[#6D28D9] hover:bg-[#7C3AED] text-white text-xs font-bold shadow-md cursor-pointer"
          >
            حفظ التغييرات
          </button>
        </div>
      </div>
    </div>
  );
};
