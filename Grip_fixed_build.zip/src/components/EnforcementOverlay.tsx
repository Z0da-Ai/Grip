import React, { useState, useEffect, useRef } from 'react';
import { GripTask, GripSettings } from '../types/grip';
import { hapticFeedback } from '../services/haptics';
import { Check, Lock, AlertTriangle, Timer } from 'lucide-react';

interface EnforcementOverlayProps {
  task: GripTask;
  settings: GripSettings;
  onPostponeSuccess: (task: GripTask, freeWindowMinutes: number) => void;
  onDoneEarly: (task: GripTask) => void;
  onEmergencyExit: (task: GripTask) => void;
  onClosePreview?: () => void;
  isSimulatedInApp?: boolean;
}

export const EnforcementOverlay: React.FC<EnforcementOverlayProps> = ({
  task,
  settings,
  onPostponeSuccess,
  onDoneEarly,
  onEmergencyExit,
  onClosePreview,
}) => {
  // Escalating friction calculation: 1st 3-4: 10s, next 3-4: 20s, max 30s
  const calculateRequiredSeconds = (count: number): number => {
    if (count < 3) return settings.baseHoldSeconds || 10;
    if (count < 6) return settings.midHoldSeconds || 20;
    return settings.maxHoldSeconds || 30;
  };

  const calculateNextHoldSeconds = (count: number): number => {
    return calculateRequiredSeconds(count + 1);
  };

  const currentHoldRequired = calculateRequiredSeconds(task.postponeCount);
  const nextHoldSeconds = calculateNextHoldSeconds(task.postponeCount);

  // Holding state for "فكرني بعدين"
  const [holdingProgress, setHoldingProgress] = useState(0); // 0 to 100
  const [heldSeconds, setHeldSeconds] = useState(0);
  const [isHolding, setIsHolding] = useState(false);

  // Holding state for "خلّصت بدري" (exactly 2 seconds hold)
  const [isDoneEarlyHolding, setIsDoneEarlyHolding] = useState(false);
  const [doneEarlyProgress, setDoneEarlyProgress] = useState(0); // 0 to 100

  // Hidden Emergency Exit (60 seconds hold)
  const [isEmergencyHolding, setIsEmergencyHolding] = useState(false);
  const [emergencyProgress, setEmergencyProgress] = useState(0);
  const [emergencySeconds, setEmergencySeconds] = useState(0);
  const emergencyIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // CBT 5-Minute Micro-Start Mode (breaks initiation paralysis without guilt)
  const [microStartSecondsLeft, setMicroStartSecondsLeft] = useState<number | null>(null);

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const doneEarlyIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
      if (doneEarlyIntervalRef.current) clearInterval(doneEarlyIntervalRef.current);
      if (emergencyIntervalRef.current) clearInterval(emergencyIntervalRef.current);
      if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    };
  }, []);

  // CBT 5-minute countdown effect
  useEffect(() => {
    if (microStartSecondsLeft === null) return;
    if (microStartSecondsLeft <= 0) {
      hapticFeedback.heavy();
      setToastMessage('كسرت حاجز البداية! استمر في التركيز أو اضغط تم بدري عند الانتهاء.');
      const t = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(t);
    }
    const interval = setInterval(() => {
      setMicroStartSecondsLeft((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [microStartSecondsLeft]);

  const formatMicroTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const isHeavyResistance = task.postponeCount >= 3;

  // Trigger vibration helper
  const triggerWarningVibration = () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([150, 80, 150]);
      } catch {
        // ignore
      }
    }
  };

  // START "فكرني بعدين" Hold
  const startHold = () => {
    setIsHolding(true);
    const startTime = Date.now();
    const durationMs = currentHoldRequired * 1000;

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / durationMs) * 100);
      const secs = (elapsed / 1000).toFixed(1);

      setHoldingProgress(progress);
      setHeldSeconds(parseFloat(secs));

        if (elapsed >= durationMs) {
          if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
          setIsHolding(false);
          setHoldingProgress(100);
          hapticFeedback.heavy();

          // Show dark toast before triggering callback
          const freeMins = settings.freeWindowMinutes || 4;
          setToastMessage(`تمام، تم منح نافذة حرة لمدة ${freeMins} دقائق`);
          toastTimeoutRef.current = setTimeout(() => {
            onPostponeSuccess(task, freeMins);
          }, 1100);
        }
    }, 35);
  };

  // CANCEL "فكرني بعدين" Hold with Penalty (Reset to 0 + Vibration)
  const cancelHold = () => {
    if (!isHolding) return;
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
    // Punishment: vibration & reset
    triggerWarningVibration();
    setIsHolding(false);
    setHoldingProgress(0);
    setHeldSeconds(0);
    setToastMessage('رفعت إصبعك مبكراً! أعيد العداد للصفر');
    setTimeout(() => setToastMessage(null), 2000);
  };

  // Hidden Emergency Exit Hold (60 seconds)
  const startEmergencyHold = () => {
    setIsEmergencyHolding(true);
    const startTime = Date.now();
    const durationMs = (settings.emergencyExitSeconds || 60) * 1000;

    emergencyIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / durationMs) * 100);
      const secs = Math.floor(elapsed / 1000);

      setEmergencyProgress(progress);
      setEmergencySeconds(secs);

      if (elapsed >= durationMs) {
        if (emergencyIntervalRef.current) clearInterval(emergencyIntervalRef.current);
        setIsEmergencyHolding(false);
        setEmergencyProgress(100);
        setToastMessage('تم خروج الطوارئ الاستثنائي بنجاح');
        setTimeout(() => {
          onEmergencyExit(task);
        }, 800);
      }
    }, 100);
  };

  const cancelEmergencyHold = () => {
    if (!isEmergencyHolding) return;
    if (emergencyIntervalRef.current) {
      clearInterval(emergencyIntervalRef.current);
      emergencyIntervalRef.current = null;
    }
    triggerWarningVibration();
    setIsEmergencyHolding(false);
    setEmergencyProgress(0);
    setEmergencySeconds(0);
  };

  // START "خلّصت بدري" Hold (2 seconds = 2000 ms)
  const startDoneEarlyHold = () => {
    setIsDoneEarlyHolding(true);
    const startTime = Date.now();
    const durationMs = 2000; // 2 seconds

    doneEarlyIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / durationMs) * 100);
      setDoneEarlyProgress(progress);

      if (elapsed >= durationMs) {
        if (doneEarlyIntervalRef.current) clearInterval(doneEarlyIntervalRef.current);
        setIsDoneEarlyHolding(false);
        setDoneEarlyProgress(100);

        // Show dark toast before triggering callback
        setToastMessage('أحسنت! تم إنجاز المهمة بنجاح.');
        toastTimeoutRef.current = setTimeout(() => {
          onDoneEarly(task);
        }, 1200);
      }
    }, 35);
  };

  // CANCEL "خلّصت بدري" Hold
  const cancelDoneEarlyHold = () => {
    if (!isDoneEarlyHolding) return;
    if (doneEarlyIntervalRef.current) {
      clearInterval(doneEarlyIntervalRef.current);
      doneEarlyIntervalRef.current = null;
    }
    setIsDoneEarlyHolding(false);
    setDoneEarlyProgress(0);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#F8F9FA] text-[#1F2433] select-none p-3 sm:p-5"
      dir="rtl"
    >
      {/* Phone container: max-w-[420px], all inside ONE screen, no scrolling */}
      <div className="w-full max-w-[420px] h-full max-h-[920px] flex flex-col justify-between items-center py-2 sm:py-3">
        {/* 1. Header: Official Grip Logo + Discrete Emergency Exit Icon */}
        <div className="w-full flex items-center justify-between gap-2.5 pt-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-[12px] overflow-hidden bg-[#2A2D34] border border-slate-700/20 shadow-xs flex items-center justify-center shrink-0">
              <img
                src="/icon.svg"
                alt="Grip Logo"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/favicon.png';
                }}
              />
            </div>
            <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-xl text-[#1F2433] tracking-wide">
              Grip
            </span>
          </div>

          {settings.allowEmergencyExit !== false && (
            <button
              type="button"
              onMouseDown={startEmergencyHold}
              onMouseUp={cancelEmergencyHold}
              onMouseLeave={cancelEmergencyHold}
              onTouchStart={startEmergencyHold}
              onTouchEnd={cancelEmergencyHold}
              onTouchCancel={cancelEmergencyHold}
              className={`relative min-h-[36px] rounded-xl text-[11px] font-bold transition overflow-hidden border select-none cursor-pointer flex items-center justify-center ${
                isEmergencyHolding
                  ? 'px-3 text-rose-700 border-rose-300 bg-rose-50'
                  : 'w-9 h-9 text-slate-400 hover:text-slate-600 border-slate-200/80 bg-white/80'
              }`}
              style={{ touchAction: 'none' }}
              title="خروج الطوارئ الاستثنائي (اضغط مطولاً 60 ثانية)"
              aria-label="خروج الطوارئ"
            >
              <div
                className="absolute inset-y-0 right-0 bg-rose-200/80 transition-all pointer-events-none"
                style={{ width: `${emergencyProgress}%` }}
              />
              <span className="relative z-10 flex items-center gap-1 tabular-nums">
                {isEmergencyHolding ? (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                    <span>{emergencySeconds}/{settings.emergencyExitSeconds || 60}ث</span>
                  </>
                ) : (
                  <Lock className="w-3.5 h-3.5" />
                )}
              </span>
            </button>
          )}
        </div>

        {/* 2. Small pill: Lavender bg, purple text, 13px */}
        <div className="px-3.5 py-1 rounded-full bg-[#E9E3FB] text-[#6D28D9] text-[13px] font-bold">
          جلسة التركيز الحالية
        </div>

        {/* 3. Task title: 23px bold, dark text */}
        <h2 className="text-[23px] font-black text-[#1F2433] text-center leading-snug px-3 line-clamp-2">
          {task.title}
        </h2>

        {/* 4. Main message card: Lavender bg (#E9E3FB), radius 20, padding 16 */}
        <div className="w-full p-4 rounded-[20px] bg-[#E9E3FB] text-center">
          <h3 className="text-[22px] font-black text-[#6D28D9] leading-tight">
            {microStartSecondsLeft !== null
              ? microStartSecondsLeft > 0
                ? 'أنت الآن في أول 5 دقائق'
                : 'ممتاز! كسرت حاجز البداية'
              : isHeavyResistance
              ? 'المهمة تقيلة النهارده؟'
              : 'يلا خلّصها'}
          </h3>
          <p className="text-[13px] text-purple-700 font-bold mt-0.5">
            {microStartSecondsLeft !== null
              ? 'ركّز على أصغر خطوة فقط — بدون أي ضغط للكمال'
              : isHeavyResistance
              ? 'ده طبيعي جداً — مش مطلوب تخلّص كل حاجة مرة واحدة'
              : 'امسك تركيزك.. واقطع السرحان'}
          </p>
          <p className="text-[12px] text-[#6B7280] font-medium mt-1 leading-normal">
            {microStartSecondsLeft !== null
              ? 'البداية هي أصعب جزء. بمجرد مرور 5 دقائق، عقلك بيكمل بسهولة.'
              : isHeavyResistance
              ? 'جرّب قاعدة الـ 5 دقائق بالأسفل واكسر التردد بخطوة واحدة صغيرة.'
              : 'مفيش زر بدء لأنك في وقتها بالفعل. ابدأ دلوقتي واهزم التسويف.'}
          </p>
        </div>

        {/* 5. Two stat boxes side by side, radius 14 */}
        <div className="w-full grid grid-cols-2 gap-3">
          {/* Peach Box: big number (postpone count) + label "مرات التأجيل للمهمة" */}
          <div className="p-3 rounded-[14px] bg-[#FDE8DC] text-center flex flex-col items-center justify-center">
            <span className="text-[22px] font-black text-[#B4531F] leading-tight">
              {task.postponeCount}
            </span>
            <span className="text-[11px] font-semibold text-[#B4531F] mt-0.5">
              مرات التأجيل للمهمة
            </span>
          </div>

          {/* White Box with 1px lavender border: big purple number + label "الضغطة القادمة" */}
          <div className="p-3 rounded-[14px] bg-white border border-[#E9E3FB] text-center flex flex-col items-center justify-center shadow-xs">
            <span className="text-[22px] font-black text-[#6D28D9] leading-tight">
              {nextHoldSeconds} ث
            </span>
            <span className="text-[11px] font-semibold text-[#6B7280] mt-0.5">
              الضغطة القادمة
            </span>
          </div>
        </div>

        {/* 6. Hold ring: 150px circle, track lavender #E9E3FB, filled progress purple #7C3AED */}
        <div className="flex flex-col items-center justify-center my-1">
          <div
            onMouseDown={startHold}
            onMouseUp={cancelHold}
            onMouseLeave={cancelHold}
            onTouchStart={startHold}
            onTouchEnd={cancelHold}
            onTouchCancel={cancelHold}
            style={{
              background: `conic-gradient(#7C3AED ${holdingProgress * 3.6}deg, #E9E3FB 0deg)`,
              touchAction: 'none',
            }}
            className="w-[145px] h-[145px] rounded-full flex items-center justify-center cursor-pointer select-none transition-transform duration-150 active:scale-95 shadow-md"
          >
            {/* Inside white circle with soft purple shadow */}
            <div className="w-[122px] h-[122px] rounded-full bg-white shadow-[0_4px_16px_rgba(109,40,217,0.12)] flex flex-col items-center justify-center text-center px-2">
              <span className="text-[15px] font-black text-[#1F2433]">
                فكرني بعدين
              </span>
              <span className="text-[11px] text-[#6B7280] font-medium mt-0.5">
                {isHolding ? `${heldSeconds} ث` : `اضغط مطولاً (${currentHoldRequired}ث)`}
              </span>
            </div>
          </div>
        </div>

        {/* 7. Small muted note (12px) */}
        <p className="text-[11px] text-[#6B7280] text-center font-medium px-4">
          كمّل الضغط من غير ما ترفع إصبعك. لو رفعته العداد هيرجع للصفر مع اهتزاز تحذيري.
        </p>

        {/* 8. CBT 5-Minute Micro-Start & Done Early Actions */}
        <div className="w-full space-y-2">
          {microStartSecondsLeft === null ? (
            <button
              type="button"
              onClick={() => {
                hapticFeedback.light();
                setMicroStartSecondsLeft(300);
              }}
              className="w-full py-2.5 px-4 rounded-[14px] bg-white border border-[#E9E3FB] hover:border-[#6D28D9]/40 text-[#6D28D9] font-bold text-[12px] flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-[0.99] shadow-xs"
            >
              <Timer className="w-4 h-4" />
              <span>ابدأ بـ 5 دقائق فقط (كسر حاجز البداية)</span>
            </button>
          ) : (
            <div className="w-full py-2.5 px-4 rounded-[14px] bg-purple-50 border border-purple-200 text-[#6D28D9] font-black text-[13px] flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Timer className="w-4 h-4" />
                <span>{microStartSecondsLeft > 0 ? 'جلسة الـ 5 دقائق جارية' : 'أتممت الـ 5 دقائق بنجاح'}</span>
              </span>
              <span className="font-mono text-base tabular-nums">
                {formatMicroTimer(microStartSecondsLeft)}
              </span>
            </div>
          )}

          <div className="w-full relative rounded-[16px] overflow-hidden select-none">
            <button
              type="button"
              onMouseDown={startDoneEarlyHold}
              onMouseUp={cancelDoneEarlyHold}
              onMouseLeave={cancelDoneEarlyHold}
              onTouchStart={startDoneEarlyHold}
              onTouchEnd={cancelDoneEarlyHold}
              onTouchCancel={cancelDoneEarlyHold}
              className="w-full relative py-3 px-4 bg-[#DDF4EA] text-[#0F6B4A] font-bold text-[13px] flex items-center justify-center cursor-pointer overflow-hidden transition-all duration-150 active:scale-[0.99]"
              style={{ touchAction: 'none' }}
            >
              {/* While holding, darker mint overlay fills from right to left (RTL) */}
              <div
                className="absolute inset-y-0 right-0 bg-[#B8E8D2] transition-all duration-75 pointer-events-none"
                style={{
                  width: `${doneEarlyProgress}%`,
                  opacity: isDoneEarlyHolding ? 1 : 0,
                }}
              />

              <span className="relative z-10 font-black flex items-center justify-center gap-1.5">
                <Check className="w-4 h-4 stroke-[3]" />
                <span>تم بدري (اضغط مطوّلًا ثانيتين)</span>
              </span>
            </button>
          </div>
        </div>

        {/* Bottom safe spacer */}
        <div className="h-1" />
      </div>

      {/* 10. Small dark toast at the bottom */}
      {toastMessage && (
        <div className="fixed bottom-6 z-60 px-5 py-2.5 rounded-full bg-[#1F2433] text-white text-[13px] font-bold shadow-xl animate-fadeIn">
          {toastMessage}
        </div>
      )}
    </div>
  );
};
