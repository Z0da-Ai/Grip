import React from 'react';
import { Flame, Sparkles } from 'lucide-react';
import { StreakStats } from '../services/streakService';

interface StreakBadgeProps {
  stats: StreakStats;
  onClick: () => void;
  variant?: 'header' | 'compact' | 'card';
  isDarkMode?: boolean;
}

export const StreakBadge: React.FC<StreakBadgeProps> = ({
  stats,
  onClick,
  variant = 'header',
  isDarkMode = false,
}) => {
  const isBurning = stats.isCompletedToday;
  const streakCount = stats.currentStreak;

  if (variant === 'compact') {
    return (
      <button
        onClick={onClick}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-black transition cursor-pointer select-none active:scale-95 ${
          isBurning
            ? 'bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-950/70 dark:text-amber-200 dark:border-amber-700 shadow-xs'
            : 'bg-orange-50 text-orange-800 border border-orange-200 dark:bg-orange-950/40 dark:text-orange-300 dark:border-orange-800'
        }`}
        title={`سلسلة الانضباط: ${streakCount} أيام متواصلة. انقر لعرض التفاصيل`}
      >
        <Flame
          className={`w-3.5 h-3.5 text-amber-500 fill-amber-500 ${
            isBurning ? 'animate-bounce' : 'animate-pulse'
          }`}
        />
        <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black">{streakCount}</span>
        <span className="text-[10px] opacity-80">أيام</span>
      </button>
    );
  }

  if (variant === 'card') {
    return (
      <div
        onClick={onClick}
        className={`p-4 rounded-2xl border transition cursor-pointer hover:shadow-md select-none ${
          isDarkMode
            ? 'bg-slate-900/90 border-slate-800 hover:border-amber-700/60'
            : 'bg-gradient-to-br from-amber-50/50 via-white to-orange-50/40 border-amber-200/80 shadow-sm hover:border-amber-400'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
            سلسلة الانضباط اليومي
          </span>
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition ${
              isBurning
                ? 'bg-amber-500 text-white shadow-sm shadow-orange-500/30'
                : 'bg-amber-100 dark:bg-amber-950/60 text-amber-600'
            }`}
          >
            <Flame className={`w-4 h-4 fill-current ${isBurning ? 'animate-bounce' : 'animate-pulse'}`} />
          </div>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-amber-500 dark:text-amber-400 font-['Plus_Jakarta_Sans',sans-serif]">
            {streakCount}
          </span>
          <span className="text-xs font-bold text-slate-400">أيام متتالية</span>
        </div>

        <div className="mt-2 flex items-center justify-between text-[11px] font-bold">
          <span
            className={
              isBurning
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-amber-600 dark:text-amber-400'
            }
          >
            {isBurning ? 'مكتمل لهذا اليوم' : 'بانتظار إنجاز اليوم'}
          </span>
          <span className="text-slate-400 hover:text-amber-600 underline">عرض التفاصيل ←</span>
        </div>
      </div>
    );
  }

  // Default 'header' variant: Clean tactile streak button
  return (
    <button
      type="button"
      onClick={onClick}
      className={`group relative flex items-center gap-1.5 px-2.5 py-1.5 min-h-[38px] rounded-xl border transition-colors duration-200 cursor-pointer select-none active:scale-95 ${
        isBurning
          ? 'bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-950/60 border-amber-200 dark:border-amber-700/70 text-amber-800 dark:text-amber-200'
          : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
      }`}
      title={`سلسلة الانضباط: ${streakCount} أيام متواصلة`}
    >
      <Flame
        className={`w-4 h-4 shrink-0 ${
          isBurning ? 'text-amber-500 fill-amber-500' : 'text-amber-500'
        }`}
      />
      <span className="font-['Plus_Jakarta_Sans',sans-serif] tabular-nums font-bold text-xs sm:text-sm tracking-tight">
        {streakCount}
      </span>
      <span className="text-[11px] font-semibold hidden sm:inline">
        {streakCount === 1 ? 'يوم' : streakCount === 2 ? 'يومان' : 'أيام'}
      </span>
    </button>
  );
};
