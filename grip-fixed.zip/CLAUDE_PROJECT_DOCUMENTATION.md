# Grip (امسك يومك) — Complete System Architecture & Engineering Blueprint

> **To Claude / Senior Architect Reading This Document:**  
> This document provides an exhaustive, 360-degree technical and functional specification of **Grip**, an ADHD-friendly, native-ready life-management, study-enforcement, and daily scheduling application. Read this to understand every architectural layer, database schema, design philosophy, mobile background services, and AI processing pipeline.

---

## 1. Executive Summary & Core Value Proposition

- **App Name**: Grip (امسك يومك، لا تدع الوقت يفلت)
- **Target Audience**: Students, professionals, and individuals with ADHD, executive dysfunction, or chronic procrastination who easily ignore standard, passive calendar notifications.
- **Core Problem**: Traditional todo apps send gentle push notifications that users swipe away in 0.5 seconds. By the time they look at the phone, hours have slipped into social media doomscrolling.
- **Grip's Solution**:
  1. **Escalating Enforcement Overlay**: When a scheduled session begins, Grip aggressively claims the screen (via Android `SYSTEM_ALERT_WINDOW` or in-app full takeover). To dismiss or snooze, friction is introduced (e.g., holding a button for 5 continuous seconds).
  2. **Study Hierarchy (4-Tier Academic Wiki)**: Eliminates study overwhelm by structuring coursework into `Module` ➔ `Lecture` ➔ `Topic` ➔ `Study Task`.
  3. **Zero-Friction Capture (Voice & Photo)**: Voice dictation in colloquial/standard Arabic and timetable photo OCR using Gemini 2.5 Flash to automatically schedule tasks without tedious manual typing.
  4. **ADHD Second Brain & Intentions**: Instant brain-dump drawer for fleeting thoughts with one-click conversion to scheduled tasks.
  5. **Privacy & Offline-First**: 100% functional without an internet connection using local persistence (Room Database in Kotlin / LocalStorage in Web).

---

## 2. High-Level Technology Stack

### A. Native Android Layer (`android/`)
- **Language**: Kotlin 1.9+
- **UI Toolkit**: Jetpack Compose (Material 3 guidelines, edge-to-edge support)
- **Local Persistence**: Android Room Database (`GripDatabase`, Room DAOs, Coroutines, Flow)
- **Concurrency**: Kotlin Coroutines & StateFlow
- **Background Orchestration**:
  - `AlarmManager` (with `setExactAndAllowWhileIdle` and `SCHEDULE_EXACT_ALARM` permissions) for precision scheduling.
  - `ForegroundService` with ongoing notification (`NotificationCompat.Builder`) to keep the session alive.
  - `SYSTEM_ALERT_WINDOW` (Draw over other apps) for full-screen enforcement locks.
- **Build System**: Gradle Kotlin DSL (`build.gradle.kts`, `settings.gradle.kts`, Target SDK 34 / Android 14+).

### B. Web / PWA / WebAPK Layer (`src/`, `public/`)
- **Framework**: React 18 with TypeScript.
- **Styling**: Tailwind CSS with dark mode class strategy (`#090D16` deep dark slate & `#6D28D9` brand royal violet).
- **Icons**: Lucide React.
- **PWA / Service Worker**: `vite-plugin-pwa` with `Workbox` caching strategy, `manifest.webmanifest`, WebAPK install support.
- **Store Compliance**: Google Play Store TWA (Trusted Web Activity) via `assetlinks.json` and `privacy.html`.

### C. Backend & AI Server (`server.ts`)
- **Runtime**: Node.js + Express with TypeScript (`tsx`).
- **Development Mode**: Integrated Vite middleware (`createViteServer`) with HMR isolation.
- **AI Engine**: `@google/genai` TypeScript SDK using `gemini-2.5-flash` model.
- **Endpoints**:
  - `POST /api/ai/parse-voice`: Multi-turn Arabic natural language parsing for schedule events, alarms, and expenses.
  - `POST /api/ai/parse-photo-schedule`: Multimodal OCR processing of class timetables and study lists.
  - `POST /api/ai/split-topics`: Automatic syllabus decompilation into bite-sized 30-minute focus sessions.
  - `GET /api/download-project-zip` & `/grip-complete-project.zip`: Serves complete project backup.

---

## 3. Data Models & Schemas

### 1. `GripTask` (The Core Schedule Unit)
```typescript
interface GripTask {
  id: string;                         // UUID
  title: string;                      // e.g. "مذاكرة فسيولوجي"
  category: 'study' | 'work' | 'sport' | 'prayer' | 'other';
  startTime: string;                  // ISO 8601 string
  endTime: string;                    // ISO 8601 string
  type: 'FIXED' | 'FLEXIBLE';         // FIXED = cannot auto-shift; FLEXIBLE = auto-reschedules on conflict
  status: 'pending' | 'in_progress' | 'done' | 'done_early' | 'postponed' | 'missed';
  notes?: string;
  moduleId?: string;                  // Link to StudyModule
  topicId?: string;                   // Link to StudyTopic
  actualMinutesSpent?: number;
  postponeCount?: number;
}
```

### 2. `StudyModule`, `StudyLecture`, `StudyTopic` (The Academic Hierarchy)
- **Module**: e.g., "Human Physiology", with color, icon, and semester.
- **Lecture**: e.g., "Lecture 4: Cardiovascular Hemodynamics".
- **Topic**: e.g., "Blood pressure regulation mechanics" (estimated 30 mins).
- **Auto-Chain Link**: Completing a lecture can automatically propose scheduled review sessions at intervals (spaced repetition concept).

### 3. `GripIntention` (The ADHD Second Brain)
```typescript
interface GripIntention {
  id: string;
  text: string;
  tag: 'today' | 'later' | 'idea';
  createdAt: string;
  completed: boolean;
}
```

### 4. `DailyTrackerRecord` & Streaks
- Records daily completion rates, number of postponed tasks, and total scheduled sessions.
- Calculates ongoing streaks, best streaks, and trigger celebration confetti upon milestones.

### 5. `BudgetItem` (Integrated Student Finance)
- Records simple daily expenses and income so students don't need a separate finance tracker.

---

## 4. Key Architectural Subsystems

### Subsystem 1: The Escalating Enforcement Engine (`EnforcementOverlay.tsx`)
1. **Pre-Warning (30 seconds before start)**: Sound chime & gentle heads-up notification.
2. **Hard Takeover**: At `startTime`, if the task has not been marked done, the full-screen overlay opens:
   - Displays task title, countdown timer of session, and motivation micro-copy.
   - Darkened background blocks user from navigating elsewhere.
3. **Friction Snooze (Anti-Impulse Mechanism)**:
   - The user cannot simply tap "Later".
   - They must press and physically hold the postpone button for **5 seconds** while a circular progress bar fills and haptic feedback pulses.
   - This breaks unconscious thumb habits and forces conscious decision-making.
4. **Free Window Grace Period**:
   - Once a focus session is completed, a "Free Window" (e.g., 10 minutes) banner activates at the top of the app, giving the user explicit guilt-free break time.

### Subsystem 2: The Flexible Auto-Reschedule Engine (`rescheduleEngine.ts`)
- If a task marked `FLEXIBLE` is postponed or bumped by an unexpected emergency or overlapping `FIXED` event, the engine:
  1. Scans the remainder of the user's day for open slots $\ge$ task duration.
  2. Respects user bedtime and prayer times.
  3. Automatically updates `startTime` and `endTime` and persists to storage.

### Subsystem 3: Multimodal AI Schedules (`server.ts`)
- **Voice Assistant**: Listens in Arabic (Egyptian dialect or Modern Standard Arabic, e.g., *"عايز أذاكر باثولوجي بكرة من 5 لـ 7 ومعايا 50 جنيه مصروف"*). The server parses this into structured JSON actions: creating calendar tasks, recording budget expenses, and setting morning alarms in a single pass.
- **Vision OCR**: The student photographs a whiteboard lecture schedule or university paper timetable; Gemini parses dates, times, and course codes directly into `GripTask[]`.

### Subsystem 4: Android Native Implementation (`android/`)
- Located in `/android`:
  - `app/src/main/java/com/grip/app/MainActivity.kt`: Jetpack Compose entry point.
  - `app/src/main/java/com/grip/app/data/`: Room Database entities & DAOs.
  - `app/src/main/java/com/grip/app/service/EnforcementService.kt`: Android Foreground Service managing system overlay windows.
  - `app/src/main/java/com/grip/app/receiver/AlarmReceiver.kt`: Broadcast receiver for `AlarmManager`.

---

## 5. Directory Structure Overview

```text
/
├── android/                   # Full Native Kotlin Android Studio Project
│   ├── app/
│   │   ├── build.gradle.kts
│   │   └── src/main/java/com/grip/app/
│   │       ├── MainActivity.kt
│   │       ├── data/          # Room Database, Entities, DAOs
│   │       ├── service/       # Enforcement & Overlay Foreground Services
│   │       ├── receiver/      # Alarm Broadcast Receivers
│   │       └── ui/            # Jetpack Compose Screens
│   ├── build.gradle.kts
│   └── settings.gradle.kts
├── public/                    # Static Assets & PWA
│   ├── icon.svg               # Official Grip Chain-link Logo
│   ├── manifest.webmanifest   # PWA / WebAPK Manifest
│   ├── privacy.html           # Google Play Store Privacy Policy
│   ├── .well-known/           # assetlinks.json for Digital Asset Links
│   └── grip-complete-project.zip # Pre-packaged complete ZIP bundle
├── scripts/
│   └── create-complete-zip.py # Python script for building offline project archive
├── src/
│   ├── components/            # UI Modals & Views (Calendar, Study, Trackers, Overlay, AI)
│   ├── services/              # Storage, Rescheduling, Haptics, Notifications
│   ├── types/                 # TypeScript interfaces (GripTask, Module, User, etc.)
│   ├── utils/                 # Hijri calendar calculations, ZIP download helper
│   ├── App.tsx                # Main App entry point & responsive viewport
│   └── main.tsx               # React DOM bootstrap
├── .github/workflows/         # CI/CD: build-android.yml
├── server.ts                  # Express backend + Gemini AI SDK endpoints
├── package.json               # NPM scripts and dependencies
└── tsconfig.json              # TypeScript compilation rules
```

---

## 6. How to Run & Build

1. **Web Dev Mode**: `npm run dev` (Runs Express + Vite on port 3000).
2. **Web Production Build**: `npm run build` (Outputs bundle to `dist/`).
3. **Android Studio**: Open `/android` folder directly in Android Studio Hedgehog / Iguana / Ladybug; Gradle sync will succeed out of the box. Run `./gradlew assembleDebug` to build the APK.
