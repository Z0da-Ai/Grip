/**
 * On-device Arabic (Egyptian + Modern Standard) / English understanding of tasks,
 * expenses, alarms, intentions and habits. Used by the app itself (no internet, no server)
 * and by the server as a fallback.
 */

// ---------------------------------------------------------------- text helpers
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const clean = (t: string) =>
  (t || '')
    .replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d)))
    .replace(/[\u064B-\u065F\u0640]/g, '') // tashkeel + tatweel
    .replace(/[،؛,;]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const A = '[أاإآ]';
const HOUR_WORDS: Record<string, number> = {
  واحده: 1, واحدة: 1, وحده: 1, اتنين: 2, اثنين: 2, اثنتين: 2, تلاته: 3, ثلاثه: 3, تلاتة: 3, ثلاثة: 3,
  اربعه: 4, أربعه: 4, اربعة: 4, أربعة: 4, خمسه: 5, خمسة: 5, سته: 6, ستة: 6, سبعه: 7, سبعة: 7,
  تمانيه: 8, تمانية: 8, ثمانيه: 8, ثمانية: 8, تسعه: 9, تسعة: 9, عشره: 10, عشرة: 10,
  حداشر: 11, احدعشر: 11, اتناشر: 12, اثناعشر: 12,
};
const HOUR_WORD_RE = Object.keys(HOUR_WORDS).join('|');

const NUM_WORDS: Record<string, number> = {
  واحد: 1, اتنين: 2, اثنين: 2, تلاته: 3, تلاتة: 3, ثلاثة: 3, اربعه: 4, اربعة: 4, أربعة: 4, خمسه: 5, خمسة: 5,
  سته: 6, ستة: 6, سبعه: 7, سبعة: 7, تمانيه: 8, تمانية: 8, ثمانية: 8, تسعه: 9, تسعة: 9, عشره: 10, عشرة: 10,
  حداشر: 11, اتناشر: 12, عشرين: 20, تلاتين: 30, ثلاثين: 30, اربعين: 40, أربعين: 40, خمسين: 50, ستين: 60,
  سبعين: 70, تمانين: 80, ثمانين: 80, تسعين: 90, ميه: 100, مية: 100, مائة: 100, ميتين: 200, مئتين: 200,
  تلتمية: 300, ثلاثمائة: 300, ربعمية: 400, اربعمية: 400, خمسمية: 500, خمسمائة: 500, ستمية: 600,
  سبعمية: 700, تمنمية: 800, تسعمية: 900, الف: 1000, ألف: 1000, الفين: 2000, ألفين: 2000,
};

function wordsToNumber(text: string): number | null {
  const tokens = text.split(/\s+/).map((t) => t.replace(/^و/, (m) => (NUM_WORDS[t] ? m : '')));
  let total = 0;
  let found = false;
  for (const raw of text.split(/\s+/)) {
    const t = NUM_WORDS[raw] !== undefined ? raw : raw.replace(/^و/, '');
    if (NUM_WORDS[t] !== undefined) {
      total += NUM_WORDS[t];
      found = true;
    }
  }
  void tokens;
  return found ? total : null;
}

function parseRef(referenceDateStr?: string): Date {
  if (referenceDateStr) {
    const m = referenceDateStr.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    const d = new Date(referenceDateStr);
    if (!isNaN(d.getTime())) return d;
  }
  const n = new Date();
  return new Date(n.getFullYear(), n.getMonth(), n.getDate());
}

// ---------------------------------------------------------------- date
const WEEKDAYS: Array<[RegExp, number]> = [
  [new RegExp(`(?:ال)?${A}حد(?![\\u0600-\\u06FF])`), 0],
  [/(?:ال)?(?:اثنين|إثنين|اتنين|تنين)(?![\u0600-\u06FF])/, 1],
  [/(?:ال)?(?:ثلاثاء|تلات|تلاتاء|ثلاثاء)(?![\u0600-\u06FF])/, 2],
  [new RegExp(`(?:ال)?${A}ربعاء(?![\\u0600-\\u06FF])|(?:ال)?${A}ربع(?![\\u0600-\\u06FF])`), 3],
  [/(?:ال)?خميس(?![\u0600-\u06FF])/, 4],
  [/(?:ال)?جمع[ةه](?![\u0600-\u06FF])/, 5],
  [/(?:ال)?سبت(?![\u0600-\u06FF])/, 6],
];
const MONTHS: Array<[RegExp, number]> = [
  [/يناير|كانون الثاني/, 0], [/فبراير|شباط/, 1], [/مارس|اذار|آذار/, 2], [/ابريل|أبريل|نيسان/, 3],
  [/مايو|ايار|أيار/, 4], [/يونيو|يونيه|حزيران/, 5], [/يوليو|يوليه|تموز/, 6], [/اغسطس|أغسطس|اب\b|آب\b/, 7],
  [/سبتمبر|ايلول|أيلول/, 8], [/اكتوبر|أكتوبر|تشرين الاول/, 9], [/نوفمبر|تشرين الثاني/, 10], [/ديسمبر|كانون الاول/, 11],
];

interface Span { start: number; end: number }

function findDate(n: string, ref: Date): { date: Date; spans: Span[]; explicit: boolean } {
  const spans: Span[] = [];
  const mark = (m: RegExpMatchArray | null) => {
    if (m && m.index !== undefined) spans.push({ start: m.index, end: m.index + m[0].length });
  };
  const d = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate());

  let m = n.match(/بعد\s*(?:بكره|بكرة|غد)|day after tomorrow/i);
  if (m) { mark(m); d.setDate(d.getDate() + 2); return { date: d, spans, explicit: true }; }
  m = n.match(/(?:بكره|بكرة|غدا|غداً|tomorrow)/i);
  if (m) { mark(m); d.setDate(d.getDate() + 1); return { date: d, spans, explicit: true }; }
  m = n.match(/(?:امبارح|أمس|امس|yesterday)/i);
  if (m) { mark(m); d.setDate(d.getDate() - 1); return { date: d, spans, explicit: true }; }
  m = n.match(/(?:النهارده|النهاردة|النهارد[ةه]|اليوم|الليله|الليلة|today|tonight)/i);
  if (m) { mark(m); return { date: d, spans, explicit: true }; }

  // 25/11 or 25-11
  m = n.match(/\b(\d{1,2})\s*[\/\-]\s*(\d{1,2})(?:\s*[\/\-]\s*(\d{2,4}))?\b/);
  if (m && +m[2] >= 1 && +m[2] <= 12 && +m[1] >= 1 && +m[1] <= 31) {
    mark(m);
    const year = m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : ref.getFullYear();
    return { date: new Date(year, +m[2] - 1, +m[1]), spans, explicit: true };
  }
  // 25 نوفمبر
  for (const [re, idx] of MONTHS) {
    const mm = n.match(new RegExp(`(\\d{1,2})\\s*(?:من\\s*)?(?:شهر\\s*)?(${re.source})`));
    if (mm) {
      mark(mm);
      let date = new Date(ref.getFullYear(), idx, +mm[1]);
      if (date.getTime() < d.getTime() - 86400000) date = new Date(ref.getFullYear() + 1, idx, +mm[1]);
      return { date, spans, explicit: true };
    }
  }
  // weekday
  for (const [re, wd] of WEEKDAYS) {
    const mm = n.match(new RegExp(`(?:يوم\\s*)?(?:${re.source})`));
    if (mm) {
      mark(mm);
      let diff = (wd - d.getDay() + 7) % 7;
      if (/(?:الاسبوع|الأسبوع)\s*(?:الجاي|القادم|اللي جاي|الجايه)/.test(n)) diff += diff === 0 ? 7 : 0;
      d.setDate(d.getDate() + diff);
      const wk = n.match(/(?:ال[اأ]سبوع)\s*(?:الجاي|القادم|اللي جاي|الجايه)/);
      mark(wk);
      return { date: d, spans, explicit: true };
    }
  }
  return { date: d, spans, explicit: false };
}

// ---------------------------------------------------------------- time
type Period = 'am' | 'pm' | 'noon' | null;
const periodOf = (s: string): Period => {
  if (s.trim() === 'ص') return 'am';
  if (s.trim() === 'م') return 'pm';
  if (/(?:صبح|الصبح|صباح|صباحا|صباحاً|فجر|الفجر|am\b)/i.test(s)) return 'am';
  if (/(?:ضهر|الضهر|ظهر|الظهر)/.test(s)) return 'noon';
  if (/(?:عصر|العصر|مساء|المساء|مساءً|مغرب|المغرب|عشاء|ليل|الليل|بالليل|ليلا|pm\b)/i.test(s)) return 'pm';
  return null;
};
const PERIOD_RE = '(?:ص(?![\\u0600-\\u06FF])|م(?![\\u0600-\\u06FF])|صباحا|صباحاً|الصبح|صبح|الفجر|فجر|الضهر|ضهر|الظهر|ظهر|العصر|عصر|المغرب|مغرب|المساء|مساءً|مساء|بالليل|الليل|ليل|ليلا|am|pm)';

function to24(h: number, p: Period, preferAM: boolean): number {
  if (h >= 13) return h % 24;
  if (p === 'am') return h === 12 ? 0 : h;
  if (p === 'noon') return h < 7 ? h + 12 : h === 12 ? 12 : h;
  if (p === 'pm') return h === 12 ? (/ليل/.test('') ? 0 : 12) : h + 12;
  // no period given: pick the most natural reading
  if (preferAM) return h === 12 ? 12 : h;
  if (h >= 1 && h <= 6) return h + 12;
  return h; // 7..12 -> morning/noon
}

interface TimeInfo { startH: number; startM: number; endH?: number; endM?: number; spans: Span[]; found: boolean }

function findTime(n: string, preferAM = false): TimeInfo {
  const spans: Span[] = [];
  const mark = (m: RegExpMatchArray) => { if (m.index !== undefined) spans.push({ start: m.index, end: m.index + m[0].length }); };
  const hourTok = `(\\d{1,2}|${HOUR_WORD_RE})`;
  const minTok = '(?::(\\d{2}))?';
  const frac = '(?:\\s*(ونص|ونصف|وربع|وثلث|الا ربع|إلا ربع|الا تلت|إلا ثلث|الا ثلث))?';
  const hv = (s: string) => (/^\d+$/.test(s) ? parseInt(s, 10) : HOUR_WORDS[s] ?? NaN);
  const minutesOf = (hr: number, mm: string | undefined, fr: string | undefined): [number, number] => {
    if (mm) return [hr, parseInt(mm, 10)];
    if (!fr) return [hr, 0];
    if (/ونص|ونصف/.test(fr)) return [hr, 30];
    if (/وربع/.test(fr)) return [hr, 15];
    if (/وثلث/.test(fr)) return [hr, 20];
    if (/الا ربع|إلا ربع/.test(fr)) return [hr - 1, 45];
    return [hr - 1, 40];
  };

  // range: "من 4 لـ 6 المغرب"
  const range = n.match(new RegExp(`(?:من|from)\\s*(?:الساع[ةه]\\s*)?${hourTok}${minTok}\\s*(${PERIOD_RE})?\\s*(?:لـ?|الى|إلى|حتى|to|-)\\s*(?:الساع[ةه]\\s*)?${hourTok}${minTok}\\s*(${PERIOD_RE})?`, 'i'));
  if (range) {
    mark(range);
    const p2 = periodOf(range[6] || '') || periodOf(range[3] || '');
    const p1 = periodOf(range[3] || '') || p2;
    let [sH, sM] = minutesOf(hv(range[1]), range[2], undefined);
    let [eH, eM] = minutesOf(hv(range[4]), range[5], undefined);
    sH = to24(sH, p1, preferAM);
    eH = to24(eH, p2, preferAM);
    if (eH <= sH && eH < 12) eH += 12;
    if (eH <= sH) eH = sH + 1;
    return { startH: sH, startM: sM, endH: eH, endM: eM, spans, found: true };
  }

  // "الساعة 5 العصر" / "5:30 م" / "الساعة خمسة ونص"
  const single =
    n.match(new RegExp(`(?:الساع[ةه]|ساع[ةه]|عند|على|at)\\s*${hourTok}${minTok}${frac}\\s*(${PERIOD_RE})?`, 'i')) ||
    n.match(new RegExp(`(?<![\\d:/])(\\d{1,2})(?::(\\d{2}))${frac}\\s*(${PERIOD_RE})?`, 'i')) ||
    n.match(new RegExp(`(?<![\\d:/.])(\\d{1,2})()${frac}\\s*(${PERIOD_RE})(?![\\w])`, 'i'));
  if (single) {
    mark(single);
    const hr = hv(single[1]);
    if (!isNaN(hr) && hr >= 0 && hr <= 24) {
      const [h0, m0] = minutesOf(hr, single[2], single[3]);
      const h = to24(h0, periodOf(single[4] || ''), preferAM);
      return { startH: h, startM: m0, spans, found: true };
    }
  }
  return { startH: 0, startM: 0, spans, found: false };
}

function findDurationMinutes(n: string): { minutes: number | null; spans: Span[] } {
  const spans: Span[] = [];
  const mark = (m: RegExpMatchArray) => { if (m.index !== undefined) spans.push({ start: m.index, end: m.index + m[0].length }); };
  let m = n.match(/(?:لمده|لمدة|مدة|for)?\s*(?:ساعه|ساعة)\s*(?:و\s*)?(نص|نصف|ربع)(?![\u0600-\u06FF])/);
  if (m) { mark(m); return { minutes: 60 + (m[1] === 'ربع' ? 15 : 30), spans }; }
  m = n.match(/(?:لمده|لمدة|مدة)?\s*(نص|نصف)\s*(?:ساعه|ساعة)/);
  if (m) { mark(m); return { minutes: 30, spans }; }
  m = n.match(/(?:لمده|لمدة|مدة)?\s*ربع\s*(?:ساعه|ساعة)/);
  if (m) { mark(m); return { minutes: 15, spans }; }
  m = n.match(/(?:لمده|لمدة|مدة)?\s*(?:ساعتين|ساعتان)/);
  if (m) { mark(m); return { minutes: 120, spans }; }
  m = n.match(new RegExp(`(?:لمده|لمدة|مدة|for)\\s*(\\d+(?:\\.\\d+)?|${Object.keys(NUM_WORDS).join('|')})\\s*(ساع[ةه]|ساعات|دقيق[ةه]|دقايق|دقائق|hours?|hrs?|minutes?|mins?)`, 'i'));
  if (m) {
    mark(m);
    const v = /^\d/.test(m[1]) ? parseFloat(m[1]) : NUM_WORDS[m[1]];
    return { minutes: /ساع|hour|hr/i.test(m[2]) ? Math.round(v * 60) : Math.round(v), spans };
  }
  m = n.match(/(?<![\d:])(\d+)\s*(دقيق[ةه]|دقايق|دقائق|ساع[ةه]|ساعات)(?!\s*(?:ونص|وربع))/);
  if (m) { mark(m); return { minutes: /ساع/.test(m[2]) ? +m[1] * 60 : +m[1], spans }; }
  return { minutes: null, spans };
}

function removeSpans(text: string, spans: Span[]): string {
  const sorted = [...spans].sort((a, b) => b.start - a.start);
  let out = text;
  for (const s of sorted) out = out.slice(0, s.start) + ' ' + out.slice(s.end);
  return out;
}

// ---------------------------------------------------------------- tasks
const LECTURE_RE = /(?:محاضر[ةه]|امتحان|اختبار|كويز|سكشن|ميتنج|اجتماع|meeting|exam|quiz|lecture|ميعاد دكتور|موعد دكتور|عند الدكتور)/i;
const SPORT_RE = /(?:تمرين|تمارين|جيم|نادي|جري|اجري|رياض[ةه]|مشي|سباح[ةه]|gym|workout|run|كارديو)/i;
const STUDY_RE = /(?:ذاكر|اذاكر|أذاكر|مذاكر[ةه]|مراجع[ةه]|اراجع|أراجع|محاضر[ةه]|امتحان|كويز|سكشن|واجب|درس|كورس|حل مسائل|study)/i;
const WORK_RE = /(?:شغل|عمل|اجتماع|ميتنج|تقرير|عميل|مشروع|ايميل|إيميل|رد على|مكالم[ةه]|work)/i;
const SLEEP_RE = /(?:نوم|انام|أنام|اتنام|sleep)/i;
const LEAD_VERBS = new RegExp(
  `^(?:${A}?ضيف(?:لي)?|${A}ضف|سجل(?:لي)?|حط(?:لي)?|اعمل(?:لي)?|${A}عمل(?:لي)?|عايز|عاوز|ع[ا]يز|محتاج|ح${A}عمل|هعمل|ناوي|فكرني|ذكرني|ضيف لي|جدول(?:لي)?|ابقى|لازم|مهم[ةه]|موعد|ميعاد|عندي|اني|انا|إني|أنا|ان)\\s+(?:ان\\s+|أن\\s+)?`,
  'i'
);

function titleFrom(original: string, spans: Span[], lectureOrSport: { lecture: boolean; study: boolean }): string {
  let t = removeSpans(original, spans);
  for (let i = 0; i < 3; i++) t = t.replace(LEAD_VERBS, '').trim();
  t = t
    .replace(/\b(?:الساع[ةه]|ساع[ةه]|يوم|في|فى|على|عند|ل|لـ|ب|بـ|من|الى|إلى|at|on|for)\s*$/i, '')
    .replace(/^(?:ل|لـ|ب|بـ|في|عن|على)\s+/, '')
    .replace(/\s+(?:في|الساعة|الساعه|يوم|من|لـ|ل|بعد|على|عند)\s*$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  // "ذاكر فيزياء" -> "مذاكرة فيزياء"
  t = t.replace(new RegExp(`^(?:${A}?ذاكر|ه?${A}?ذاكر)\\s*`), 'مذاكرة ').trim();
  t = t.replace(/^(?:اراجع|أراجع)\s*/, 'مراجعة ').trim();
  t = t.replace(/^(?:اروح|أروح|هروح)\s*/, 'الذهاب إلى ').trim();
  if (!t) return lectureOrSport.study ? 'جلسة مذاكرة' : 'مهمة جديدة';
  return t;
}

function startOfDayPlus(date: Date, h: number, m: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), h, m, 0, 0);
}

function parseOneTask(sentence: string, ref: Date, opts?: { now?: Date }) {
  const original = clean(sentence);
  const dateInfo = findDate(original, ref);
  const timeInfo = findTime(original);
  const dur = findDurationMinutes(original);

  const isLecture = LECTURE_RE.test(original);
  const isSport = SPORT_RE.test(original);
  const isStudy = STUDY_RE.test(original);
  const isWork = WORK_RE.test(original);
  const isSleep = SLEEP_RE.test(original);

  let startH = 16, startM = 0;
  if (timeInfo.found) {
    startH = timeInfo.startH;
    startM = timeInfo.startM;
  } else if (!dateInfo.explicit || dateInfo.date.toDateString() === ref.toDateString()) {
    // no time and it's for today: start at the next full hour
    const now = opts?.now || new Date();
    if (now.toDateString() === dateInfo.date.toDateString()) {
      startH = Math.min(22, now.getHours() + 1);
      startM = 0;
    }
  }
  const start = startOfDayPlus(dateInfo.date, startH, startM);
  let end: Date;
  if (timeInfo.endH !== undefined) {
    end = startOfDayPlus(dateInfo.date, timeInfo.endH, timeInfo.endM || 0);
  } else {
    const minutes = dur.minutes ?? (isLecture || isStudy ? 120 : isSport ? 60 : 60);
    end = new Date(start.getTime() + minutes * 60000);
  }

  let title = titleFrom(original, [...dateInfo.spans, ...timeInfo.spans, ...dur.spans], { lecture: isLecture, study: isStudy });
  if (isLecture && /^(?:محاضر[ةه])/.test(title) && !/حضور/.test(title)) title = `${title} (حضور كليّة)`;

  const category = isLecture && !isWork ? 'study' : isSport ? 'sport' : isSleep ? 'sleep' : isWork && !isStudy ? 'work' : isStudy || isLecture ? 'study' : 'personal';
  const type = isLecture ? 'FIXED' : 'FLEXIBLE';
  return {
    title,
    category,
    startTime: start.toISOString(),
    endTime: end.toISOString(),
    type,
    notes: isLecture ? 'حضور • منبه وتنبيه قبل الموعد' : 'تم استخراجها من كلامك على جهازك',
  };
}

export function extractTasksRuleBased(promptText: string, referenceDateStr?: string) {
  const ref = parseRef(referenceDateStr);
  const parts = (promptText || '')
    .split(/\n+|[.;؛]\s+|\s+ثم\s+/)
    .map((p) => p.trim())
    .filter((p) => p.length > 1);
  if (parts.length === 0) return [];
  return parts.map((p) => parseOneTask(p, ref));
}

// ---------------------------------------------------------------- amounts
function findAmount(n: string): { value: number; span: Span } | null {
  let m = n.match(/(\d+(?:\.\d+)?)\s*(?:جنيه|جنية|ج\.?م|جم|egp|pounds?|\$|دولار|ريال)/i);
  if (m && m.index !== undefined) return { value: parseFloat(m[1]), span: { start: m.index, end: m.index + m[0].length } };
  m = n.match(/(?:بـ?|ب|قيمه|قيمة|مبلغ|بمبلغ)\s*(\d+(?:\.\d+)?)/i);
  if (m && m.index !== undefined) return { value: parseFloat(m[1]), span: { start: m.index, end: m.index + m[0].length } };
  m = n.match(/(?<![:\d\/])(\d+(?:\.\d+)?)(?![:\d\/])/);
  if (m && m.index !== undefined) return { value: parseFloat(m[1]), span: { start: m.index, end: m.index + m[0].length } };
  // words: "خمسين جنيه", "مية وخمسين"
  const wm = n.match(new RegExp(`((?:و?(?:${Object.keys(NUM_WORDS).join('|')}))(?:\\s+و?(?:${Object.keys(NUM_WORDS).join('|')}))*)\\s*(?:جنيه|جنية|جم|ج)?`));
  if (wm && wm.index !== undefined) {
    const v = wordsToNumber(wm[1]);
    if (v) return { value: v, span: { start: wm.index, end: wm.index + wm[0].length } };
  }
  return null;
}

// ---------------------------------------------------------------- voice commands
export function parseVoiceCommandRuleBased(promptText: string, referenceDateStr?: string) {
  const text = clean(promptText);
  const ref = parseRef(referenceDateStr);

  // 1. Expense
  const isExpense = /(?:صرفت|صرف|مصروف|مصاريف|اشتريت|اشترى|دفعت|دفع|تكلف[ةه]|جنيه|جنية|egp|شراء|فاتور[ةه]|خدت ب|كلفني)/i.test(text);
  if (isExpense) {
    const amt = findAmount(text);
    if (amt && amt.value > 0) {
      let categoryName = 'أخرى';
      if (/أكل|اكل|شرب|قهو[ةه]|فطار|غدا|عشا|شاي|عصير|مطعم|ساندوتش|وجب[ةه]|حلويات|بيتزا|برجر|كشري|سوبر ?ماركت/i.test(text)) categoryName = 'أكل ومشاريب';
      else if (/بنزين|مواصلات|اوبر|أوبر|تاكسي|مترو|ميكروباص|عربي[ةه]|تذكر[ةه]|توك توك|اتوبيس|أتوبيس/i.test(text)) categoryName = 'مواصلات';
      else if (/كتب|كتاب|كورس|ملازم|مكتب[ةه]|مذكر[ةه]|معهد|جامع[ةه]|محاضر[ةه]|ادوات|أدوات|اشتراك/i.test(text)) categoryName = 'مذاكرة وكورسات';
      else if (/خروج[ةه]|سينما|فسح[ةه]|بلايستيشن|لعب[ةه]|ترفيه|كافيه|نتفليكس/i.test(text)) categoryName = 'خروجات وترفيه';

      let title = removeSpans(text, [amt.span])
        .replace(/(?:سجل|سجلت|ضيف|اضف|أضف|صرفت|صرف|اشتريت|دفعت|مصروف|مصاريف|تكلف[ةه]|بقيم[ةه]|قيم[ةه]|مبلغ|خدت|كلفني)\s*/gi, ' ')
        .replace(/(?:^|\s)(?:جنيه|جنية|ج\.?م|egp)(?![\u0600-\u06FF])/gi, ' ')
        .replace(/(?:^|\s)(?:ب|بـ|على|في|عشان|علي|من|لـ|ل)(?=\s|$)/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!title) title = categoryName;

      return {
        intent: 'ADD_EXPENSE',
        summary: `تسجيل مصروف بقيمة ${amt.value} ج.م (${categoryName}) - ${title}`,
        spokenFeedback: `تم تسجيل مصروف ${amt.value} جنيه في ${categoryName} بنجاح`,
        data: {
          expense: {
            amount: amt.value,
            amountMinor: Math.round(amt.value * 100),
            title,
            categoryName,
            note: 'تمت الإضافة بالأمر الصوتي',
          },
        },
      };
    }
  }

  // 2. Wake-up alarm
  if (/(?:منبه|صحيني|اصحيني|اصحى|أصحى|الصحو[ةه]|استيقاظ|فوقني)/i.test(text)) {
    const t = findTime(text, true);
    const hour = t.found ? t.startH : 6;
    const min = t.found ? t.startM : 30;
    const timeFormatted = `${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
    return {
      intent: 'SET_WAKE_UP_ALARM',
      summary: `ضبط منبه الصحوة الحاسم على الساعة ${timeFormatted}`,
      spokenFeedback: `تم ضبط منبه الصحوة الحاسم على الساعة ${hour} و ${min} دقيقة بنجاح`,
      data: { alarm: { time: timeFormatted, title: 'منبه الصحوة الحاسم ⏰', notes: 'تم الضبط عبر الأمر الصوتي' } },
    };
  }

  // 3. Intention
  if (/(?:نيتي|النيه|النية|انوي|أنوي|نويت|ناوي|نيه|نية|هدف اليوم|هدفي|عازم على)/i.test(text)) {
    let intentionText = text
      .replace(/(?:اضف نية|سجل نية|نيتي|النية|نويت|ناوي|انوي|أنوي|هدفي|هدف اليوم)\s*/gi, ' ')
      .replace(/(?:النهارده|النهاردة|اليوم|ان شاء الله|إن شاء الله)/g, ' ')
      .replace(/^\s*(?:هي|هو|إني|اني|ان|أن)\s+/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!intentionText) intentionText = text;
    let tag: 'today' | 'routine' | 'idea' | 'urgent' = 'today';
    if (/ماء|مياه|مية|صلا[ةه]|رياض[ةه]|تنفس|عاد[ةه]|تمرين/i.test(text)) tag = 'routine';
    else if (/فكر[ةه]|تدوين[ةه]|مشروع/i.test(text)) tag = 'idea';
    else if (/ضروري|مستعجل|مهم جدا|مهم جداً/i.test(text)) tag = 'urgent';
    return {
      intent: 'ADD_INTENTION',
      summary: `تسجيل نية جديدة: "${intentionText}"`,
      spokenFeedback: 'تم تسجيل نيتك بنجاح، بالتوفيق والبركة',
      data: { intention: { text: intentionText, tag } },
    };
  }

  // 4. Habit log (past tense "I drank water")
  if (/(?:شربت|شرب[ةه]?)\s*(?:كوباي[ةه]|كوب|لتر|ازاز[ةه]|زجاج[ةه])?\s*(?:مياه|ماء|مية|ميه)|كوباي[ةه] (?:مياه|مية|ماء)|لتر (?:مياه|مية)/i.test(text) && !/فكرني|ذكرني/.test(text)) {
    return {
      intent: 'LOG_TRACKER',
      summary: 'تسجيل شرب كوب ماء 💧',
      spokenFeedback: 'تم تسجيل شرب الماء بنجاح، ممتاز!',
      data: { tracker: { trackerType: 'water', label: 'شرب ماء', value: 1 } },
    };
  }

  // 5. Task / reminder / appointment
  const task: any = extractTasksRuleBased(promptText, referenceDateStr)[0] || {
    title: text || 'مهمة جديدة',
    category: 'personal',
    startTime: new Date().toISOString(),
    endTime: new Date(Date.now() + 3600000).toISOString(),
    type: 'FLEXIBLE',
    notes: 'تمت الإضافة عبر الأمر الصوتي',
  };
  if (/فكرني|ذكرني/.test(text)) {
    task.notes = 'تذكير أضفته بصوتك';
  }
  const startTimeDate = new Date(task.startTime);
  const timeLabel = isNaN(startTimeDate.getTime())
    ? ''
    : ` (${startTimeDate.getHours()}:${String(startTimeDate.getMinutes()).padStart(2, '0')})`;
  return {
    intent: 'SCHEDULE_TASK',
    summary: `إضافة مهمة للجدول: "${task.title}"${timeLabel}`,
    spokenFeedback: `تمت جدولة ${task.title} في الجدول بنجاح`,
    data: { task },
  };
}
