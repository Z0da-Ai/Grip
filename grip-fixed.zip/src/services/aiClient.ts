/**
 * All "smart" features go through here.
 * 1) If an AI server is reachable, use it (better understanding, can read images/PDF).
 * 2) Otherwise understand the text ON THE DEVICE with the built-in Arabic/English parser.
 * Inside the Android app there is no server unless VITE_API_URL was set, so it runs fully offline.
 */
import { apiUrl, hasRemoteApi } from './apiBase';
import { extractTasksRuleBased, parseVoiceCommandRuleBased } from '../shared/ruleBased';

const isNative = () => !!(window as any).Capacitor?.isNativePlatform?.();

async function tryServer(path: string, body: unknown, timeoutMs = 9000): Promise<any | null> {
  if (isNative() && !hasRemoteApi()) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(apiUrl(path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function processVoiceCommand(body: {
  speechText: string;
  referenceDate: string;
  categories?: string[];
}): Promise<any> {
  const data = await tryServer('/api/ai/process-voice-command', body);
  if (data && data.success) return data;
  return {
    success: true,
    isFallback: true,
    rawText: body.speechText,
    ...parseVoiceCommandRuleBased(body.speechText, body.referenceDate),
  };
}

export async function extractTasks(body: any): Promise<any> {
  const data = await tryServer('/api/ai/extract-tasks', body, 20000);
  if (data && Array.isArray(data.tasks)) return data;
  if (body.imageBase64 || body.pdfBase64) {
    throw new Error('قراءة الصور وملفات PDF تحتاج اتصالاً بخادم الذكاء الاصطناعي وهو غير متاح الآن. اكتب جدولك كنص وسأفهمه مباشرة.');
  }
  return {
    success: true,
    isFallback: true,
    tasks: extractTasksRuleBased(body.promptText, body.referenceDate),
  };
}

export async function splitTopics(body: any): Promise<any> {
  const data = await tryServer('/api/ai/split-topics', body, 30000);
  if (data && Array.isArray(data.topics)) return data;
  const text: string = (body.contentText || '').trim();
  if (!text) {
    throw new Error('تقسيم ملفات PDF يحتاج اتصالاً بخادم الذكاء الاصطناعي. الصق نص المحاضرة بدلاً من الملف وسأقسمه تلقائياً.');
  }
  const min = body.minDuration || 20;
  const max = body.maxDuration || 40;
  const chunks = text
    .split(/\n\s*\n|\n(?=\s*(?:\d+[.)\-]|[•\-*]|الفصل|الباب|الدرس|Chapter|Section))/i)
    .map((c) => c.trim())
    .filter((c) => c.length >= 12)
    .slice(0, 40);
  const topics = chunks.map((chunk, i) => ({
    title: chunk.split('\n')[0].replace(/^[\d\s.)\-•*]+/, '').slice(0, 70) || `الجزء ${i + 1}`,
    estimatedMinutes: Math.min(max, Math.max(min, Math.round(chunk.length / 35))),
    sequenceOrder: i + 1,
    description: 'تم التقسيم تلقائياً على جهازك',
  }));
  if (topics.length === 0) throw new Error('لم أستطع تقسيم النص، جرّب نصاً أطول بفقرات منفصلة.');
  return { success: true, isFallback: true, topics };
}
