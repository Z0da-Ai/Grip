/**
 * Where the AI server lives.
 * - In the browser / AI Studio: empty string, so '/api/...' hits the same server.
 * - In the Android app (Capacitor) there is no server inside the phone, so build with
 *   VITE_API_URL=https://your-server.example to point the app at your deployed server.
 */
const BASE = ((import.meta as any).env?.VITE_API_URL as string | undefined)?.replace(/\/$/, '') || '';

export const apiUrl = (path: string) => `${BASE}${path}`;

/** True when the app was built with a real AI server address. */
export const hasRemoteApi = () => BASE !== '';
