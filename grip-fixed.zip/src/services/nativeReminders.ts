/**
 * Reliable reminders inside the Android app.
 * Web notifications stop when the app is closed; native local notifications are scheduled
 * with the system alarm so they still ring. Does nothing in a normal browser.
 */
import { GripTask } from '../types/grip';

const plugin = () => (window as any).Capacitor?.Plugins?.LocalNotifications;
const isNative = () => !!(window as any).Capacitor?.isNativePlatform?.();

const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h) % 2000000000;
};

let permissionAsked = false;

export async function syncNativeReminders(tasks: GripTask[]): Promise<void> {
  if (!isNative()) return;
  const ln = plugin();
  if (!ln) return;
  try {
    if (!permissionAsked) {
      permissionAsked = true;
      const p = await ln.requestPermissions();
      if (p?.display && p.display !== 'granted') return;
    }

    const pending = await ln.getPending?.();
    if (pending?.notifications?.length) await ln.cancel({ notifications: pending.notifications });

    const now = Date.now();
    const horizon = now + 7 * 86400000;
    const notifications: any[] = [];
    for (const t of tasks) {
      if (t.status === 'done' || t.status === 'done_early' || t.status === 'missed') continue;
      const start = new Date(t.startTime).getTime();
      if (isNaN(start) || start <= now || start > horizon) continue;
      const isAlarm = t.isWakeUpAlarm || t.category === 'wake_up';
      notifications.push({
        id: hash(t.id + ':start'),
        title: isAlarm ? 'صحّيني ⏰' : 'وقت المهمة',
        body: t.title,
        schedule: { at: new Date(start), allowWhileIdle: true },
        channelId: 'grip-tasks',
      });
      if (t.type === 'FIXED' && !isAlarm && start - 15 * 60000 > now) {
        notifications.push({
          id: hash(t.id + ':pre'),
          title: 'بعد 15 دقيقة',
          body: t.title,
          schedule: { at: new Date(start - 15 * 60000), allowWhileIdle: true },
          channelId: 'grip-tasks',
        });
      }
    }
    notifications.sort((a, b) => a.schedule.at.getTime() - b.schedule.at.getTime());
    const limited = notifications.slice(0, 60);
    if (limited.length) {
      await ln.createChannel?.({ id: 'grip-tasks', name: 'تنبيهات المهام', importance: 5, vibration: true });
      await ln.schedule({ notifications: limited });
    }
  } catch {
    // Reminders are best-effort; never break the app because of them.
  }
}
