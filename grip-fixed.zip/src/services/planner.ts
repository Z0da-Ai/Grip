import { GripTask } from '../types/grip';

interface Interval { s: number; e: number }

const DAY_START_H = 8;
const DAY_END_H = 22;
const BUFFER_MIN = 15;

function busyOn(tasks: GripTask[], day: Date): Interval[] {
  const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate()).getTime();
  const dayEnd = dayStart + 86400000;
  return tasks
    .filter((t) => t.status !== 'missed')
    .map((t) => ({ s: new Date(t.startTime).getTime(), e: new Date(t.endTime).getTime() }))
    .filter((i) => !isNaN(i.s) && !isNaN(i.e) && i.e > dayStart && i.s < dayEnd)
    .sort((a, b) => a.s - b.s);
}

/**
 * Finds the earliest free slot of `minutes` on `day` (or the next days) that does not
 * overlap any existing task. Prefers slots starting after `preferAfter`, then falls back
 * to any free time that day (e.g. before the event).
 */
export function findFreeSlot(
  tasks: GripTask[],
  day: Date,
  minutes: number,
  preferAfter?: Date,
  now: Date = new Date()
): { start: Date; end: Date } | null {
  const need = minutes * 60000;
  for (let offset = 0; offset < 4; offset++) {
    const d = new Date(day.getFullYear(), day.getMonth(), day.getDate() + offset);
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), DAY_START_H).getTime();
    const dayEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate(), DAY_END_H).getTime();
    let from = dayStart;
    if (d.toDateString() === now.toDateString()) from = Math.max(from, Math.ceil((now.getTime() + 10 * 60000) / (15 * 60000)) * 15 * 60000);
    const busy = busyOn(tasks, d);

    const search = (lowerBound: number): { start: Date; end: Date } | null => {
      let cursor = Math.max(from, lowerBound);
      for (const b of busy) {
        if (b.e + BUFFER_MIN * 60000 <= cursor) continue;
        if (cursor + need + BUFFER_MIN * 60000 <= b.s) break;
        cursor = Math.max(cursor, b.e + BUFFER_MIN * 60000);
      }
      if (cursor + need <= dayEnd) return { start: new Date(cursor), end: new Date(cursor + need) };
      return null;
    };

    if (offset === 0 && preferAfter) {
      const after = search(preferAfter.getTime() + 30 * 60000);
      if (after) return after;
    }
    const any = search(dayStart);
    if (any) return any;
  }
  return null;
}
