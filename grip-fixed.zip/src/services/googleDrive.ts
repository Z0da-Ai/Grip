/**
 * Optional Google Drive backup (browser / installed web app).
 * Uses Google Identity Services + the private "appDataFolder" of the user's own Drive:
 * the file is invisible in their Drive UI, only Grip can read it, and we get no other access.
 * Needs VITE_GOOGLE_CLIENT_ID (a free OAuth Web client ID from Google Cloud Console).
 */
const CLIENT_ID = ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string | undefined) || '';
const SCOPE = 'https://www.googleapis.com/auth/drive.appdata';
const FILE_NAME = 'grip-backup.json';

const isNative = () => !!(window as any).Capacitor?.isNativePlatform?.();

/** The Drive section is shown only when it can really work. */
export const isDriveAvailable = () => CLIENT_ID !== '' && !isNative();

let gisLoading: Promise<void> | null = null;
function loadGis(): Promise<void> {
  if ((window as any).google?.accounts?.oauth2) return Promise.resolve();
  if (gisLoading) return gisLoading;
  gisLoading = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      gisLoading = null;
      reject(new Error('تعذر الاتصال بخدمة جوجل. تأكد من الإنترنت.'));
    };
    document.head.appendChild(s);
  });
  return gisLoading;
}

let accessToken = '';
let expiresAt = 0;
let pending: { resolve: (t: string) => void; reject: (e: Error) => void } | null = null;
let tokenClient: any = null;

async function getToken(): Promise<string> {
  if (accessToken && Date.now() < expiresAt) return accessToken;
  await loadGis();
  return new Promise<string>((resolve, reject) => {
    pending = { resolve, reject };
    if (!tokenClient) {
      tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPE,
        callback: (r: any) => {
          if (r.error || !r.access_token) {
            pending?.reject(new Error('لم يتم السماح بالوصول إلى Drive.'));
          } else {
            accessToken = r.access_token;
            expiresAt = Date.now() + (Number(r.expires_in) || 3000) * 1000 - 60000;
            pending?.resolve(accessToken);
          }
          pending = null;
        },
        error_callback: () => {
          pending?.reject(new Error('تم إغلاق نافذة تسجيل الدخول.'));
          pending = null;
        },
      });
    }
    tokenClient.requestAccessToken({ prompt: accessToken ? '' : 'consent' });
  });
}

async function findBackupFile(token: string): Promise<{ id: string; modifiedTime: string } | null> {
  const q = encodeURIComponent(`name='${FILE_NAME}'`);
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,modifiedTime)&pageSize=1`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw new Error('تعذر الوصول إلى Drive.');
  const data = await res.json();
  return data.files && data.files[0] ? data.files[0] : null;
}

export async function backupToDrive(json: string): Promise<string> {
  const token = await getToken();
  const existing = await findBackupFile(token);
  let res: Response;
  if (existing) {
    res = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${existing.id}?uploadType=media`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: json,
    });
  } else {
    const boundary = 'grip' + Math.random().toString(36).slice(2);
    const body =
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` +
      JSON.stringify({ name: FILE_NAME, parents: ['appDataFolder'] }) +
      `\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${json}\r\n--${boundary}--`;
    res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': `multipart/related; boundary=${boundary}` },
      body,
    });
  }
  if (!res.ok) throw new Error('فشل رفع النسخة إلى Drive.');
  return new Date().toISOString();
}

export async function restoreFromDrive(): Promise<string | null> {
  const token = await getToken();
  const file = await findBackupFile(token);
  if (!file) return null;
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error('تعذر تنزيل النسخة من Drive.');
  return await res.text();
}
