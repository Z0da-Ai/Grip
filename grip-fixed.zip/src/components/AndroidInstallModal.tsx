import React, { useState } from 'react';
import { Smartphone, Download, CheckCircle2, X, MoreVertical, PlusSquare, ShieldCheck } from 'lucide-react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  deferredPrompt: any;
  onInstallSuccess?: () => void;
  onOpenAndroidCode?: () => void;
}

/** Simple, user-facing "install Grip on your phone" sheet. No developer or store details. */
export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  onInstallSuccess,
}) => {
  const [done, setDone] = useState(false);

  if (!isOpen) return null;

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    try {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice?.outcome === 'accepted') {
        setDone(true);
        onInstallSuccess?.();
      }
    } catch {
      // The browser refused; the manual steps below still work.
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-700"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#6D28D9] flex items-center justify-center text-white">
              <Smartphone className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-black">ثبّت Grip على هاتفك</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق"
            className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {done ? (
          <div className="flex flex-col items-center gap-2 py-6 text-center">
            <CheckCircle2 className="w-12 h-12 text-emerald-500" />
            <p className="font-black">تم التثبيت! افتح Grip من الشاشة الرئيسية.</p>
          </div>
        ) : (
          <>
            {deferredPrompt && (
              <button
                onClick={handleInstall}
                className="w-full py-3.5 mb-4 rounded-2xl bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-black flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                <span>تثبيت الآن</span>
              </button>
            )}

            <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-3">
              {deferredPrompt ? 'أو يدوياً من متصفح Chrome:' : 'من متصفح Chrome على هاتفك:'}
            </p>
            <ol className="space-y-3 text-sm font-semibold">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 shrink-0 rounded-full bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 flex items-center justify-center text-xs font-black">1</span>
                <span className="flex items-center gap-1.5 flex-wrap">
                  اضغط على قائمة المتصفح <MoreVertical className="w-4 h-4 inline" /> أعلى الشاشة
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 shrink-0 rounded-full bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 flex items-center justify-center text-xs font-black">2</span>
                <span className="flex items-center gap-1.5 flex-wrap">
                  اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية» <PlusSquare className="w-4 h-4 inline" />
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 shrink-0 rounded-full bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 flex items-center justify-center text-xs font-black">3</span>
                <span>افتح Grip من أيقونته على الشاشة الرئيسية.</span>
              </li>
            </ol>

            <div className="mt-5 flex items-start gap-2 text-[11px] font-semibold text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-500 mt-0.5" />
              <span>بياناتك تبقى على جهازك فقط، والتطبيق يعمل بدون إنترنت.</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
