import { parseVoiceCommandRuleBased as p, extractTasksRuleBased as e } from '../src/shared/ruleBased';
const ref='2026-10-25'; // Sunday
const tests=[
 'ذاكر فيزياء بكرة الساعة 5 العصر','ضيف مصروف 50 جنيه أكل','صرفت 120 على مواصلات','فكرني أشرب مية','صحيني الساعة 7 الصبح',
 'عندي محاضرة رياضة الأحد الساعة 10','مذاكرة كيمياء بعد بكرة من 4 لـ 6 المغرب','اشتريت قهوة بـ 35','نويت أخلص التقرير النهارده',
 'تمرين جيم الساعة 6 مساء','صرفت خمسين جنيه على غدا','شربت كوباية مية','ضيف اجتماع شغل الخميس الساعة 2 الضهر لمدة ساعة ونص',
 'صحيني 6 ونص','اروح الدكتور الساعة 8 مساء','ذاكر أحياء الساعة ٩ صباحا','اشتريت كتاب بـ 200 جنيه',
];
for(const t of tests){
  const r:any=p(t,ref);
  const task=r.data?.task;
  console.log('•',t,'\n   ->',r.intent,'|',r.summary, task? '| '+task.startTime.slice(0,16)+'→'+task.endTime.slice(11,16)+' '+task.category+' '+task.type : '');
}
console.log('--- schedule text');
for (const t of ['محاضرة فيزياء الاثنين 9 ص\nمحاضرة كيمياء الثلاثاء 11 ص\nمذاكرة رياضيات الأربعاء 4 م','اجتماع مع العميل يوم الجمعة الساعة 3 العصر','محاضرة الكتروميكانيكا الاحد من 8 ل 10']) {
  for (const x of e(t,ref)) console.log(' ',x.title,'|',x.startTime.slice(0,16),'→',x.endTime.slice(11,16),x.category,x.type);
}
