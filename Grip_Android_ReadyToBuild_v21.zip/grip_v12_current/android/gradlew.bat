@echo off
setlocal EnableExtensions
rem Grip Gradle bootstrapper for Windows. Requires PowerShell and Java 17+.
set "GRIP_GRADLE_HOME=%USERPROFILE%\.gradle-dist\gradle-8.13"
if exist "%GRIP_GRADLE_HOME%\bin\gradle.bat" goto run_gradle
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  for /f "tokens=2" %%V in ('gradle --version ^| findstr /R /C:"^Gradle 8\.13$"') do set "GRIP_SYSTEM_GRADLE=%%V"
  if defined GRIP_SYSTEM_GRADLE (
    gradle %*
    exit /b %ERRORLEVEL%
  )
)
set "GRIP_GRADLE_ZIP=%USERPROFILE%\.gradle-dist\gradle-8.13-bin.zip"
if not exist "%USERPROFILE%\.gradle-dist" mkdir "%USERPROFILE%\.gradle-dist"
if exist "%GRIP_GRADLE_ZIP%" goto extract_gradle
echo Downloading Gradle 8.13. Internet access is required for the first build.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile '%GRIP_GRADLE_ZIP%'"
if errorlevel 1 (
  echo ERROR: Could not download Gradle. Check internet access and try again.
  exit /b 1
)
:extract_gradle
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%GRIP_GRADLE_ZIP%' -DestinationPath '%USERPROFILE%\.gradle-dist' -Force"
if errorlevel 1 (
  echo ERROR: Could not extract Gradle.
  exit /b 1
)
:run_gradle
call "%GRIP_GRADLE_HOME%\bin\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
