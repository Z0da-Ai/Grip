#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Android SDK not found. Install Android Studio / SDK Platform 36 first." >&2
  exit 2
fi
if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 17+ not found." >&2
  exit 2
fi
chmod +x ./gradlew
./gradlew --no-daemon clean :app:assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
echo "APK created: $PWD/$APK"
