package com.grip.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionStepsTest {

    private val all = GripPermission.values().toSet()

    @Test
    fun `nothing granted nothing skipped asks in display order`() {
        assertEquals(
            listOf(
                GripPermission.NOTIFICATIONS,
                GripPermission.EXACT_ALARMS,
                GripPermission.OVERLAY,
                GripPermission.DND
            ),
            PermissionSteps.pending(emptySet(), emptySet())
        )
    }

    @Test
    fun `granted and skipped permissions are not asked again`() {
        val pending = PermissionSteps.pending(
            granted = setOf(GripPermission.NOTIFICATIONS),
            skipped = setOf(GripPermission.OVERLAY)
        )
        assertEquals(listOf(GripPermission.EXACT_ALARMS, GripPermission.DND), pending)
    }

    @Test
    fun `everything granted shows neither wizard nor banner`() {
        assertTrue(PermissionSteps.pending(all, emptySet()).isEmpty())
        assertFalse(PermissionSteps.needsBanner(all, emptySet()))
    }

    @Test
    fun `skipping a core permission leaves a reminder banner instead of trapping the user`() {
        val granted = setOf(GripPermission.NOTIFICATIONS, GripPermission.EXACT_ALARMS)
        val skipped = setOf(GripPermission.OVERLAY, GripPermission.DND)
        assertTrue(PermissionSteps.pending(granted, skipped).isEmpty())
        assertTrue(PermissionSteps.needsBanner(granted, skipped))
        assertEquals(listOf(GripPermission.OVERLAY), PermissionSteps.missingCore(granted))
    }

    @Test
    fun `skipping only the optional DND permission needs no banner`() {
        val granted = setOf(
            GripPermission.NOTIFICATIONS,
            GripPermission.EXACT_ALARMS,
            GripPermission.OVERLAY
        )
        assertFalse(PermissionSteps.needsBanner(granted, setOf(GripPermission.DND)))
    }

    @Test
    fun `a skipped permission that is later granted is simply granted`() {
        val skipped = setOf(GripPermission.OVERLAY)
        assertTrue(PermissionSteps.pending(all, skipped).isEmpty())
        assertFalse(PermissionSteps.needsBanner(all, skipped))
    }

    @Test
    fun `only DND is optional`() {
        assertEquals(listOf(GripPermission.DND), GripPermission.values().filterNot { it.isCore })
    }
}
