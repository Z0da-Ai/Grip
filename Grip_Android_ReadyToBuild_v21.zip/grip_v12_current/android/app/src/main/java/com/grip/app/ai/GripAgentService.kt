package com.grip.app.ai

import android.content.Context
import com.grip.app.budget.BudgetDb
import com.grip.app.budget.ExpenseEntity
import com.grip.app.data.local.AppDatabase
import com.grip.app.data.local.entity.TaskCategory
import com.grip.app.data.local.entity.TaskEntity
import com.grip.app.data.local.entity.TaskStatus
import com.grip.app.data.local.entity.TaskType
import com.grip.app.util.GripAlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import java.util.UUID

/** Deterministic, permission-bounded action layer. The LLM never writes directly to storage. */
class GripAgentService(context: Context) {
    private val app = context.applicationContext
    private val tasks = AppDatabase.getInstance(app).taskDao()
    private val budgets = BudgetDb.get(app).dao()

    sealed interface Plan {
        val preview: String
        data object ListTasks : Plan { override val preview = "عرض المهام المفتوحة" }
        data object BuildSchedule : Plan { override val preview = "عرض جدولك الحالي وترتيبه حسب الوقت" }
        data object BudgetSummary : Plan { override val preview = "عرض ملخص الميزانية والمصاريف" }
        data class CreateTask(val title: String, val category: TaskCategory, val start: Long, val end: Long) : Plan {
            override val preview: String = "إضافة مهمة: $title\n${java.time.Instant.ofEpochMilli(start).atZone(ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("EEE d/M - hh:mm a", Locale("ar", "EG")))}"
        }
        data class CompleteTask(val task: TaskEntity) : Plan { override val preview = "إنجاز المهمة: ${task.title}" }
        data class AddExpense(val amountMinor: Long, val note: String) : Plan { override val preview = "تسجيل مصروف ${amountMinor / 100.0} — $note" }
        data class NeedClarification(override val preview: String) : Plan
        data object NoAction : Plan { override val preview = "" }
    }

    suspend fun propose(request: String): Plan = withContext(Dispatchers.IO) {
        val raw = request.trim()
        require(raw.isNotBlank()) { "اكتب طلبك الأول." }
        val text = normalize(raw)
        if (containsAny(text, "اعرض مهامي", "وريني مهامي", "المهام عندي", "قائمة المهام", "show my tasks", "list tasks")) return@withContext Plan.ListTasks
        if (containsAny(text, "رتب يومي", "جدول اليوم", "الجدول بتاعي", "خطط يومي", "نظم يومي", "organize my day", "my schedule")) return@withContext Plan.BuildSchedule
        if (containsAny(text, "ملخص الميزانية", "فاضل كام", "مصروفاتي", "ميزانيتي", "budget summary", "how much left")) return@withContext Plan.BudgetSummary

        if (containsAny(text, "مصروف", "دفعت", "اشتريت", "expense", "spent")) {
            // Prefer an amount adjacent to an expense verb; otherwise use the first numeric token.
            // The normalized string also converts Arabic-Indic digits before numeric parsing.
            // Accept ordinary decimals (75.50 / 75,50) and grouped thousands (1,200 / 1,200.50).
            val amountPattern = "(\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)"
            // Prefer the amount tied to currency or an explicit "بـ 120" expression.
            // This avoids interpreting "اشتريت 3 كتب بـ120 جنيه" as a 3-pound expense.
            val currencyAmount = Regex("$amountPattern\\s*(?:جنيه(?:ات|اً|ا)?|egp|le)(?:\\s|[،,؛.!؟]|$)", RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.get(1)
            val prepositionAmount = Regex("(?:ب|بـ|بمبلغ)\\s*[:：]?\\s*$amountPattern", RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.get(1)
            val verbAmount = Regex("(?:مصروف|دفعت|اشتريت|صرف(?:ت)?|spent|expense)\\s*[:：]?\\s*$amountPattern", RegexOption.IGNORE_CASE)
                .find(text)?.groupValues?.get(1)
            val amountToken = currencyAmount ?: prepositionAmount ?: verbAmount ?: Regex("(?<!\\d)$amountPattern(?!\\d)").find(text)?.groupValues?.get(1)
            val amountText = amountToken?.let { token ->
                if (Regex(",\\d{3}(?:\\.|$)").containsMatchIn(token)) token.replace(",", "") else token.replace(',', '.')
            }
            val amount = amountText?.toBigDecimalOrNull()
            if (amount == null || amount <= BigDecimal.ZERO || amount > BigDecimal("100000000")) return@withContext Plan.NeedClarification("اكتب مبلغًا موجبًا وواضحًا، مثال: سجل مصروف 75 جنيه مواصلات.")
            val amountMinor = try { amount.movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact() } catch (_: ArithmeticException) {
                return@withContext Plan.NeedClarification("المبلغ كبير جدًا أو غير صالح. اكتب مبلغًا أصغر بصيغة واضحة.")
            }
            val normalizedRaw = normalize(raw)
            val note = normalizedRaw.replace(Regex("(?i)(سجل|ضيف|اضف|مصروف|دفعت|اشتريت|صرف(?:ت)?|expense|spent|جنيه|جنيهات|egp|le)"), " ")
                .replace(Regex("\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?"), " ").trim().ifBlank { "مصروف من Grip Smart" }
            val budget = budgets.getCurrentBudget()
            if (budget == null) return@withContext Plan.NeedClarification("لسه مفيش ميزانية نشطة. أنشئ ميزانية من قسم المصاريف أولًا، وبعدها أقدر أسجل المصروف.")
            return@withContext Plan.AddExpense(amountMinor, note)
        }

        if (containsAny(text, "خلصت", "انجزت", "تمت", "complete task", "finish task", "mark done")) {
            val query = normalize(raw)
                .replace(Regex("(?i)(خلصت|انجزت|تمت|المهمه|مهمه|انا|complete task|finish task|mark done)"), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (query.isBlank()) return@withContext Plan.NeedClarification("اكتب اسم المهمة اللي خلصتها عشان ما أعلّمش مهمة غلط.")
            // Compare normalized titles in memory so Arabic hamza/diacritics and SQL LIKE
            // wildcard characters in user text cannot cause false matches.
            val normalizedQuery = normalize(query)
            val matches = tasks.getOpenTasks().filter { task ->
                val title = normalize(task.title)
                title.contains(normalizedQuery) || normalizedQuery.contains(title) && title.length >= 3
            }.take(5)
            return@withContext when (matches.size) {
                0 -> Plan.NeedClarification("مش لاقي مهمة مفتوحة بالاسم ده. اكتب جزءًا أوضح من اسمها.")
                1 -> Plan.CompleteTask(matches.first())
                else -> Plan.NeedClarification("لقيت أكتر من مهمة مشابهة: ${matches.joinToString("، ") { it.title }}. اكتب الاسم بشكل أدق.")
            }
        }

        if (containsAny(text, "ضيف مهمة", "اضف مهمة", "سجل مهمة", "فكرني", "ذكرني", "اعمل تاسك", "add task", "remind me", "create task")) {
            // Keep the user's original spelling/capitalization in the saved title; normalize only for matching.
            val title = raw.trim()
                .replace(Regex("(?i)(ضيف|أضف|اضف|سجل|اعمل|مهمة|تاسك|فكرني|ذكرني|add task|create task|remind me)"), " ")
                .replace(Regex("(?i)(بكره|بكرة|غدا|غدًا|النهارده|النهاردة|اليوم|tomorrow|today)"), " ")
                .replace(Regex("(?i)(الساعة|الساعه)\\s*\\d{1,2}(?::\\d{2})?\\s*(صباحا|صباحاً|مساء|مساءً|am|pm)?"), " ")
                .replace(Regex("(?i)(?<!\\d)\\d{1,2}(?::\\d{2})?\\s*(صباحا|صباحاً|مساء|مساءً|am|pm)(?!\\w)"), " ")
                .replace(Regex("\\s+"), " ").trim().trim(':','-','،',' ')
            if (title.length < 2) return@withContext Plan.NeedClarification("اكتب اسم المهمة، مثال: ضيف مهمة مذاكرة الفارما الساعة 7 مساءً.")
            val now = LocalDateTime.now()
            val date = when {
                text.contains("بكره") || text.contains("بكرة") || text.contains("غدا") || text.contains("tomorrow") -> now.toLocalDate().plusDays(1)
                else -> now.toLocalDate()
            }
            // Do not mistake numbers in a task title (e.g. "3 محاضرات") for a clock time.
            val explicitTimePattern = Regex("(?:الساعة|الساعه)\\s*(\\d{1,2})(?::(\\d{2}))?\\s*(صباحا|صباحاً|مساء|مساءً|am|pm)?")
            val meridiemTimePattern = Regex("(?<!\\d)(\\d{1,2})(?::(\\d{2}))?\\s*(صباحا|صباحاً|مساء|مساءً|am|pm)")
            val timeMatch = explicitTimePattern.find(text) ?: meridiemTimePattern.find(text)
            val time = if (timeMatch != null) {
                var hour = timeMatch.groupValues[1].toIntOrNull() ?: return@withContext Plan.NeedClarification("الوقت مش واضح. استخدم صيغة زي 7:30 مساءً.")
                val minute = timeMatch.groupValues[2].toIntOrNull() ?: 0
                val meridiem = timeMatch.groupValues.getOrNull(3).orEmpty()
                if (minute !in 0..59 || (meridiem.isNotBlank() && hour !in 1..12) || (meridiem.isBlank() && hour !in 0..23)) return@withContext Plan.NeedClarification("الوقت مش واضح. استخدم صيغة زي 7:30 مساءً.")
                if ((meridiem.contains("مساء") || meridiem.equals("pm", true)) && hour < 12) hour += 12
                if ((meridiem.contains("صباح") || meridiem.equals("am", true)) && hour == 12) hour = 0
                LocalTime.of(hour, minute)
            } else now.toLocalTime().plusHours(1).withMinute(0).withSecond(0).withNano(0)
            val requestedStart = LocalDateTime.of(date, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            if (requestedStart < System.currentTimeMillis() && (timeMatch != null || date != now.toLocalDate())) {
                return@withContext Plan.NeedClarification("الوقت اللي حددته عدى بالفعل. حدّد وقتًا مستقبليًا أو اكتب «بكرة» مع الساعة.")
            }
            val start = if (requestedStart < System.currentTimeMillis()) LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() else requestedStart
            val category = when {
                containsAny(text, "مذاكرة", "محاضرة", "كلية", "study", "lecture") -> TaskCategory.STUDY
                containsAny(text, "جيم", "تمرين", "رياضة", "gym", "workout") -> TaskCategory.SPORT
                containsAny(text, "شغل", "عمل", "work") -> TaskCategory.WORK
                containsAny(text, "نوم", "sleep") -> TaskCategory.SLEEP
                else -> TaskCategory.PERSONAL
            }
            return@withContext Plan.CreateTask(title, category, start, start + 60 * 60_000L)
        }
        Plan.NoAction
    }

    suspend fun execute(plan: Plan): String = withContext(Dispatchers.IO) {
        when (plan) {
            Plan.ListTasks, Plan.BuildSchedule -> {
                val all = tasks.getOpenTasks()
                val todayStart = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val tomorrowStart = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val open = if (plan == Plan.BuildSchedule) all.filter { it.startTimeEpochMs in todayStart until tomorrowStart } else all
                if (open.isEmpty()) if (plan == Plan.BuildSchedule) "مفيش مهام مفتوحة مسجلة لليوم. أضف مهامك الأول، وبعدها أقدر أعرضها مرتبة حسب الوقت." else "مفيش مهام مفتوحة حاليًا." else open.take(20).joinToString("\n") { task ->
                    val time = java.time.Instant.ofEpochMilli(task.startTimeEpochMs).atZone(ZoneId.systemDefault())
                        .format(java.time.format.DateTimeFormatter.ofPattern("EEE d/M hh:mm a", Locale("ar", "EG")))
                    "• ${task.title} — $time${if (plan == Plan.BuildSchedule) " (${task.category.name})" else ""}"
                }
            }
            Plan.BudgetSummary -> {
                val budget = budgets.getCurrentBudget() ?: return@withContext "لسه مفيش ميزانية نشطة. أنشئ ميزانية من قسم المصاريف أولًا."
                val expenses = budgets.getExpenses(budget.id)
                val todayStart = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val spent = expenses.sumOf { it.amountMinor }
                val todaySpent = expenses.filter { it.createdAt >= todayStart }.sumOf { it.amountMinor }
                val remaining = budget.totalMinor - spent
                "ميزانية «${budget.name}»: ${budget.totalMinor / 100.0} ${budget.currency}\nإجمالي المصروفات: ${spent / 100.0} ${budget.currency}\nالمتبقي الحسابي: ${remaining / 100.0} ${budget.currency}\nمصروفات اليوم: ${todaySpent / 100.0} ${budget.currency}\nملاحظة: الأرقام محسوبة من المصروفات المسجلة داخل Grip فقط."
            }
            is Plan.CreateTask -> {
                val task = TaskEntity(UUID.randomUUID().toString(), plan.title, plan.category, plan.start, plan.end, TaskType.FLEXIBLE)
                tasks.insertTask(task)
                val saved = tasks.getTaskById(task.id)
                    ?: return@withContext "ماقدرتش أتحقق من حفظ المهمة؛ افتح قائمة المهام وتأكد قبل إعادة المحاولة."
                if (saved.title != task.title || saved.startTimeEpochMs != task.startTimeEpochMs || saved.endTimeEpochMs != task.endTimeEpochMs) {
                    return@withContext "المهمة موجودة لكن بياناتها لا تطابق الطلب الأصلي. افتح قائمة المهام وراجعها قبل إعادة المحاولة."
                }
                var alarmScheduled = true
                try { GripAlarmScheduler.scheduleExactTaskAlarm(app, saved) } catch (_: Exception) { alarmScheduled = false }
                if (tasks.getTaskById(task.id) == null) return@withContext "المهمة لم تعد موجودة بعد الحفظ؛ راجع قائمة المهام."
                if (alarmScheduled) "اتحفظت المهمة «${task.title}» على الجهاز، وتم طلب جدولة تنبيهها. تأكد من سماح Android بالإشعارات والمنبّهات."
                else "اتحفظت المهمة «${task.title}»، لكن تعذرت جدولة التنبيه. راجع صلاحيات المنبّهات في إعدادات Android."
            }
            is Plan.CompleteTask -> {
                tasks.markTaskComplete(plan.task.id, TaskStatus.DONE, System.currentTimeMillis())
                val updated = tasks.getTaskById(plan.task.id)
                if (updated?.status != TaskStatus.DONE) return@withContext "لم أستطع تأكيد تحديث حالة المهمة. افتح قائمة المهام وتحقق منها قبل إعادة المحاولة."
                GripAlarmScheduler.cancel(app, plan.task.id)
                "تم التحقق من تعليم «${plan.task.title}» كمهمة منجزة."
            }
            is Plan.AddExpense -> {
                val budget = budgets.getCurrentBudget() ?: return@withContext "مفيش ميزانية نشطة؛ المصروف لم يُسجّل."
                val category = budgets.getCategories(budget.id).firstOrNull { candidate ->
                    val categoryName = normalize(candidate.name)
                    val note = normalize(plan.note)
                    categoryName.isNotBlank() && note.isNotBlank() && (note.contains(categoryName) || categoryName.contains(note))
                }
                val expenseId = budgets.insertExpense(ExpenseEntity(budgetId = budget.id, categoryId = category?.id, amountMinor = plan.amountMinor, note = plan.note))
                val verified = budgets.getExpenses(budget.id).any { it.id == expenseId && it.amountMinor == plan.amountMinor }
                if (!verified) return@withContext "لم أستطع التحقق من حفظ المصروف. راجع سجل المصروفات قبل إعادة المحاولة."
                val categoryText = category?.name ?: "أخرى"
                "تم التحقق من تسجيل المصروف ${"%.2f".format(Locale.US, plan.amountMinor / 100.0)} ${budget.currency} تحت «${plan.note}» — التصنيف: $categoryText."
            }
            is Plan.NeedClarification -> plan.preview
            Plan.NoAction -> "مفيش إجراء تلقائي آمن اتعرف من الطلب. أقدر حاليًا أضيف مهمة، أعرض المهام أو جدول اليوم، أعلّم مهمة منجزة، وأسجل مصروفًا أو أعرض ملخص الميزانية عند وجود ميزانية نشطة."
        }
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي')
        .map { ch -> when (ch) { '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'; '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'; else -> ch } }.joinToString("")
    private fun containsAny(value: String, vararg phrases: String): Boolean = phrases.any { normalize(value).contains(normalize(it)) }
}
