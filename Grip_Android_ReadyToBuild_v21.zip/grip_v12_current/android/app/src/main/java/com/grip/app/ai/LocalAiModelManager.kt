package com.grip.app.ai

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.database.Cursor
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/** Downloads the quantized Qwen3-1.7B LiteRT-LM artifact only after the user opts in. */
object LocalAiModelManager {
    const val MODEL_FILE = "Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm"
    const val MODEL_SIZE_LABEL = "حوالي 932 ميجابايت"
    private const val PREFS = "grip_local_ai"
    private const val KEY_DOWNLOAD_ID = "qwen3_download_id"
    private const val MODEL_URL = "https://huggingface.co/litert-community/Qwen3-1.7B/resolve/main/Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm?download=true"
    private const val EXPECTED_SHA256 = "2eeffef7b51bc3e1225ea69fe7aa5f417397934b56a5b6c20cc068d6fd2c918b"
    private const val MIN_MODEL_BYTES = 900_000_000L

    data class DownloadState(
        val status: Int,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val reason: Int = 0,
    ) {
        val percent: Int
            get() = if (totalBytes > 0L) ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100) else 0
    }

    fun modelFile(context: Context): File {
        val directory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "models")
        if (!directory.exists()) directory.mkdirs()
        return File(directory, MODEL_FILE)
    }

    fun isModelPresent(context: Context): Boolean {
        val file = modelFile(context)
        return file.isFile && file.length() >= MIN_MODEL_BYTES
    }

    fun savedDownloadId(context: Context): Long? {
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_DOWNLOAD_ID, -1L)
        return id.takeIf { it > 0L }
    }

    fun startDownload(context: Context): Long {
        val destination = modelFile(context)
        if (destination.exists() && destination.length() < MIN_MODEL_BYTES) destination.delete()
        val request = DownloadManager.Request(Uri.parse(MODEL_URL))
            .setTitle("Grip AI — Qwen3")
            .setDescription("تنزيل نموذج الذكاء الاصطناعي المحلي؛ لن يحتاج إلى Gemini بعد التنزيل")
            .setMimeType("application/octet-stream")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, MODEL_FILE)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val id = manager.enqueue(request)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_DOWNLOAD_ID, id).apply()
        return id
    }

    fun queryDownload(context: Context, id: Long): DownloadState? {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor: Cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return null
        cursor.use {
            if (!it.moveToFirst()) return null
            fun longColumn(name: String): Long {
                val index = it.getColumnIndex(name)
                return if (index >= 0) it.getLong(index) else 0L
            }
            return DownloadState(
                status = longColumn(DownloadManager.COLUMN_STATUS).toInt(),
                downloadedBytes = longColumn(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR),
                totalBytes = longColumn(DownloadManager.COLUMN_TOTAL_SIZE_BYTES),
                reason = longColumn(DownloadManager.COLUMN_REASON).toInt(),
            )
        }
    }

    /** Verify the downloaded artifact before passing it to the native inference runtime. */
    fun verifyModel(context: Context): Boolean {
        val file = modelFile(context)
        if (!file.isFile || file.length() < MIN_MODEL_BYTES) return false
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        return actual.equals(EXPECTED_SHA256, ignoreCase = true)
    }

    fun clearDownloadId(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_DOWNLOAD_ID).apply()
    }
}
