package com.grip.app.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.provider.Settings
import android.view.*
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.grip.app.R
import com.grip.app.data.local.AppDatabase
import com.grip.app.data.local.entity.TaskEntity
import com.grip.app.ui.components.EnforcementOverlayCompose
import com.grip.app.data.local.entity.TaskStatus
import com.grip.app.util.GripAlarmScheduler
import com.grip.app.util.OverlayLifecycleOwner
import kotlinx.coroutines.*

/**
 * EnforcementOverlayService
 * The heart of Grip:
 * - Runs as a Foreground Service with persistent notification
 * - Mounts a SYSTEM_ALERT_WINDOW full screen overlay
 * - Escalating continuous press-and-hold (10s -> 20s -> 30s cap)
 * - Fixed five-minute free window after a successful postpone
 * - Suppressed during phone calls (AudioManager mode, no extra permission needed)
 */
class EnforcementOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var currentTask: TaskEntity? = null
    private var isCallActive = false
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var callWatcher: Job? = null

    companion object {
        const val CHANNEL_ID = "grip_enforcement_channel"
        const val NOTIFICATION_ID = 1001
        const val EXTRA_TASK_ID = "extra_task_id"
        private const val DND_PREFS = "grip_focus_dnd"
        private const val DND_ACTIVE = "active"
        private const val DND_PREVIOUS_FILTER = "previous_filter"

        fun startEnforcement(context: Context, taskId: String) {
            val intent = Intent(context, EnforcementOverlayService::class.java).apply {
                putExtra(EXTRA_TASK_ID, taskId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopEnforcement(context: Context) {
            context.stopService(Intent(context, EnforcementOverlayService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val taskId = intent?.getStringExtra(EXTRA_TASK_ID)

        // Android 14+ requires the foreground service type to be passed explicitly.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                buildForegroundNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, buildForegroundNotification())
        }

        if (taskId == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        serviceScope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            val task = db.taskDao().getTaskById(taskId)
            val stillActive = task != null &&
                (task.status == TaskStatus.PENDING || task.status == TaskStatus.IN_PROGRESS)
            if (!stillActive) {
                stopSelf()
                return@launch
            }
            currentTask = task
            enableFocusDoNotDisturb()
            if (!Settings.canDrawOverlays(this@EnforcementOverlayService)) {
                // Permission was revoked: never crash, just stop quietly.
                stopSelf()
                return@launch
            }
            showEnforcementOverlay(task!!)
        }
        // NOT_STICKY: if the system kills us we must not restart with a null intent
        // and leave a notification with no overlay behind.
        return START_NOT_STICKY
    }

    @SuppressLint("InflateParams")
    private fun showEnforcementOverlay(task: TaskEntity) {
        if (overlayView != null) return

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val owner = OverlayLifecycleOwner().also {
            it.onCreate()
            it.onResume()
        }
        lifecycleOwner = owner

        val frameLayout = FrameLayout(this)
        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                EnforcementOverlayCompose(
                    task = task,
                    onPostponeSuccess = { _ ->
                        handlePostponeSuccess(task)
                    },
                    onDoneEarly = {
                        handleDoneEarly(task)
                    }
                )
            }
        }
        frameLayout.addView(composeView)
        overlayView = frameLayout

        try {
            windowManager?.addView(overlayView, layoutParams)
            startCallWatcher()
        } catch (e: Exception) {
            overlayView = null
            stopSelf()
        }
    }

    private fun handlePostponeSuccess(task: TaskEntity) {
        serviceScope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            db.taskDao().incrementPostponeCount(task.id)

            // Hide overlay during free window
            removeOverlay()

            // Schedule return of overlay after the fixed five-minute free window
            GripAlarmScheduler.scheduleFreeWindowReturn(
                applicationContext,
                task.id,
                5
            )
            stopSelf()
        }
    }

    private fun handleDoneEarly(task: TaskEntity) {
        serviceScope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            db.taskDao().markTaskComplete(
                task.id,
                com.grip.app.data.local.entity.TaskStatus.DONE_EARLY,
                System.currentTimeMillis()
            )
            removeOverlay()
            stopSelf()
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
        }
        callWatcher?.cancel()
        lifecycleOwner?.onDestroy()
        lifecycleOwner = null
    }

    /**
     * Hide the overlay while the user is on a call or the phone is ringing.
     * AudioManager.mode needs no runtime permission (unlike READ_PHONE_STATE),
     * which keeps the Play Store permission review much simpler.
     */
    private fun startCallWatcher() {
        callWatcher?.cancel()
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        callWatcher = serviceScope.launch {
            while (isActive) {
                val inCall = audio.mode == AudioManager.MODE_IN_CALL ||
                    audio.mode == AudioManager.MODE_RINGTONE ||
                    audio.mode == AudioManager.MODE_IN_COMMUNICATION
                if (inCall != isCallActive) {
                    isCallActive = inCall
                    overlayView?.visibility = if (inCall) View.GONE else View.VISIBLE
                }
                delay(1500)
            }
        }
    }

    /**
     * Respect the user's special-access choice. Save the previous interruption filter once,
     * enable Priority-only DND for this focus session, and restore the saved filter on exit.
     * Priority-only is intentionally less destructive than NONE because user-configured
     * priority exceptions (for example alarms/important contacts) remain available.
     */
    private fun enableFocusDoNotDisturb() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!manager.isNotificationPolicyAccessGranted) return

        val prefs = getSharedPreferences(DND_PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(DND_ACTIVE, false)) {
            prefs.edit()
                .putInt(DND_PREVIOUS_FILTER, manager.currentInterruptionFilter)
                .putBoolean(DND_ACTIVE, true)
                .apply()
        }
        try {
            manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } catch (_: SecurityException) {
            // The user may revoke access between the check and the operation.
        }
    }

    private fun restorePreviousDoNotDisturb() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val prefs = getSharedPreferences(DND_PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(DND_ACTIVE, false)) return
        val previous = prefs.getInt(DND_PREVIOUS_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            // Restore only if the filter is still the one Grip selected. If the user
            // manually changed DND during the session, respect that newer choice.
            if (manager.isNotificationPolicyAccessGranted &&
                manager.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                manager.setInterruptionFilter(previous)
            }
        } catch (_: SecurityException) {
            // Do not crash if access was revoked while a session was active.
        } finally {
            prefs.edit().remove(DND_PREVIOUS_FILTER).putBoolean(DND_ACTIVE, false).apply()
        }
    }

    private fun buildForegroundNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Grip • قبضة التركيز نشطة")
            .setContentText("نظام الحماية والإنفاذ يعمل لضمان الالتزام بمهمتك.")
            .setSmallIcon(R.drawable.ic_grip_chain)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Grip Enforcement Channel",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إشعارات الحماية ضد التسويف"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        restorePreviousDoNotDisturb()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
