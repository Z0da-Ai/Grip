package com.grip.app.data.local

import androidx.room.TypeConverter
import com.grip.app.data.local.entity.TaskCategory
import com.grip.app.data.local.entity.TaskStatus
import com.grip.app.data.local.entity.TaskType

/** Stable Room representation for task enums. Store names, not ordinal positions. */
class TaskConverters {
    @TypeConverter
    fun categoryToString(value: TaskCategory?): String? = value?.name

    @TypeConverter
    fun stringToCategory(value: String?): TaskCategory? = value?.let {
        runCatching { TaskCategory.valueOf(it) }.getOrDefault(TaskCategory.OTHER)
    }

    @TypeConverter
    fun typeToString(value: TaskType?): String? = value?.name

    @TypeConverter
    fun stringToType(value: String?): TaskType? = value?.let {
        runCatching { TaskType.valueOf(it) }.getOrDefault(TaskType.FLEXIBLE)
    }

    @TypeConverter
    fun statusToString(value: TaskStatus?): String? = value?.name

    @TypeConverter
    fun stringToStatus(value: String?): TaskStatus? = value?.let {
        runCatching { TaskStatus.valueOf(it) }.getOrDefault(TaskStatus.PENDING)
    }
}
