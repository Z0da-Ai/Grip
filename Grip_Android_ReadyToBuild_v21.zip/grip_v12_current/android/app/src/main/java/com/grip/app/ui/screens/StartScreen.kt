package com.grip.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.grip.app.data.local.AppDatabase
import com.grip.app.data.local.entity.TaskCategory
import com.grip.app.data.local.entity.TaskEntity
import com.grip.app.data.local.entity.TaskStatus
import com.grip.app.data.local.entity.TaskType
import kotlinx.coroutines.launch
import java.util.UUID

private val startCategories = listOf(
    TaskCategory.STUDY to "دراسة",
    TaskCategory.WORK to "شغل",
    TaskCategory.SPORT to "رياضة",
    TaskCategory.PERSONAL to "شخصي"
)
private val startDurations = listOf(25, 45, 60)

/**
 * The first page: "what do you want to start with?". It replaces the old timed splash.
 * Starting creates one task that begins now (status IN_PROGRESS, the same state the home screen's
 * "ابدأ دلوقتي" button uses) and opens the home screen, where it shows as "شغّال دلوقتي".
 * No alarm is scheduled for it because it starts immediately. The skip button always works.
 */
@Composable
fun StartScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val database = remember(context) { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var title by rememberSaveable { mutableStateOf("") }
    var categoryName by rememberSaveable { mutableStateOf(TaskCategory.PERSONAL.name) }
    var minutes by rememberSaveable { mutableStateOf(25) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .imePadding()
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "تحب تبدأ بمهمة إيه؟",
                    fontSize = 28.sp,
                    lineHeight = 36.sp,
                    fontWeight = FontWeight.Black,
                    color = cs.onBackground
                )
                Text(
                    "اكتب مهمة واحدة بس، وهنبدأها دلوقتي.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم المهمة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("النوع", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    startCategories.forEach { (category, label) ->
                        ChoicePill(label = label, selected = categoryName == category.name) {
                            categoryName = category.name
                        }
                    }
                }

                Text("المدة", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    startDurations.forEach { value ->
                        ChoicePill(label = "$value دقيقة", selected = minutes == value) { minutes = value }
                    }
                }

                if (error != null) {
                    Text(error!!, color = cs.error, style = MaterialTheme.typography.bodySmall)
                }

                Button(
                    onClick = {
                        val cleanTitle = title.trim()
                        if (cleanTitle.isNotEmpty() && !saving) {
                            saving = true
                            error = null
                            val now = System.currentTimeMillis()
                            val category = runCatching { TaskCategory.valueOf(categoryName) }
                                .getOrDefault(TaskCategory.PERSONAL)
                            val task = TaskEntity(
                                id = UUID.randomUUID().toString(),
                                title = cleanTitle,
                                category = category,
                                startTimeEpochMs = now,
                                endTimeEpochMs = now + minutes * 60_000L,
                                type = TaskType.FLEXIBLE,
                                status = TaskStatus.IN_PROGRESS
                            )
                            scope.launch {
                                try {
                                    database.taskDao().insertTask(task)
                                    onDone()
                                } catch (_: Exception) {
                                    // Never trap the user on this page: show a message and allow another try or skip.
                                    saving = false
                                    error = "تعذر حفظ المهمة. جرّب تاني أو اضغط تخطي."
                                }
                            }
                        }
                    },
                    enabled = title.isNotBlank() && !saving,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("ابدأ دلوقتي", fontWeight = FontWeight.Black) }

                TextButton(
                    onClick = onDone,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) { Text("تخطي، افتح التطبيق") }
            }
        }
    }
}

@Composable
private fun ChoicePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (selected) cs.primary else cs.surface,
        border = if (selected) null else BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) cs.onPrimary else cs.onSurfaceVariant
        )
    }
}
