package com.grip.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.grip.app.ai.LocalAiAssistantDialog
import com.grip.app.data.local.AppDatabase
import com.grip.app.data.local.entity.TaskCategory
import com.grip.app.data.local.entity.TaskEntity
import com.grip.app.data.local.entity.TaskStatus
import com.grip.app.data.local.entity.TaskType
import com.grip.app.util.GripAlarmScheduler
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

private data class CalendarDay(
    val date: LocalDate,
    val dayName: String,
    val dayNumber: String,
    val isToday: Boolean
)

private val arabicLocale = Locale("ar", "EG")
private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", arabicLocale)

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val database = remember(context) { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()
    val allTasks by database.taskDao().getAllTasksFlow().collectAsState(initial = emptyList())
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var selectedCategory by remember { mutableStateOf<TaskCategory?>(null) }
    var showLocalAi by remember { mutableStateOf(false) }
    var showAddTask by remember { mutableStateOf(false) }

    val today = LocalDate.now()
    val weekStart = remember(today) { today.with(java.time.DayOfWeek.MONDAY) }
    val days = remember(weekStart) {
        (0..6).map { offset ->
            val date = weekStart.plusDays(offset.toLong())
            CalendarDay(
                date = date,
                dayName = date.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, arabicLocale),
                dayNumber = date.dayOfMonth.toString(),
                isToday = date == today
            )
        }
    }
    val zone = remember { ZoneId.systemDefault() }
    val dayStart = selectedDate.atStartOfDay(zone).toInstant().toEpochMilli()
    val nextDayStart = selectedDate.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val dayTasks = allTasks.filter { it.startTimeEpochMs >= dayStart && it.startTimeEpochMs < nextDayStart }
        .sortedBy { it.startTimeEpochMs }
    val visibleTasks = dayTasks.filter { selectedCategory == null || it.category == selectedCategory }
    val completedCount = dayTasks.count { it.status == TaskStatus.DONE || it.status == TaskStatus.DONE_EARLY }
    val todayCompleted = allTasks.filter {
        val date = java.time.Instant.ofEpochMilli(it.completedAtEpochMs ?: 0L).atZone(zone).toLocalDate()
        (it.status == TaskStatus.DONE || it.status == TaskStatus.DONE_EARLY) && date == today
    }.size
    val completedDates = allTasks.filter {
        (it.status == TaskStatus.DONE || it.status == TaskStatus.DONE_EARLY) && it.completedAtEpochMs != null
    }.map { java.time.Instant.ofEpochMilli(it.completedAtEpochMs!!).atZone(zone).toLocalDate() }.toSet()
    val streak = remember(completedDates, today) {
        var cursor = if (today in completedDates) today else today.minusDays(1)
        var count = 0
        while (cursor in completedDates && count < 3650) { count++; cursor = cursor.minusDays(1) }
        count
    }
    val focusTask = dayTasks.firstOrNull { it.status == TaskStatus.IN_PROGRESS }
        ?: dayTasks.firstOrNull { it.status == TaskStatus.PENDING && it.endTimeEpochMs > System.currentTimeMillis() }
    val cs = MaterialTheme.colorScheme

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(
            containerColor = cs.background,
            floatingActionButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    FloatingActionButton(
                        onClick = { showAddTask = true },
                        containerColor = cs.surface,
                        contentColor = cs.onSurface,
                        shape = RoundedCornerShape(18.dp)
                    ) { Icon(Icons.Filled.Add, contentDescription = "إضافة مهمة") }
                    FloatingActionButton(
                        onClick = { showLocalAi = true },
                        containerColor = cs.primary,
                        contentColor = Color.White,
                        shape = RoundedCornerShape(18.dp)
                    ) { Icon(Icons.Filled.AutoAwesome, contentDescription = "المساعد", modifier = Modifier.size(26.dp)) }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
            ) {
                // Compact brand header inspired by the web app.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF111827)),
                            contentAlignment = Alignment.Center
                        ) {
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.grip.app.R.drawable.ic_grip_chain),
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Column {
                            Text("GRIP", fontSize = 18.sp, fontWeight = FontWeight.Black, color = cs.onBackground, letterSpacing = 1.4.sp)
                            Text(
                                selectedDate.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", arabicLocale)),
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                    Surface(shape = RoundedCornerShape(50), color = if (streak > 0) Color(0xFFFFF1D6) else cs.surfaceVariant) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("🔥", fontSize = 15.sp)
                            Text(streak.toString(), fontWeight = FontWeight.Black, color = if (streak > 0) Color(0xFF9A3412) else cs.onSurfaceVariant)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        // Today focus card: same purple gradient and direct next step as the web reference.
                        Surface(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(24.dp), color = Color.Transparent
                        ) {
                            Column(
                                modifier = Modifier.background(
                                    brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                        colors = listOf(Color(0xFF6D28D9), Color(0xFF4C1D95))
                                    )
                                ).padding(18.dp)
                            ) {
                                Text(if (focusTask?.status == TaskStatus.IN_PROGRESS) "شغّال دلوقتي" else "ابدأ بأول مهمة",
                                    color = Color(0xFFE9D5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(5.dp))
                                Text(
                                    focusTask?.title ?: if (dayTasks.isEmpty()) "ابدأ بمهمة صغيرة" else "أنجزت مهامك المجدولة 👏",
                                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black,
                                    lineHeight = 28.sp
                                )
                                Spacer(Modifier.height(5.dp))
                                Text(
                                    focusTask?.let { "${formatTime(it.startTimeEpochMs, zone)} – ${formatTime(it.endTimeEpochMs, zone)}" }
                                        ?: "كل خطوة صغيرة بتفرق. اختار مهمة وابدأ.",
                                    color = Color(0xFFE9D5FF), fontSize = 13.sp, fontWeight = FontWeight.Medium
                                )
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                    Button(
                                        onClick = {
                                            if (focusTask == null) showAddTask = true
                                            else scope.launch {
                                                database.taskDao().updateTask(focusTask.copy(status = TaskStatus.IN_PROGRESS))
                                            }
                                        },
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4C1D95))
                                    ) {
                                        Text(if (focusTask == null) "أضف مهمة" else if (focusTask.status == TaskStatus.IN_PROGRESS) "كمّل دلوقتي" else "ابدأ دلوقتي",
                                            fontWeight = FontWeight.Black)
                                    }
                                    OutlinedButton(
                                        onClick = { showAddTask = true },
                                        modifier = Modifier.heightIn(min = 48.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .45f)),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                    ) { Icon(Icons.Filled.Add, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("مهمة جديدة", fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                    }

                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatTile(value = todayCompleted.toString(), label = "أنجزت النهارده", modifier = Modifier.weight(1f))
                            StatTile(value = dayTasks.size.toString(), label = "المهام", modifier = Modifier.weight(1f))
                            StatTile(value = streak.toString(), label = "أيام متتالية", modifier = Modifier.weight(1f))
                        }
                    }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("أيام الأسبوع", modifier = Modifier.padding(horizontal = 20.dp),
                                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black)
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(days, key = { it.date.toString() }) { day ->
                                    val selected = day.date == selectedDate
                                    Column(
                                        modifier = Modifier.width(48.dp).clip(RoundedCornerShape(16.dp))
                                            .background(if (selected) Color(0xFF111827) else cs.surface)
                                            .clickable { selectedDate = day.date }
                                            .padding(vertical = 10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(day.dayName, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                            color = if (selected) Color.White.copy(alpha = .78f) else cs.onSurfaceVariant)
                                        Spacer(Modifier.height(4.dp))
                                        Text(day.dayNumber, fontSize = 16.sp, fontWeight = FontWeight.Black,
                                            color = if (selected) Color.White else cs.onSurface)
                                        if (day.isToday) {
                                            Spacer(Modifier.height(4.dp))
                                            Box(Modifier.size(5.dp).clip(CircleShape).background(if (selected) Color.White else cs.primary))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val filters = listOf<Pair<TaskCategory?, String>>(null to "الكل") + TaskCategory.values().map { it to categoryLabel(it) }
                            items(filters, key = { it.second }) { (category, label) ->
                                val selected = selectedCategory == category
                                Surface(
                                    modifier = Modifier.clickable { selectedCategory = category },
                                    shape = RoundedCornerShape(50),
                                    color = if (selected) Color(0xFF111827) else cs.surface,
                                    border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)
                                ) {
                                    Text(label, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp),
                                        fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else cs.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(if (selectedDate == today) "مهام النهارده" else "مهام ${selectedDate.dayOfMonth}",
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            Text("${visibleTasks.size} مهمة", color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (visibleTasks.isEmpty()) {
                        item {
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(20.dp), color = cs.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("مفيش مهام هنا لسه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                                    Spacer(Modifier.height(6.dp))
                                    Text("ابدأ بحاجة صغيرة وهتلاقيها هنا.", color = cs.onSurfaceVariant)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { showAddTask = true }, shape = RoundedCornerShape(14.dp)) { Text("أضف مهمة") }
                                }
                            }
                        }
                    } else {
                        items(visibleTasks, key = { it.id }) { task ->
                            val isDone = task.status == TaskStatus.DONE || task.status == TaskStatus.DONE_EARLY
                            val categoryColor = categoryColor(task.category)
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = cs.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant),
                                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                            ) {
                                Row(Modifier.fillMaxWidth().heightIn(min = 94.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.width(5.dp).height(94.dp).background(categoryColor))
                                    Column(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp),
                                        verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                            Surface(shape = RoundedCornerShape(8.dp), color = categoryColor.copy(alpha = .14f)) {
                                                Text(categoryLabel(task.category), modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                                                    color = categoryColor, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                            }
                                            Text("${formatTime(task.startTimeEpochMs, zone)} – ${formatTime(task.endTimeEpochMs, zone)}",
                                                fontSize = 11.sp, color = cs.onSurfaceVariant, fontWeight = FontWeight.Medium)
                                        }
                                        Text(task.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold,
                                            textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                                            color = if (isDone) cs.onSurfaceVariant else cs.onSurface)
                                    }
                                    FilledIconButton(
                                        onClick = {
                                            scope.launch {
                                                val nextStatus = if (isDone) TaskStatus.PENDING else TaskStatus.DONE
                                                database.taskDao().markTaskComplete(task.id, nextStatus,
                                                    if (isDone) 0L else System.currentTimeMillis())
                                                if (nextStatus == TaskStatus.DONE) {
                                                    GripAlarmScheduler.cancel(context, task.id)
                                                } else if (task.startTimeEpochMs > System.currentTimeMillis()) {
                                                    GripAlarmScheduler.scheduleExactTaskAlarm(context, task)
                                                }
                                            }
                                        },
                                        modifier = Modifier.padding(end = 10.dp).size(48.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = IconButtonDefaults.filledIconButtonColors(
                                            containerColor = if (isDone) Color(0xFFDCFCE7) else Color(0xFFF3E8FF),
                                            contentColor = if (isDone) Color(0xFF15803D) else Color(0xFF6D28D9)
                                        )
                                    ) {
                                        Icon(if (isDone) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                            contentDescription = if (isDone) "إلغاء الإنجاز" else "إنجاز المهمة",
                                            modifier = Modifier.size(25.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddTask) {
        AddTaskDialog(
            selectedDate = selectedDate,
            onDismiss = { showAddTask = false },
            onSave = { task ->
                scope.launch {
                    database.taskDao().insertTask(task)
                    if (task.startTimeEpochMs > System.currentTimeMillis()) {
                        GripAlarmScheduler.scheduleExactTaskAlarm(context, task)
                    }
                }
                showAddTask = false
            }
        )
    }
    if (showLocalAi) LocalAiAssistantDialog(onDismiss = { showLocalAi = false })
}

@Composable
private fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = cs.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Column(Modifier.padding(horizontal = 5.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 19.sp, fontWeight = FontWeight.Black, color = cs.primary)
            Spacer(Modifier.height(3.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
        }
    }
}

private fun categoryColor(category: TaskCategory): Color = when (category) {
    TaskCategory.STUDY -> Color(0xFF7C3AED)
    TaskCategory.WORK -> Color(0xFFEA580C)
    TaskCategory.SPORT -> Color(0xFF059669)
    TaskCategory.SLEEP -> Color(0xFFE11D48)
    TaskCategory.PERSONAL -> Color(0xFF0284C7)
    TaskCategory.OTHER -> Color(0xFF64748B)
}

@Composable
private fun AddTaskDialog(selectedDate: LocalDate, onDismiss: () -> Unit, onSave: (TaskEntity) -> Unit) {
    var title by remember { mutableStateOf("") }
    var startText by remember { mutableStateOf("09:00") }
    var endText by remember { mutableStateOf("10:00") }
    var category by remember { mutableStateOf(TaskCategory.PERSONAL) }
    var isFixed by remember { mutableStateOf(false) }
    var categoryMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مهمة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it; error = null },
                    label = { Text("اسم المهمة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { categoryMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("التصنيف: ${categoryLabel(category)}")
                    }
                    DropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                        TaskCategory.values().forEach { item ->
                            DropdownMenuItem(text = { Text(categoryLabel(item)) }, onClick = { category = item; categoryMenu = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = startText, onValueChange = { startText = it; error = null },
                        label = { Text("وقت البداية") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = endText, onValueChange = { endText = it; error = null },
                        label = { Text("وقت النهاية") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isFixed, onCheckedChange = { isFixed = it })
                    Text("موعد ثابت")
                }
                Text("التاريخ: ${selectedDate.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", arabicLocale))}",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                if (error != null) Text(error!!, color = cs.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleanTitle = title.trim()
                val start = runCatching { LocalTime.parse(startText.trim()) }.getOrNull()
                val end = runCatching { LocalTime.parse(endText.trim()) }.getOrNull()
                when {
                    cleanTitle.isBlank() -> error = "اكتب اسم المهمة الأول."
                    start == null || end == null -> error = "اكتب الوقت مثل 09:30 بنظام 24 ساعة."
                    !end.isAfter(start) -> error = "وقت النهاية لازم يكون بعد البداية في نفس اليوم."
                    else -> {
                        val startEpoch = LocalDateTime.of(selectedDate, start).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        val endEpoch = LocalDateTime.of(selectedDate, end).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        onSave(TaskEntity(
                            id = UUID.randomUUID().toString(), title = cleanTitle, category = category,
                            startTimeEpochMs = startEpoch, endTimeEpochMs = endEpoch,
                            type = if (isFixed) TaskType.FIXED else TaskType.FLEXIBLE
                        ))
                    }
                }
            }) { Text("حفظ المهمة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun categoryLabel(category: TaskCategory): String = when (category) {
    TaskCategory.STUDY -> "دراسة"
    TaskCategory.WORK -> "شغل"
    TaskCategory.SPORT -> "رياضة"
    TaskCategory.SLEEP -> "نوم"
    TaskCategory.PERSONAL -> "شخصي"
    TaskCategory.OTHER -> "أخرى"
}

private fun formatTime(epochMs: Long, zone: ZoneId): String =
    java.time.Instant.ofEpochMilli(epochMs).atZone(zone).format(timeFormatter)
