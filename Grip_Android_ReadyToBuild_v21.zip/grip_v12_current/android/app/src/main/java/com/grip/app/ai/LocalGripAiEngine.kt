package com.grip.app.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Local, offline text reasoning for Grip. Application actions must still be validated by Grip code. */
class LocalGripAiEngine(context: Context) {
    private val appContext = context.applicationContext

    suspend fun answer(userRequest: String): String = withContext(Dispatchers.IO) {
        require(userRequest.isNotBlank()) { "اكتب طلبك الأول." }
        check(LocalAiModelManager.verifyModel(appContext)) {
            "نموذج Grip المحلي غير موجود أو فشل التحقق من سلامته. نزّله مرة أخرى من داخل التطبيق."
        }
        val modelPath = LocalAiModelManager.modelFile(appContext).absolutePath
        val systemInstruction = """
            أنت Grip، مساعد عربي عملي لتنظيم الحياة اليومية لمستخدم لديه مهام ودراسة ومصاريف وتركيز.
            أجب بالعربية المصرية الواضحة وباختصار مفيد. افهم الطلب قبل الرد، ولا تخترع بيانات أو مواعيد أو مصاريف.
            إذا كانت معلومة أساسية ناقصة فاسأل سؤالًا واحدًا محددًا. لا تدّعِ أنك حفظت مهمة أو عدّلت ميزانية أو أنشأت تنبيهًا؛ أنت تشرح أو تقترح فقط، وتطبيق Grip هو الذي ينفذ بعد التحقق والتأكيد.
            لا تذكر أنك متصل بالإنترنت؛ هذا النموذج يعمل محليًا. إذا كان الطلب يحتاج صورة أو ملفًا غير موجود في الرسالة، اطلب من المستخدم إرفاقه.
        """.trimIndent()

        fun runWith(backend: Backend): String {
            val config = EngineConfig(
                modelPath = modelPath,
                backend = backend,
                cacheDir = appContext.cacheDir.absolutePath,
            )
            val engine = Engine(config)
            // Initialize before entering use: LiteRT-LM close() expects successful initialization.
            engine.initialize()
            engine.use {
                val conversationConfig = ConversationConfig(
                    systemInstruction = Contents.of(systemInstruction),
                    samplerConfig = SamplerConfig(topK = 20, topP = 0.8, temperature = 0.35),
                )
                engine.createConversation(conversationConfig).use { conversation ->
                    val reply = replyText(
                        conversation.sendMessage(
                            userRequest,
                            extraContext = mapOf("enable_thinking" to false),
                        )
                    ).trim()
                    return reply.ifBlank { "مش قادر أطلع رد واضح للطلب ده. جرّب صياغة أبسط." }
                }
            }
        }

        // Try GPU first for responsiveness; fall back to CPU if the device driver/runtime rejects it.
        try {
            runWith(Backend.GPU())
        } catch (gpuError: Throwable) {
            // Preserve cancellation and fatal memory/thread failures; fall back for native GPU/linkage failures too.
            if (gpuError is CancellationException || gpuError is OutOfMemoryError || gpuError is ThreadDeath) throw gpuError
            try {
                runWith(Backend.CPU())
            } catch (cpuError: Throwable) {
                if (cpuError is CancellationException || cpuError is OutOfMemoryError || cpuError is ThreadDeath) throw cpuError
                cpuError.addSuppressed(gpuError)
                throw IllegalStateException(
                    "تعذّر تشغيل النموذج المحلي على هذا الجهاز. يمكننا مراجعة توافق GPU/CPU في سجل البناء.",
                    cpuError,
                )
            }
        }
    }
}

private val defaultObjectToString = Regex("^[\\w.\$]+@[0-9a-fA-F]+\$")

/**
 * Plain text of a LiteRT-LM reply. The reply object of litertlm 0.18.0 has no `text` property (that was a
 * compile error), so read it through toString() and, only if that is the default Object.toString(),
 * through a text/contents getter.
 */
private fun replyText(message: Any?): String {
    if (message == null) return ""
    val direct = message.toString()
    if (!defaultObjectToString.matches(direct)) return direct
    for (getter in listOf("getText", "getContents")) {
        val value = runCatching { message.javaClass.getMethod(getter).invoke(message) }.getOrNull() ?: continue
        val text = value.toString()
        if (!defaultObjectToString.matches(text)) return text
    }
    return direct
}
