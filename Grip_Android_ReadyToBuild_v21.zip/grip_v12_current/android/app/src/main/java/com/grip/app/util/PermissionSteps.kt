package com.grip.app.util

/**
 * The special permissions Grip asks for, in the order they are presented.
 *
 * [isCore] = a Grip feature stops working or degrades without it, so skipping it needs an
 * explicit confirmation that explains the consequence. Skipping is still safe for every one of
 * them: GripAlarmScheduler falls back to inexact alarms, and EnforcementOverlayService stops
 * quietly when the overlay permission is missing.
 */
enum class GripPermission(val isCore: Boolean) {
    NOTIFICATIONS(true),
    EXACT_ALARMS(true),
    OVERLAY(true),
    DND(false)
}

/** Pure decision logic (no Android classes) so it can be unit-tested on the JVM. */
object PermissionSteps {

    /** Permissions still to ask about: not granted and not skipped by the user, in display order. */
    fun pending(granted: Set<GripPermission>, skipped: Set<GripPermission>): List<GripPermission> =
        GripPermission.values().filter { it !in granted && it !in skipped }

    /** Core permissions that are not granted, whether or not the user skipped them. */
    fun missingCore(granted: Set<GripPermission>): List<GripPermission> =
        GripPermission.values().filter { it.isCore && it !in granted }

    /**
     * True when no step is left to ask but a core permission is still missing
     * (the user skipped it, or revoked it later): show the slim reminder instead of the wizard.
     */
    fun needsBanner(granted: Set<GripPermission>, skipped: Set<GripPermission>): Boolean =
        pending(granted, skipped).isEmpty() && missingCore(granted).isNotEmpty()
}
