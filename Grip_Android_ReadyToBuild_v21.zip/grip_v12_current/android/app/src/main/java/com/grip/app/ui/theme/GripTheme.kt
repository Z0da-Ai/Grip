package com.grip.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import com.grip.app.R

private val GripPurple = Color(0xFF6D28D9)
private val GripPurpleDark = Color(0xFF4C1D95)
private val GripLightBackground = Color(0xFFF8FAFC)
private val GripDarkBackground = Color(0xFF0B1220)
private val GripBorderLight = Color(0xFFE2E8F0)
private val GripBorderDark = Color(0xFF273449)

// Local Arabic font bundled with the app. Cairo is not included in the supplied archive;
// Amiri is used as a local fallback until the licensed Cairo font files can be added.
private val GripArabicFont = FontFamily(
    Font(R.font.amiri_regular, FontWeight.Normal),
    Font(R.font.amiri_bold, FontWeight.Bold)
)

private val GripTypography = Typography(
    displayLarge = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Black, fontSize = 57.sp, lineHeight = 64.sp),
    displayMedium = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.ExtraBold, fontSize = 45.sp, lineHeight = 52.sp),
    displaySmall = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 36.sp, lineHeight = 44.sp),
    headlineLarge = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Black, fontSize = 32.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 24.sp),
    titleSmall = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = GripArabicFont, fontWeight = FontWeight.Bold, fontSize = 11.sp, lineHeight = 16.sp)
)

private val GripLightColors = lightColorScheme(
    primary = GripPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE9FE),
    onPrimaryContainer = GripPurpleDark,
    secondary = GripPurpleDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1EAFE),
    onSecondaryContainer = GripPurpleDark,
    background = GripLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFCBD5E1),
    outlineVariant = GripBorderLight,
    error = Color(0xFFB91C1C)
)

private val GripDarkColors = darkColorScheme(
    primary = Color(0xFFA78BFA),
    onPrimary = Color(0xFF2E1065),
    primaryContainer = Color(0xFF4C1D95),
    onPrimaryContainer = Color(0xFFEDE9FE),
    secondary = Color(0xFFC4B5FD),
    onSecondary = Color(0xFF2E1065),
    secondaryContainer = Color(0xFF31205A),
    onSecondaryContainer = Color(0xFFEDE9FE),
    background = GripDarkBackground,
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF111B2D),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFB6C2D2),
    outline = Color(0xFF475569),
    outlineVariant = GripBorderDark,
    error = Color(0xFFFCA5A5)
)

@Composable
fun GripTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) GripDarkColors else GripLightColors,
        typography = GripTypography,
        content = content
    )
}
