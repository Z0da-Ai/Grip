import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { extractTasksRuleBased, parseVoiceCommandRuleBased } from './src/shared/ruleBased';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.set('trust proxy', 1);
// PDFs/images arrive as base64 (~33% bigger), so 12mb covers ~8mb files without allowing abuse.
app.use(express.json({ limit: '12mb' }));

app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), geolocation=(), microphone=(self)');
  next();
});

// Minimal in-memory rate limiter for the paid AI endpoints (no extra dependency).
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = parseInt(process.env.AI_RATE_LIMIT_PER_MIN || '20', 10);
const hits = new Map<string, { count: number; reset: number }>();
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
}, RATE_WINDOW_MS).unref();

app.use('/api/ai', (req, res, next) => {
  const key = req.ip || 'unknown';
  const now = Date.now();
  const entry = hits.get(key);
  if (!entry || entry.reset < now) {
    hits.set(key, { count: 1, reset: now + RATE_WINDOW_MS });
    return next();
  }
  entry.count += 1;
  if (entry.count > RATE_MAX) {
    res.setHeader('Retry-After', Math.ceil((entry.reset - now) / 1000).toString());
    return res.status(429).json({ success: false, error: 'طلبات كثيرة، حاول بعد دقيقة.' });
  }
  next();
});

// Cap free-text fields so a single request cannot burn the Gemini quota.
const MAX_TEXT_CHARS = 6000;
app.use('/api/ai', (req, _res, next) => {
  if (req.body && typeof req.body === 'object') {
    for (const key of ['speechText', 'promptText', 'text']) {
      if (typeof req.body[key] === 'string' && req.body[key].length > MAX_TEXT_CHARS) {
        req.body[key] = req.body[key].slice(0, MAX_TEXT_CHARS);
      }
    }
  }
  next();
});

// One place to change the model. gemini-2.5-flash is the documented stable default.
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

// Initialize Google GenAI client if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}



// Endpoint 0: Universal Smart Voice Assistant for Tasks, Expenses, Intentions, Alarms & Habits
app.post('/api/ai/process-voice-command', async (req: Request, res: Response) => {
  try {
    const { speechText, referenceDate, categories, imageBase64, imageMimeType, pdfBase64, pdfMimeType, appContext, responseLocale } = req.body;
    const text = (speechText || '').trim();

    if (!text && !imageBase64 && !pdfBase64) {
      return res.status(400).json({ success: false, error: 'تحدث أو اكتب طلبك، أو أرفق صورة/PDF.' });
    }

    const refDate = referenceDate || new Date().toISOString().split('T')[0];

    if (!aiClient) {
      if (imageBase64 || pdfBase64) return res.status(503).json({ success: false, error: 'تحليل الصور وPDF يحتاج خادم Grip AI مع مفتاح Gemini. لم يتم تنفيذ أي إجراء.' });
      const fallbackResult = parseVoiceCommandRuleBased(text, refDate);
      return res.json({
        success: true,
        isFallback: true,
        rawText: text,
        ...fallbackResult,
      });
    }

    const availableCategories = (categories && Array.isArray(categories))
      ? categories.join(', ')
      : 'أكل ومشاريب, مواصلات, مذاكرة وكورسات, خروجات وترفيه, أخرى';

    const localeInstruction = responseLocale === 'en'
      ? 'Respond naturally in English, including summary and spokenFeedback. The user may still speak Arabic or mix languages.'
      : responseLocale === 'ar-eg'
        ? 'Respond in natural, respectful Egyptian Arabic, including summary and spokenFeedback. Understand Egyptian colloquial Arabic, Modern Standard Arabic, and mixed English.'
        : 'Respond in clear, broadly understandable Arabic close to Modern Standard Arabic, including summary and spokenFeedback. Understand Egyptian, Gulf, Levantine, and Modern Standard Arabic; do not assume every Arabic speaker prefers Egyptian dialect.';

    const systemPrompt = `
أنت العقل الموحد لتطبيق Grip — مساعد ADHD لتنظيم الحياة والدراسة والتركيز والمصاريف والعادات. ${localeInstruction} افهم اللغة الطبيعية بالعربية المصرية والفصحى واللهجات العربية والإنجليزية المختلطة. قد يستقبل المستخدم نصًا أو تفريغ صوت أو صورة أو PDF أو مزيجًا منها. افهم محتوى المرفق مع الطلب، ولا تخمّن التفاصيل غير الواضحة. إذا كان الملف جدولًا دراسيًا متعدد الأحداث، أعد كل الأحداث في data.tasks. إذا كان المطلوب غير واضح أو ناقصًا، اختر UNKNOWN واكتب سؤال توضيح محددًا بدل تنفيذ خاطئ. لا تدّعِ أنك نفذت إجراءً؛ أنت فقط تقترح بيانات منظمة ليؤكدها المستخدم داخل التطبيق.

التصنيفات المتاحة للأمر (intent):
1. "ADD_EXPENSE": عندما يتحدث المستخدم عن تسجيل مصروف أو صرف نقود أو شراء شيء أو دفع فاتورة.
   - مثال: "سجل مصروف 50 جنيه قهوة ومشاريب"، "صرفت 200 بنزين"، "اشتريت كتب بـ 150 جنيه".
   - استخرج:
     * amount (رقم موجب، مثلاً 50)
     * amountMinor (amount مضروباً في 100، مثلاً 5000)
     * title (اسم المصروف، مثلاً "قهوة وشاي")
     * categoryName (اختر الأقرب من التصنيفات المتاحة: ${availableCategories})
     * note (ملاحظة اختيارية)

2. "SCHEDULE_TASK": عندما يطلب المستخدم وضع موعد في الجدول أو مذاكرة أو تمرين أو محاضرة أو مهمة.
   - مثال: "حطلي ميعاد بكرة الساعة 5 العصر مذاكرة فسيولوجي"، "عندي تمرين جيم النهاردة من 7 ل 9 بالليل".
   - استخرج:
     * title (اسم المهمة بالعربية)
     * category ("study" | "work" | "sport" | "sleep" | "personal" | "other")
     * startTime (بصيغة ISO كاملة بناءً على تاريخ اليوم: ${refDate})
     * endTime (بصيغة ISO كاملة)
     * type ("FIXED" للمحاضرات والمواعيد الثابتة، أو "FLEXIBLE" للمذاكرة والتمارين المرنة)
     * notes (ملاحظات)

3. "SET_WAKE_UP_ALARM": عندما يطلب ضبط منبه الصحوة الصباحي (المنبه الحاسم الذي يرن مرة واحدة).
   - مثال: "ظبطلي منبه الصحوة الساعة 6 الصبح"، "عايز اصحى الساعة 7 ونص".
   - استخرج:
     * time (توقيت بصيغة HH:mm مثل "06:30")
     * title ("منبه الصحوة الحاسم ⏰")

4. "ADD_INTENTION": عندما يذكر المستخدم نية يومية، أو هدف معنوي/روحي/تركيزي.
   - مثال: "نيتي النهاردة التركيز التام بدون تشتت"، "اضف نية شرب 3 لتر مياه والاهتمام بالصحة"، "نيتي الإخلاص في العمل".
   - استخرج:
     * text (نص النية بأسلوب لطيف وملهم)
     * tag ("today" | "routine" | "idea" | "urgent")

5. "LOG_TRACKER": عندما يذكر المستخدم إنجاز عادة إيجابية كشرب الماء أو التركيز أو التمرين.
   - مثال: "سجل اني شربت مياه"، "سجلت كوباية مية".
   - استخرج:
     * trackerType ("water" | "deep_work" | "workout")
     * label (اسم العادة)
     * value (العدد أو القيمة)

6. "ANSWER_QUERY": إذا سأل المستخدم سؤالاً استفسارياً عن مهامه أو يومه أو الميزانية أو المصاريف أو العادات. استخدم سياق Grip المرفق ولا تخترع بيانات غير موجودة. أرجع إجابة واضحة وموجزة في queryAnswer.
7. \"SET_BUDGET\": عندما يحدد المستخدم ميزانية جديدة أو يغيّر ميزانيته. استخرج amount كقيمة بالعملة الرئيسية (مثلاً 500 جنيه = 500)، وdurationDays (أسبوع=7، شهر=30 ما لم يحدد غير ذلك)، وname، وcurrency (افتراضي ج.م). لا تستخدم هذا intent عند السؤال عن المتبقي؛ هذا ANSWER_QUERY.
8. \"START_FOCUS_SESSION\": عندما يطلب المستخدم بدء جلسة تركيز الآن، استخرج durationMinutes (افتراضي 25 إذا لم يحدد مدة) وtitle. لا تستخدمه عند جدولة جلسة للمستقبل؛ تلك SCHEDULE_TASK.
9. عند طلب ترتيب عدة أحداث، ضعها كلها في data.tasks، سواء جاءت من الكلام أو المرفق.

قواعد الاستجابة:
- ضع summary يوضح للمستخدم بالعربية ما تم فهمه (مثال: "تم فهم تسجيل مصروف 50 ج.م في أكل ومشاريب").
- ضع spokenFeedback عبارة قصيرة مشجعة بالعامية المهذبة مناسبة للنطق الصوتي (مثال: "تمام، تم تسجيل المصروف بنجاح").
`;

    const userParts: any[] = [];
    if (imageBase64) userParts.push({ inlineData: { mimeType: imageMimeType || 'image/jpeg', data: imageBase64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '') } });
    if (pdfBase64) userParts.push({ inlineData: { mimeType: pdfMimeType || 'application/pdf', data: pdfBase64.replace(/^data:application\/pdf;base64,/, '') } });
    userParts.push({ text: `${systemPrompt}\n\nسياق Grip الحالي (بيانات المستخدم المحلية التي أرسلها التطبيق لهذا الطلب فقط):\n${JSON.stringify(appContext || {})}\n\nنص المستخدم أو التفريغ الصوتي:\n${text || 'حلّل المرفق واستخرج المطلوب منه. إذا كان جدولًا فاستخرج أحداثه، وإذا كان مستندًا فاسأل عن الإجراء المقصود إذا لم يكن واضحًا.'}` });

    const response = await aiClient.models.generateContent({
      model: GEMINI_MODEL,
      contents: [{ role: 'user', parts: userParts }],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            intent: {
              type: Type.STRING,
              description: 'ADD_EXPENSE, SCHEDULE_TASK, SET_WAKE_UP_ALARM, ADD_INTENTION, LOG_TRACKER, SET_BUDGET, START_FOCUS_SESSION, ANSWER_QUERY, or UNKNOWN',
            },
            summary: { type: Type.STRING },
            spokenFeedback: { type: Type.STRING },
            data: {
              type: Type.OBJECT,
              properties: {
                expense: {
                  type: Type.OBJECT,
                  properties: {
                    amount: { type: Type.NUMBER },
                    amountMinor: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    categoryName: { type: Type.STRING },
                    note: { type: Type.STRING },
                  },
                },
                task: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    category: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                    type: { type: Type.STRING },
                    notes: { type: Type.STRING },
                  },
                },
                tasks: {
                  type: Type.ARRAY,
                  items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, category: { type: Type.STRING }, startTime: { type: Type.STRING }, endTime: { type: Type.STRING }, type: { type: Type.STRING }, notes: { type: Type.STRING }, autoPlace: { type: Type.BOOLEAN }, placeDay: { type: Type.STRING }, durationMinutes: { type: Type.INTEGER }, preferAfter: { type: Type.STRING } }, required: ['title', 'category', 'startTime', 'endTime', 'type'] },
                },
                alarm: {
                  type: Type.OBJECT,
                  properties: {
                    time: { type: Type.STRING },
                    title: { type: Type.STRING },
                    notes: { type: Type.STRING },
                  },
                },
                intention: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    tag: { type: Type.STRING },
                  },
                },
                tracker: {
                  type: Type.OBJECT,
                  properties: {
                    trackerType: { type: Type.STRING },
                    label: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                  },
                },
                budget: { type: Type.OBJECT, properties: { amount: { type: Type.NUMBER }, durationDays: { type: Type.INTEGER }, name: { type: Type.STRING }, currency: { type: Type.STRING } }, required: ['amount', 'durationDays', 'name', 'currency'] },
                focusSession: { type: Type.OBJECT, properties: { durationMinutes: { type: Type.INTEGER }, title: { type: Type.STRING } }, required: ['durationMinutes', 'title'] },
                queryAnswer: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                  },
                },
              },
            },
          },
          required: ['intent', 'summary', 'data'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      success: true,
      rawText: text,
      ...parsed,
    });
  } catch (err: any) {
    console.error('Error in /api/ai/process-voice-command:', err);
    // Never silently misinterpret a multimodal request with the text-only fallback.
    if (req.body.imageBase64 || req.body.pdfBase64) return res.status(502).json({ success: false, error: 'تعذر تحليل المرفق الآن. جرّب مرة أخرى أو اكتب محتواه؛ لم يتم تنفيذ أي إجراء.' });
    const fallbackResult = parseVoiceCommandRuleBased(req.body.speechText, req.body.referenceDate);
    return res.json({
      success: true,
      isFallback: true,
      rawText: req.body.speechText || '',
      ...fallbackResult,
    });
  }
});

// Endpoint 1: Extract tasks from text, voice transcription, or image of schedule
app.post('/api/ai/extract-tasks', async (req: Request, res: Response) => {
  try {
    const {
      promptText,
      imageBase64,
      imageMimeType,
      pdfBase64,
      pdfMimeType,
      referenceDate,
      autoScheduleStudySessions = true,
      studyHoursPerLecture = 2,
    } = req.body;

    const basePrompt = `
أنت المساعد الذكي لتطبيق "Grip" (Hold your focus. Kill the drift).
وظيفتك استخراج جدول المهام من النص أو صورة الجدول/الورقة أو ملف الـ PDF.

تاريخ اليوم المرجعي هو: ${referenceDate || new Date().toISOString().split('T')[0]}.

القواعد الصارمة:
1. استخرج المهام بتفاصيلها:
   - title (اسم المهمة بالعربية بدقة حسب ما ورد في الجدول أو النص)
   - category: أحد القيم التالية فقط: ["study", "work", "sport", "sleep", "personal", "other"]
   - startTime: توقيت البدء بصيغة ISO كاملة (YYYY-MM-DDTHH:mm:ss)
   - endTime: توقيت الانتهاء بصيغة ISO كاملة
   - type: إما "FIXED" (للمحاضرات، المواعيد الثابتة، الامتحانات) أو "FLEXIBLE" (للمذاكرة الذاتية، التمارين المرنة)
   - notes: أي ملاحظات إضافية

2. قاعدة المحاضرات الجامعية وجلسات المذاكرة (مهمة للغاية ومطلوبة):
   عندما يحتوي الجدول أو الملف على محاضرات كلية أو دراسية:
   أ) أدرج المحاضرة نفسها كـ موعد حضور ثابت (type: "FIXED")، واكتب في العنوان: "محاضرة [اسم المادة] (حضور كليّة)"، وفي الملاحظات: "حضور بالكلية • منبه وتنبيه قبل موعد المحاضرة".
   ب) ${autoScheduleStudySessions ? `قم تلقائياً بجدولة جلسة مذاكرة ومراجعة مخصصة لكل محاضرة:
      - المدة: ${studyHoursPerLecture} ساعة (${studyHoursPerLecture * 60} دقيقة).
      - النوع: "FLEXIBLE" (مرنة)، والتصنيف: "study".
      - العنوان: "مذاكرة ومراجعة: [اسم المادة] (${studyHoursPerLecture === 2 ? 'ساعتان' : `${studyHoursPerLecture} ساعات`})".
      - الموعد: حدد موعدها في نفس اليوم في أوقات الفراغ المسائية بعد انتهاء المحاضرات (مثلاً من 17:00 إلى 19:00، أو 18:00 إلى 20:00، أو 20:00 إلى 22:00) بحيث لا تتداخل أبداً مع أي محاضرة أخرى.
      - الملاحظات: "جلسة مذاكرة وتطبيق مخصصة للمحاضرة (${studyHoursPerLecture} س) - مجدولة تلقائياً في التقويم".` : ''}

3. إذا لم يذكر تاريخاً صريحاً، افترض اليوم أو الغد حسب السياق.
4. أرجع النتيجة على شكل مصفوفة JSON من المهام.
`;

    if (!aiClient) {
      const fallbackTasks = extractTasksRuleBased(promptText, referenceDate);
      return res.json({
        success: true,
        isFallback: true,
        tasks: fallbackTasks
      });
    }

    const parts: any[] = [];
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: imageMimeType || 'image/jpeg',
          data: imageBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
        },
      });
    }
    if (pdfBase64) {
      parts.push({
        inlineData: {
          mimeType: pdfMimeType || 'application/pdf',
          data: pdfBase64.replace(/^data:application\/pdf;base64,/, ''),
        },
      });
    }
    parts.push({
      text: `${basePrompt}\n\nنص المستخدم / البيانات:\n${promptText || 'استخرج جدول المحاضرات وجلسات المذاكرة المخصصة من هذا الملف/الجدول بدقة.'}`
    });

    const response = await aiClient.models.generateContent({
      model: GEMINI_MODEL,
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              category: { type: Type.STRING },
              startTime: { type: Type.STRING },
              endTime: { type: Type.STRING },
              type: { type: Type.STRING },
              notes: { type: Type.STRING },
            },
            required: ['title', 'category', 'startTime', 'endTime', 'type'],
          },
        },
      },
    });

    const text = response.text || '[]';
    const parsed = JSON.parse(text);
    return res.json({ success: true, tasks: parsed });
  } catch (err: any) {
    console.error('Error in /api/ai/extract-tasks:', err);
    // Graceful smart rule-based fallback on any API error
    const fallbackTasks = extractTasksRuleBased(req.body.promptText, req.body.referenceDate);
    return res.json({
      success: true,
      isFallback: true,
      tasks: fallbackTasks
    });
  }
});

// Endpoint 2: Split lecture PDF / syllabus text into topics of 20-40 minutes
app.post('/api/ai/split-topics', async (req: Request, res: Response) => {
  try {
    const {
      moduleTitle,
      lectureTitle,
      contentText,
      pdfBase64,
      pdfMimeType = 'application/pdf',
      minDuration = 20,
      maxDuration = 40,
    } = req.body;

    const promptText = `
أنت المساعد الأكاديمي لتطبيق Grip.
المادة (Module): ${moduleTitle || 'مادة دراسية'}
المحاضرة (Lecture): ${lectureTitle || 'المحاضرة الأولى'}

محتوى المحاضرة / ملف الـ PDF:
"""
${contentText || (pdfBase64 ? 'محتوى ملف الـ PDF المرفق' : 'محاضرة في البرمجة الكائنية Object Oriented Programming تشمل Classes, Objects, Inheritance, Polymorphism, Abstraction, Encapsulation وتطبيقات عملية.')}
"""

المطلوب:
قسّم هذه المحاضرة / ملف الـ PDF إلى مواضيع وجلسات تركيز صغيرة متتالية، كل جلسة تتراوح مدتها الإلزامية بين ${minDuration} إلى ${maxDuration} دقيقة.
أعط لكل موضوع:
1. title: اسم الموضوع بالعربية
2. estimatedMinutes: المدة المقدرة بالدقائق (بين ${minDuration} و ${maxDuration})
3. description: ملخص سريع لما سيتم إنجازه في هذه الجلسة
4. sequenceOrder: رقم ترتيب الموضوع (1, 2, 3...)
`;

    if (!aiClient) {
      return res.json({
        success: true,
        isFallback: true,
        topics: [
          {
            title: 'المقدمة والمفاهيم الأساسية للـ PDF',
            estimatedMinutes: 25,
            description: 'فهم الفكرة العامة والمصطلحات الرئيسية من الملف المرفق',
            sequenceOrder: 1,
          },
          {
            title: 'الشرح التفصيلي والأمثلة المحلولة',
            estimatedMinutes: 35,
            description: 'دراسة الحالات العملية وتحليل القوانين/الأكواد',
            sequenceOrder: 2,
          },
          {
            title: 'حل التدريبات والمسائل التطبيقية',
            estimatedMinutes: 30,
            description: 'تطبيق مباشر واختبار الفهم الذاتي',
            sequenceOrder: 3,
          },
          {
            title: 'المراجعة وتلخيص النقاط الحرجة',
            estimatedMinutes: 20,
            description: 'كتابة ملخص سريع في بطاقات استذكار',
            sequenceOrder: 4,
          },
        ],
      });
    }

    const parts: any[] = [];
    if (pdfBase64) {
      parts.push({
        inlineData: {
          mimeType: pdfMimeType || 'application/pdf',
          data: pdfBase64.replace(/^data:[a-zA-Z0-9\/+-]+;base64,/, ''),
        },
      });
    }
    parts.push({ text: promptText });

    const response = await aiClient.models.generateContent({
      model: GEMINI_MODEL,
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              estimatedMinutes: { type: Type.INTEGER },
              description: { type: Type.STRING },
              sequenceOrder: { type: Type.INTEGER },
            },
            required: ['title', 'estimatedMinutes', 'description', 'sequenceOrder'],
          },
        },
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    return res.json({ success: true, topics: parsed });
  } catch (err: any) {
    console.error('Error in /api/ai/split-topics:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'حدث خطأ أثناء تقسيم المحاضرة',
      topics: [
        {
          title: 'الجزء الأول من المحاضرة',
          estimatedMinutes: 30,
          description: 'مراجعة الأساسيات',
          sequenceOrder: 1,
        },
        {
          title: 'الجزء الثاني والتطبيقات',
          estimatedMinutes: 30,
          description: 'حل تمارين وتطبيق عملي',
          sequenceOrder: 2,
        },
      ],
    });
  }
});

// Explicit routes for Google Play Store compliance
app.get(['/privacy', '/privacy.html'], (_req: Request, res: Response) => {
  const isProd = process.env.NODE_ENV === 'production';
  const filePath = isProd
    ? path.resolve(__dirname, 'dist', 'privacy.html')
    : path.resolve(__dirname, 'public', 'privacy.html');
  res.sendFile(filePath);
});

app.get('/.well-known/assetlinks.json', (_req: Request, res: Response) => {
  const isProd = process.env.NODE_ENV === 'production';
  const filePath = isProd
    ? path.resolve(__dirname, 'dist', '.well-known', 'assetlinks.json')
    : path.resolve(__dirname, 'public', '.well-known', 'assetlinks.json');
  res.setHeader('Content-Type', 'application/json');
  res.sendFile(filePath);
});

// Setup Vite middleware in development or serve static in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('/grip-onboarding.html', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'grip-onboarding.html'));
    });
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Grip Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
