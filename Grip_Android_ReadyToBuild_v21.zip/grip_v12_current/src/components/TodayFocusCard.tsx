import React, { useEffect, useMemo, useState } from 'react';
import { Play, CheckCircle2, Mic, Plus, Flame, Clock, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';
import { GripTask } from '../types/grip';

interface Props {
  tasks: GripTask[];
  streakDays: number;
  onStart: (task: GripTask) => void;
  onFinish: (task: GripTask) => void;
  onAddTask: () => void;
  onVoice: () => void;
}

const isDone = (t: GripTask) => t.status === 'done' || t.status === 'done_early';
const minutesBetween = (a: string, b: string) => Math.max(0, Math.round((new Date(b).getTime() - new Date(a).getTime()) / 60000));
const sameDay = (a: Date, b: Date) => a.toDateString() === b.toDateString();
const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' });
const fmtMinutes = (m: number) => (m >= 60 ? `${Math.floor(m / 60)} س ${m % 60 ? `${m % 60} د` : ''}`.trim() : `${m} د`);

/**
 * The first thing a user sees: ONE thing to do now, plus a few real numbers.
 * Fewer choices = less procrastination.
 */
export const TodayFocusCard: React.FC<Props> = ({ tasks, streakDays, onStart, onFinish, onAddTask, onVoice }) => {
  const [now, setNow] = useState(() => Date.now());
  const [showWeek, setShowWeek] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);

  const real = useMemo(() => tasks.filter((t) => !t.isWakeUpAlarm && t.category !== 'wake_up'), [tasks]);

  const running = real.find((t) => t.status === 'in_progress');
  const upcoming = useMemo(
    () =>
      real
        .filter((t) => t.status === 'pending' && new Date(t.endTime).getTime() > now)
        .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())[0],
    [real, now]
  );

  const today = new Date(now);
  const doneToday = real.filter((t) => isDone(t) && sameDay(new Date(t.completedAt || t.startTime), today));
  const focusToday = doneToday.reduce((sum, t) => sum + minutesBetween(t.startTime, t.endTime), 0);

  const week = useMemo(() => {
    const from = now - 7 * 86400000;
    const inWeek = real.filter((t) => new Date(t.startTime).getTime() >= from && new Date(t.startTime).getTime() <= now);
    const done = inWeek.filter(isDone);
    return {
      total: inWeek.length,
      done: done.length,
      minutes: done.reduce((s, t) => s + minutesBetween(t.startTime, t.endTime), 0),
      rate: inWeek.length ? Math.round((done.length / inWeek.length) * 100) : 0,
    };
  }, [real, now]);

  // ---- First day: nothing yet
  if (real.length === 0) {
    return (
      <div className="rounded-3xl p-5 bg-gradient-to-br from-[#6D28D9] to-[#4C1D95] text-white shadow-lg" dir="rtl">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="w-5 h-5 text-purple-200" />
          <h2 className="text-lg font-black">ابدأ بأول مهمة</h2>
        </div>
        <p className="text-sm text-purple-100 mb-4 font-semibold">قول لي إيه اللي عندك النهارده وأنا أرتبه لك، أو أضفه بنفسك في 10 ثواني.</p>
        <div className="flex gap-2">
          <button
            onClick={onVoice}
            className="flex-1 min-h-[48px] rounded-2xl bg-white text-[#4C1D95] font-black flex items-center justify-center gap-2"
          >
            <Mic className="w-5 h-5" />
            <span>قول بصوتك</span>
          </button>
          <button
            onClick={onAddTask}
            className="flex-1 min-h-[48px] rounded-2xl bg-white/15 border border-white/30 text-white font-black flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            <span>أضف مهمة</span>
          </button>
        </div>
      </div>
    );
  }

  const stat = (icon: React.ReactNode, value: string, label: string) => (
    <div className="flex-1 rounded-2xl bg-slate-50 dark:bg-slate-800/60 p-3 text-center">
      <div className="flex items-center justify-center gap-1 text-purple-600 dark:text-purple-300 mb-0.5">{icon}</div>
      <div className="text-base font-black text-slate-900 dark:text-white">{value}</div>
      <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{label}</div>
    </div>
  );

  return (
    <div className="rounded-3xl p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm" dir="rtl">
      {running ? (
        <div className="rounded-2xl p-4 bg-gradient-to-br from-emerald-600 to-teal-700 text-white mb-3">
          <p className="text-xs font-bold text-emerald-100 mb-1">شغّال دلوقتي</p>
          <h2 className="text-lg font-black leading-snug">{running.title}</h2>
          <p className="text-sm text-emerald-100 font-semibold mt-1">
            يخلص {fmtTime(running.endTime)} • فاضل {fmtMinutes(Math.max(0, Math.round((new Date(running.endTime).getTime() - now) / 60000)))}
          </p>
          <button
            onClick={() => onFinish(running)}
            className="mt-3 w-full min-h-[48px] rounded-2xl bg-white text-emerald-800 font-black flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>خلّصت</span>
          </button>
        </div>
      ) : upcoming ? (
        <div className="rounded-2xl p-4 bg-gradient-to-br from-[#6D28D9] to-[#4C1D95] text-white mb-3">
          <p className="text-xs font-bold text-purple-200 mb-1">
            {new Date(upcoming.startTime).getTime() <= now ? 'وقتها جه' : `الجاية • ${fmtTime(upcoming.startTime)}`}
          </p>
          <h2 className="text-lg font-black leading-snug">{upcoming.title}</h2>
          <p className="text-sm text-purple-200 font-semibold mt-1">{fmtMinutes(minutesBetween(upcoming.startTime, upcoming.endTime))}</p>
          <button
            onClick={() => onStart(upcoming)}
            className="mt-3 w-full min-h-[48px] rounded-2xl bg-white text-[#4C1D95] font-black flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5" />
            <span>ابدأ دلوقتي</span>
          </button>
        </div>
      ) : (
        <div className="rounded-2xl p-4 bg-slate-50 dark:bg-slate-800/60 mb-3 text-center">
          <p className="font-black text-slate-900 dark:text-white">خلّصت كل مهامك المجدولة 👏</p>
          <button onClick={onVoice} className="mt-2 min-h-[44px] px-4 rounded-2xl bg-[#6D28D9] text-white font-black text-sm inline-flex items-center gap-2">
            <Mic className="w-4 h-4" />
            <span>أضف حاجة جديدة</span>
          </button>
        </div>
      )}

      <div className="flex gap-2">
        {stat(<CheckCircle2 className="w-4 h-4" />, String(doneToday.length), 'أنجزت النهارده')}
        {stat(<Clock className="w-4 h-4" />, fmtMinutes(focusToday), 'وقت تركيز')}
        {stat(<Flame className="w-4 h-4" />, String(streakDays), 'أيام متتالية')}
      </div>

      <button
        onClick={() => setShowWeek((v) => !v)}
        className="mt-3 w-full min-h-[44px] flex items-center justify-between px-3 rounded-2xl text-sm font-black text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60"
        aria-expanded={showWeek}
      >
        <span>ملخص آخر 7 أيام</span>
        {showWeek ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {showWeek && (
        <div className="mt-1 rounded-2xl bg-slate-50 dark:bg-slate-800/60 p-3 text-sm font-semibold text-slate-700 dark:text-slate-200 space-y-1.5">
          <p>
            أنجزت <b>{week.done}</b> من <b>{week.total}</b> مهمة ({week.rate}%)
          </p>
          <p>
            وقت التركيز الكلي: <b>{fmtMinutes(week.minutes)}</b>
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {week.total === 0
              ? 'لسه مفيش بيانات كفاية. كمّل وهتظهر لك الصورة.'
              : week.rate >= 70
              ? 'أسبوع قوي، كمّل بنفس الإيقاع.'
              : 'كل مهمة بدأتها تُحسب. ابدأ بحاجة صغيرة النهارده.'}
          </p>
        </div>
      )}
    </div>
  );
};
