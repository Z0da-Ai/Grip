import React, { useState, useEffect, useRef } from 'react';
import { GripTask, GripSettings } from '../types/grip';
import { hapticFeedback } from '../services/haptics';
import { calculateRequiredHoldSeconds, canMarkTaskDoneEarly } from '../services/enforcementPolicy';
import { Check } from 'lucide-react';

interface EnforcementOverlayProps {
  task: GripTask;
  settings: GripSettings;
  onPostponeSuccess: (task: GripTask, freeWindowMinutes: number) => void;
  onDoneEarly: (task: GripTask) => void;
  onStart?: (task: GripTask) => void;
  onClosePreview?: () => void;
  isSimulatedInApp?: boolean;
}

export const EnforcementOverlay: React.FC<EnforcementOverlayProps> = ({
  task,
  settings,
  onPostponeSuccess,
  onDoneEarly,
  onStart,
  onClosePreview,
}) => {
  // Preserve the core escalation: first 3 postpones = 10s, 4th-6th = 20s, 7th onward = 30s.
  const currentHoldRequired = calculateRequiredHoldSeconds(
    task.postponeCount,
    settings.baseHoldSeconds || 10,
    settings.midHoldSeconds || 20,
    settings.maxHoldSeconds || 30,
  );
  const nextHoldSeconds = calculateRequiredHoldSeconds(
    task.postponeCount + 1,
    settings.baseHoldSeconds || 10,
    settings.midHoldSeconds || 20,
    settings.maxHoldSeconds || 30,
  );

  // Holding state for "فكرني بعدين"
  const [holdingProgress, setHoldingProgress] = useState(0); // 0 to 100
  const [heldSeconds, setHeldSeconds] = useState(0);
  const [isHolding, setIsHolding] = useState(false);

  // Early completion is valid only at least 5 full minutes before the scheduled end.
  const [nowMs, setNowMs] = useState(() => Date.now());
  const earlyCompletionAllowed = canMarkTaskDoneEarly(task.endTime, nowMs);

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Holding state for "خلّصت بدري" (exactly 2 seconds hold)
  const [isDoneEarlyHolding, setIsDoneEarlyHolding] = useState(false);
  const [doneEarlyProgress, setDoneEarlyProgress] = useState(0); // 0 to 100


  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const doneEarlyIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
      if (doneEarlyIntervalRef.current) clearInterval(doneEarlyIntervalRef.current);
      if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    };
  }, []);

  // Trigger vibration helper
  const triggerWarningVibration = () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([150, 80, 150]);
      } catch {
        // ignore
      }
    }
  };

  // START "فكرني بعدين" Hold
  const startHold = () => {
    setIsHolding(true);
    const startTime = Date.now();
    const durationMs = currentHoldRequired * 1000;

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / durationMs) * 100);
      const secs = (elapsed / 1000).toFixed(1);

      setHoldingProgress(progress);
      setHeldSeconds(parseFloat(secs));

        if (elapsed >= durationMs) {
          if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
          setIsHolding(false);
          setHoldingProgress(100);
          hapticFeedback.heavy();

          // Show dark toast before triggering callback
          const freeMins = 5; // Grip uses a consistent five-minute window between postpones.
          setToastMessage(`تمام، تم منح نافذة حرة لمدة ${freeMins} دقائق`);
          toastTimeoutRef.current = setTimeout(() => {
            onPostponeSuccess(task, freeMins);
          }, 1100);
        }
    }, 35);
  };

  // CANCEL "فكرني بعدين" Hold with Penalty (Reset to 0 + Vibration)
  const cancelHold = () => {
    if (!isHolding) return;
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
    // A released hold simply resets; avoid punitive vibration or shaming language.
    setIsHolding(false);
    setHoldingProgress(0);
    setHeldSeconds(0);
    setToastMessage('لم يكتمل الضغط؛ يمكنك المحاولة مرة أخرى.');
    setTimeout(() => setToastMessage(null), 2000);
  };

  // START "خلّصت بدري" Hold (2 seconds = 2000 ms)
  const startDoneEarlyHold = () => {
    if (!earlyCompletionAllowed) return;
    setIsDoneEarlyHolding(true);
    const startTime = Date.now();
    const durationMs = 2000; // 2 seconds

    doneEarlyIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / durationMs) * 100);
      setDoneEarlyProgress(progress);

      if (elapsed >= durationMs) {
        if (doneEarlyIntervalRef.current) clearInterval(doneEarlyIntervalRef.current);
        doneEarlyIntervalRef.current = null;
        setIsDoneEarlyHolding(false);
        setDoneEarlyProgress(100);

        // Re-check at confirmation time so a hold cannot cross the five-minute cutoff.
        if (!canMarkTaskDoneEarly(task.endTime, Date.now())) {
          setToastMessage('لازم يتبقى 5 دقائق كاملة على نهاية المهمة.');
          setTimeout(() => setToastMessage(null), 2000);
          setDoneEarlyProgress(0);
          return;
        }
        setToastMessage('أحسنت! تم إنجاز المهمة بنجاح.');
        toastTimeoutRef.current = setTimeout(() => {
          onDoneEarly(task);
        }, 1200);
      }
    }, 35);
  };

  // CANCEL "خلّصت بدري" Hold
  const cancelDoneEarlyHold = () => {
    if (!isDoneEarlyHolding) return;
    if (doneEarlyIntervalRef.current) {
      clearInterval(doneEarlyIntervalRef.current);
      doneEarlyIntervalRef.current = null;
    }
    setIsDoneEarlyHolding(false);
    setDoneEarlyProgress(0);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#F8F9FA] text-[#1F2433] select-none p-3 sm:p-5"
      dir="rtl"
    >
      {/* Phone container: max-w-[420px], all inside ONE screen, no scrolling */}
      <div className="w-full max-w-[420px] h-full max-h-[920px] flex flex-col justify-between items-center py-2 sm:py-3">
        {/* 1. Header: Logo (40x40, radius 12, white bold "G") next to bold "Grip" */}
        <div className="w-full flex items-center justify-start gap-2.5 pt-1">
          <div className="w-10 h-10 rounded-[12px] bg-[#6D28D9] flex items-center justify-center font-['Plus_Jakarta_Sans',sans-serif] font-black text-xl text-white shadow-xs">
            G
          </div>
          <span className="font-['Plus_Jakarta_Sans',sans-serif] font-black text-xl text-[#1F2433] tracking-wide">
            Grip
          </span>
        </div>

        {/* 2. Small pill: Lavender bg, purple text, 13px */}
        <div className="px-3.5 py-1 rounded-full bg-[#E9E3FB] text-[#6D28D9] text-[13px] font-bold">
          جلسة التركيز الحالية
        </div>

        {/* 3. Task title: 23px bold, dark text */}
        <h2 className="text-[23px] font-black text-[#1F2433] text-center leading-snug px-3 line-clamp-2">
          {task.title}
        </h2>

        {/* 4. Main message card: Lavender bg (#E9E3FB), radius 20, padding 16 */}
        <div className="w-full p-4 rounded-[20px] bg-[#E9E3FB] text-center">
          <h3 className="text-[24px] font-black text-[#6D28D9] leading-tight">
            يلا خلّصها
          </h3>
          <p className="text-[13px] text-purple-700 font-bold mt-0.5">
            امسك تركيزك.. واقطع السرحان
          </p>
          <p className="text-[12px] text-[#6B7280] font-medium mt-1 leading-normal">
            مفيش زر بدء لأنك في وقتها بالفعل. ابدأ دلوقتي واهزم التسويف.
          </p>
        </div>

        {/* 5. Two stat boxes side by side, radius 14 */}
        <div className="w-full grid grid-cols-2 gap-3">
          {/* Peach Box: big number (postpone count) + label "مرات التأجيل للمهمة" */}
          <div className="p-3 rounded-[14px] bg-[#FDE8DC] text-center flex flex-col items-center justify-center">
            <span className="text-[22px] font-black text-[#B4531F] leading-tight">
              {task.postponeCount}
            </span>
            <span className="text-[11px] font-semibold text-[#B4531F] mt-0.5">
              مرات التأجيل للمهمة
            </span>
          </div>

          {/* White Box with 1px lavender border: big purple number + label "الضغطة القادمة" */}
          <div className="p-3 rounded-[14px] bg-white border border-[#E9E3FB] text-center flex flex-col items-center justify-center shadow-xs">
            <span className="text-[22px] font-black text-[#6D28D9] leading-tight">
              {nextHoldSeconds} ث
            </span>
            <span className="text-[11px] font-semibold text-[#6B7280] mt-0.5">
              الضغطة القادمة
            </span>
          </div>
        </div>

        {/* 6. Hold ring: 150px circle, track lavender #E9E3FB, filled progress purple #7C3AED */}
        <div className="flex flex-col items-center justify-center my-1">
          <div
            onPointerDown={startHold}
            onPointerUp={cancelHold}
            onPointerLeave={cancelHold}
            onPointerCancel={cancelHold}
            style={{
              background: `conic-gradient(#7C3AED ${holdingProgress * 3.6}deg, #E9E3FB 0deg)`,
              touchAction: 'none',
            }}
            className="w-[145px] h-[145px] rounded-full flex items-center justify-center cursor-pointer select-none transition-transform duration-150 active:scale-95 shadow-md"
          >
            {/* Inside white circle with soft purple shadow */}
            <div className="w-[122px] h-[122px] rounded-full bg-white shadow-[0_4px_16px_rgba(109,40,217,0.12)] flex flex-col items-center justify-center text-center px-2">
              <span className="text-[15px] font-black text-[#1F2433]">
                فكرني بعدين
              </span>
              <span className="text-[11px] text-[#6B7280] font-medium mt-0.5">
                {isHolding ? `${heldSeconds} ث` : `اضغط مطولاً (${currentHoldRequired}ث)`}
              </span>
            </div>
          </div>
        </div>

        {/* 7. Small muted note (12px) */}
        <p className="text-[11px] text-[#6B7280] text-center font-medium px-4">
          كمّل الضغط من غير ما ترفع إصبعك. لو رفعته العداد هيرجع للصفر مع اهتزاز تحذيري.
        </p>

        {/* 8. Full-width mint button, radius 16, bold mint-dark text: "تم بدري (اضغط مطوّلًا ثانيتين)" */}
        {onStart && (
          <button
            type="button"
            onClick={() => onStart(task)}
            className="w-full min-h-[52px] rounded-[16px] bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-black text-[15px] shadow-lg"
          >
            ابدأ الآن
          </button>
        )}

        {earlyCompletionAllowed ? (
        <div className="w-full relative rounded-[16px] overflow-hidden select-none">
          <button
            type="button"
            onPointerDown={startDoneEarlyHold}
            onPointerUp={cancelDoneEarlyHold}
            onPointerLeave={cancelDoneEarlyHold}
            onPointerCancel={cancelDoneEarlyHold}
            className="w-full relative py-3 px-4 bg-[#DDF4EA] text-[#0F6B4A] font-bold text-[13px] flex items-center justify-center cursor-pointer overflow-hidden transition-all duration-150 active:scale-[0.99]"
            style={{ touchAction: 'none' }}
          >
            {/* While holding, darker mint overlay fills from right to left (RTL) */}
            <div
              className="absolute inset-y-0 right-0 bg-[#B8E8D2] transition-all duration-75 pointer-events-none"
              style={{
                width: `${doneEarlyProgress}%`,
                opacity: isDoneEarlyHolding ? 1 : 0,
              }}
            />

            <span className="relative z-10 font-black flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4 stroke-[3]" />
              <span>تم بدري (اضغط مطوّلًا ثانيتين)</span>
            </span>
          </button>
        </div>
        ) : (
          <p className="w-full text-center text-[11px] font-semibold text-slate-500 px-3">
            يتاح «أنهيتها مبكرًا» فقط إذا بقيت 5 دقائق كاملة أو أكثر على موعد نهاية المهمة.
          </p>
        )}

        <div className="w-full flex flex-col items-center gap-2">
          {onClosePreview && (
            <button
              type="button"
              onClick={onClosePreview}
              className="text-[10px] text-slate-400 hover:text-slate-700 underline"
            >
              إغلاق المعاينة
            </button>
          )}
        </div>
      </div>

      {/* 10. Small dark toast at the bottom */}
      {toastMessage && (
        <div className="fixed bottom-6 z-60 px-5 py-2.5 rounded-full bg-[#1F2433] text-white text-[13px] font-bold shadow-xl animate-fadeIn">
          {toastMessage}
        </div>
      )}
    </div>
  );
};
