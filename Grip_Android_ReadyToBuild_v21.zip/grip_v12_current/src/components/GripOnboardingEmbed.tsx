import React, { useCallback, useEffect, useRef } from 'react';
import { GripUser } from '../types/grip';
import { storage } from '../services/storage';

interface GripOnboardingEmbedProps {
  onComplete: (user?: GripUser) => void;
  isDarkMode?: boolean;
}

export const GripOnboardingEmbed: React.FC<GripOnboardingEmbedProps> = ({
  onComplete,
  isDarkMode,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const completedRef = useRef(false);

  const completeOnboarding = useCallback(() => {
    // The iframe emits both a DOM event and a callback; guard against duplicate completion.
    if (completedRef.current) return;
    completedRef.current = true;
    try {
      localStorage.setItem('grip_onboarding_seen', '1');
    } catch (_) {}
    const localUser: GripUser = {
      id: `guest-${Date.now()}`,
      name: 'مستخدم Grip',
      email: '',
      isDeveloper: false,
      isGoogleUser: false,
      authProvider: 'guest',
      joinedAt: new Date().toISOString(),
    };
    storage.saveUser(localUser);
    onComplete(localUser);
  }, [onComplete]);

  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data === 'grip:onboarding-done' || (e.data && e.data.type === 'grip:onboarding-done')) {
        completeOnboarding();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [completeOnboarding]);

  const handleIframeLoad = () => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    try {
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      const win = iframe.contentWindow as any;

      if (doc && isDarkMode !== undefined) {
        doc.documentElement.setAttribute('data-theme', isDarkMode ? 'dark' : 'light');
      }

      if (win) {
        // Callback defined in grip-onboarding.html:
        // if(typeof window.onGripOnboardingDone==='function')window.onGripOnboardingDone();
        win.onGripOnboardingDone = completeOnboarding;
      }

      if (doc) {
        // The iframe's event and callback may both fire; completion is idempotent.
        doc.addEventListener('grip:onboarding-done', completeOnboarding);
      }
    } catch (err) {
      console.warn('Cross-frame setup warning in GripOnboardingEmbed:', err);
    }
  };

  return (
    <div
      className="fixed inset-0 w-full h-full z-[2147483000] bg-[#F8F9FA] dark:bg-[#0F1117] select-none"
      style={{ isolation: 'isolate' }}
    >
      <iframe
        ref={iframeRef}
        src="/grip-onboarding.html"
        title="Grip Onboarding"
        onLoad={handleIframeLoad}
        className="w-full h-full border-0 block"
        style={{
          width: '100%',
          height: '100%',
          border: 'none',
          backgroundColor: isDarkMode ? '#0F1117' : '#F8F9FA',
        }}
        allow="autoplay"
      />
    </div>
  );
};
