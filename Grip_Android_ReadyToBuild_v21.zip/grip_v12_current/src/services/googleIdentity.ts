/**
 * Google identity for the local Grip profile.
 * This proves the selected Google identity to the client through Google's userinfo API;
 * it does not create a server-side account or upload app data by itself.
 */
const CLIENT_ID = ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string | undefined) || '';
const SCOPE = 'openid email profile';

type GoogleProfile = { sub: string; email: string; name?: string; picture?: string; email_verified?: boolean };

export const isGoogleIdentityConfigured = () => CLIENT_ID.trim().length > 0;
let scriptPromise: Promise<void> | null = null;

function loadGoogleIdentity(): Promise<void> {
  if ((window as any).google?.accounts?.oauth2) return Promise.resolve();
  if (scriptPromise) return scriptPromise;
  scriptPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => {
      scriptPromise = null;
      reject(new Error('تعذر تحميل تسجيل Google. تأكد من اتصال الإنترنت.'));
    };
    document.head.appendChild(script);
  });
  return scriptPromise;
}

export async function signInWithGoogle(): Promise<GoogleProfile> {
  if (!CLIENT_ID) throw new Error('تسجيل Google غير مهيأ بعد. يجب ضبط VITE_GOOGLE_CLIENT_ID في إعدادات النشر.');
  await loadGoogleIdentity();
  const token = await new Promise<string>((resolve, reject) => {
    try {
      const client = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPE,
        include_granted_scopes: true,
        callback: (response: any) => {
          if (response?.error || !response?.access_token) {
            reject(new Error('لم يكتمل تسجيل الدخول بحساب Google.'));
            return;
          }
          resolve(response.access_token as string);
        },
        error_callback: () => reject(new Error('تم إغلاق نافذة تسجيل Google أو تعذر فتحها.')),
      });
      client.requestAccessToken({ prompt: 'select_account' });
    } catch {
      reject(new Error('تعذر بدء تسجيل الدخول بحساب Google.'));
    }
  });

  const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error('لم نستطع التحقق من بيانات حساب Google.');
  const profile = (await response.json()) as GoogleProfile;
  if (!profile.sub || !profile.email || profile.email_verified !== true) {
    throw new Error('حساب Google لم يُرجع بريدًا إلكترونيًا موثّقًا.');
  }
  return profile;
}
