export type GripAssistantLocale = 'en' | 'ar-eg' | 'ar-neutral';

/** Match the user's chosen speech language; do not assume all Arabic speakers prefer Egyptian. */
export function assistantLocaleFromSpeechLanguage(language: string): GripAssistantLocale {
  if (language === 'en-US' || language.toLowerCase().startsWith('en')) return 'en';
  if (language === 'ar-EG') return 'ar-eg';
  return 'ar-neutral';
}

export function assistantLocaleInstruction(locale: GripAssistantLocale): string {
  switch (locale) {
    case 'en':
      return 'Reply in natural, concise English. Keep UI action summaries and spoken feedback in English. Understand Arabic input too, but follow the user\'s selected response language.';
    case 'ar-eg':
      return 'رد باللهجة المصرية الطبيعية المهذبة، من غير مبالغة أو افتعال. افهم العامية المصرية والفصحى والإنجليزية المختلطة. حافظ على أسماء المواد والمصطلحات التقنية عند الحاجة.';
    default:
      return 'رد بالعربية الواضحة القريبة من الفصحى، وافهم الفصحى واللهجات العربية المختلفة ومنها المصرية والخليجية والشامية. لا تفترض أن كل المستخدمين يفضلون اللهجة المصرية.';
  }
}
