/**
 * Optional Google Drive backup (browser / installed web app).
 * Uses Google Identity Services + a visible Grip Backups folder. The drive.file scope limits
 * access to files created/opened by Grip rather than the user's entire Drive.
 * Needs VITE_GOOGLE_CLIENT_ID (a free OAuth Web client ID from Google Cloud Console).
 */
const CLIENT_ID = ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID as string | undefined) || '';
const SCOPE = 'https://www.googleapis.com/auth/drive.file';
const FILE_NAME = 'grip-backup.json';
const LINKED_KEY = 'grip_drive_linked_v1';

const isNative = () => !!(window as any).Capacitor?.isNativePlatform?.();

/** The Drive section is shown only when it can really work. */
export const isDriveAvailable = () => CLIENT_ID !== '' && !isNative();
export const isDriveLinked = () => { try { return localStorage.getItem(LINKED_KEY) === '1'; } catch { return false; } };

/** Explicit user-initiated connection. Access tokens are kept in memory, never localStorage. */
export async function connectGoogleDrive(): Promise<void> {
  await getToken();
  localStorage.setItem(LINKED_KEY, '1');
}

export function disconnectGoogleDrive(): void {
  try { localStorage.removeItem(LINKED_KEY); } catch { /* storage may be unavailable */ }
  accessToken = '';
  expiresAt = 0;
}

let gisLoading: Promise<void> | null = null;
function loadGis(): Promise<void> {
  if ((window as any).google?.accounts?.oauth2) return Promise.resolve();
  if (gisLoading) return gisLoading;
  gisLoading = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      gisLoading = null;
      reject(new Error('تعذر الاتصال بخدمة جوجل. تأكد من الإنترنت.'));
    };
    document.head.appendChild(s);
  });
  return gisLoading;
}

let accessToken = '';
let expiresAt = 0;
let pending: { resolve: (t: string) => void; reject: (e: Error) => void } | null = null;
let tokenClient: any = null;

async function getToken(): Promise<string> {
  if (accessToken && Date.now() < expiresAt) return accessToken;
  await loadGis();
  return new Promise<string>((resolve, reject) => {
    pending = { resolve, reject };
    if (!tokenClient) {
      tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPE,
        callback: (r: any) => {
          if (r.error || !r.access_token) {
            pending?.reject(new Error('لم يتم السماح بالوصول إلى Drive.'));
          } else {
            accessToken = r.access_token;
            expiresAt = Date.now() + (Number(r.expires_in) || 3000) * 1000 - 60000;
            pending?.resolve(accessToken);
          }
          pending = null;
        },
        error_callback: () => {
          pending?.reject(new Error('تم إغلاق نافذة تسجيل الدخول.'));
          pending = null;
        },
      });
    }
    tokenClient.requestAccessToken({ prompt: accessToken ? '' : 'consent' });
  });
}

async function getOrCreateBackupFolder(token: string): Promise<string> {
  const q = encodeURIComponent("name='Grip Backups' and mimeType='application/vnd.google-apps.folder' and trashed=false");
  const found = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name)&pageSize=10`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!found.ok) throw new Error('تعذر البحث عن مجلد النسخ الاحتياطية في Drive.');
  const data = await found.json();
  if (data.files?.[0]?.id) return data.files[0].id as string;

  const created = await fetch('https://www.googleapis.com/drive/v3/files?fields=id,name', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Grip Backups', mimeType: 'application/vnd.google-apps.folder' }),
  });
  if (!created.ok) throw new Error('تعذر إنشاء مجلد Grip Backups في Drive.');
  const folder = await created.json();
  if (!folder.id) throw new Error('لم يرجع Google معرّف مجلد النسخ الاحتياطية.');
  return folder.id as string;
}

async function findBackupFile(token: string, folderId: string): Promise<{ id: string; modifiedTime: string } | null> {
  const q = encodeURIComponent(`name='${FILE_NAME}' and '${folderId}' in parents and trashed=false`);
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,modifiedTime)&pageSize=1`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw new Error('تعذر الوصول إلى ملفات Grip Backups في Drive.');
  const data = await res.json();
  return data.files && data.files[0] ? data.files[0] : null;
}

export async function backupToDrive(json: string): Promise<string> {
  const token = await getToken();
  const folderId = await getOrCreateBackupFolder(token);
  const existing = await findBackupFile(token, folderId);
  let res: Response;
  if (existing) {
    res = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${existing.id}?uploadType=media`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: json,
    });
  } else {
    const boundary = 'grip' + Math.random().toString(36).slice(2);
    const body =
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` +
      JSON.stringify({ name: FILE_NAME, parents: [folderId] }) +
      `\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${json}\r\n--${boundary}--`;
    res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': `multipart/related; boundary=${boundary}` },
      body,
    });
  }
  if (!res.ok) throw new Error('فشل رفع النسخة إلى Drive.');
  return new Date().toISOString();
}

/**
 * Best-effort foreground auto-sync. It never opens an OAuth popup on its own:
 * if the short-lived token is missing/expired, the UI must ask the user to reconnect.
 */
export function installForegroundDriveAutoSync(getBackupJson: () => string): () => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  let running = false;
  const schedule = () => {
    if (!isDriveLinked() || !accessToken || Date.now() >= expiresAt || !navigator.onLine) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(async () => {
      if (running || !isDriveLinked() || !accessToken || Date.now() >= expiresAt || !navigator.onLine) return;
      running = true;
      try {
        await backupToDrive(getBackupJson());
        window.dispatchEvent(new CustomEvent('grip:drive-sync-status', { detail: { status: 'synced', at: new Date().toISOString() } }));
      } catch (error) {
        window.dispatchEvent(new CustomEvent('grip:drive-sync-status', { detail: { status: 'error', message: error instanceof Error ? error.message : 'فشلت المزامنة.' } }));
      } finally { running = false; }
    }, 1800);
  };
  window.addEventListener('grip:data-changed', schedule);
  window.addEventListener('online', schedule);
  return () => {
    if (timer) clearTimeout(timer);
    window.removeEventListener('grip:data-changed', schedule);
    window.removeEventListener('online', schedule);
  };
}

export async function restoreFromDrive(): Promise<string | null> {
  const token = await getToken();
  const folderId = await getOrCreateBackupFolder(token);
  const file = await findBackupFile(token, folderId);
  if (!file) return null;
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error('تعذر تنزيل النسخة من Drive.');
  return await res.text();
}
