import { GripTask } from '../types/grip';

const SLOT_MS = 15 * 60 * 1000;
const DAY_START_HOUR = 8;
const DAY_END_HOUR = 22;
const MAX_SEARCH_DAYS = 7;

function ceilToSlot(timestamp: number): number {
  return Math.ceil(timestamp / SLOT_MS) * SLOT_MS;
}

function nextDayAtEight(date: Date): number {
  const next = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1, DAY_START_HOUR, 0, 0, 0);
  return next.getTime();
}

/**
 * Reschedule a flexible task into the first free 15-minute slot during 08:00–22:00.
 * The optional clock parameter makes behavior deterministic in tests. If the input is
 * invalid or no slot exists within the search horizon, the original task is returned.
 */
export function autoRescheduleFlexibleTask(
  taskToReschedule: GripTask,
  allTasks: GripTask[],
  now: Date = new Date()
): GripTask {
  if (taskToReschedule.type !== 'FLEXIBLE' || !Number.isFinite(now.getTime())) return taskToReschedule;

  const originalStart = new Date(taskToReschedule.startTime).getTime();
  const originalEnd = new Date(taskToReschedule.endTime).getTime();
  if (!Number.isFinite(originalStart) || !Number.isFinite(originalEnd) || originalEnd <= originalStart) {
    return taskToReschedule;
  }
  const durationMs = originalEnd - originalStart;
  if (!Number.isFinite(durationMs) || durationMs <= 0) return taskToReschedule;

  const occupied = allTasks
    .filter((task) => task.id !== taskToReschedule.id && task.status !== 'missed')
    .map((task) => ({
      start: new Date(task.startTime).getTime(),
      end: new Date(task.endTime).getTime(),
    }))
    .filter((interval) => Number.isFinite(interval.start) && Number.isFinite(interval.end) && interval.end > interval.start)
    .sort((a, b) => a.start - b.start);

  let cursor = ceilToSlot(now.getTime());
  const searchLimit = cursor + MAX_SEARCH_DAYS * 24 * 60 * 60 * 1000;

  while (cursor < searchLimit) {
    const date = new Date(cursor);
    const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate(), DAY_START_HOUR, 0, 0, 0).getTime();
    const dayEnd = new Date(date.getFullYear(), date.getMonth(), date.getDate(), DAY_END_HOUR, 0, 0, 0).getTime();

    // Do not schedule before 08:00 or after 22:00, and never let a task cross the boundary.
    if (cursor < dayStart) {
      cursor = dayStart;
      continue;
    }
    if (cursor >= dayEnd || cursor + durationMs > dayEnd) {
      cursor = nextDayAtEight(date);
      continue;
    }

    const candidateEnd = cursor + durationMs;
    const conflict = occupied.find((interval) => cursor < interval.end && candidateEnd > interval.start);
    if (!conflict) {
      const notes = taskToReschedule.notes || '';
      const rescheduleNote = 'أعيدت جدولتها آلياً لمنع التضارب';
      const cleanNotes = notes.split(' • ').filter((note) => note !== rescheduleNote).join(' • ');
      return {
        ...taskToReschedule,
        startTime: new Date(cursor).toISOString(),
        endTime: new Date(candidateEnd).toISOString(),
        status: 'pending',
        notes: cleanNotes ? `${cleanNotes} • ${rescheduleNote}` : rescheduleNote,
      };
    }

    // Jump to the next 15-minute boundary after the conflicting task ends. This avoids
    // skipping a valid quarter-hour slot while still preventing an overlap.
    cursor = ceilToSlot(Math.max(cursor + SLOT_MS, conflict.end));
  }

  return taskToReschedule;
}
