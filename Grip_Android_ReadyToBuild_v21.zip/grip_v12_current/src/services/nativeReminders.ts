/**
 * Android task reminders through Capacitor Local Notifications.
 * Browser/PWA mode intentionally does not claim background delivery after the app is closed.
 */
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { GripTask } from '../types/grip';

const isNative = () => Capacitor.isNativePlatform();

const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h) % 2000000000;
};

let permissionAsked = false;

export async function syncNativeReminders(tasks: GripTask[]): Promise<void> {
  if (!isNative()) return;
  try {
    if (!permissionAsked) {
      permissionAsked = true;
      let permission = await LocalNotifications.checkPermissions();
      if (permission.display !== 'granted') permission = await LocalNotifications.requestPermissions();
      if (permission.display !== 'granted') return;
    }

    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length) {
      await LocalNotifications.cancel({ notifications: pending.notifications.map(({ id }) => ({ id })) });
    }

    const now = Date.now();
    const horizon = now + 7 * 86400000;
    const notifications: Array<{
      id: number;
      title: string;
      body: string;
      schedule: { at: Date; allowWhileIdle: boolean; repeats?: boolean; every?: 'day' };
      channelId: string;
    }> = [];
    let hasUpcomingTask = false;

    for (const task of tasks) {
      if (task.status === 'done' || task.status === 'done_early' || task.status === 'missed') continue;
      const end = new Date(task.endTime).getTime();
      if ((task.status === 'pending' || task.status === 'in_progress') && Number.isFinite(end) && end > now) {
        hasUpcomingTask = true;
      }
      const start = new Date(task.startTime).getTime();
      if (!Number.isFinite(start) || start <= now || start > horizon) continue;
      const isAlarm = task.isWakeUpAlarm || task.category === 'wake_up';
      notifications.push({
        id: hash(`${task.id}:start`),
        title: isAlarm ? 'صحّيني ⏰' : 'وقت المهمة',
        body: task.title,
        schedule: { at: new Date(start), allowWhileIdle: true },
        channelId: 'grip-tasks',
      });
      if (task.type === 'FIXED' && !isAlarm && start - 15 * 60000 > now) {
        notifications.push({
          id: hash(`${task.id}:pre`),
          title: 'بعد 15 دقيقة',
          body: task.title,
          schedule: { at: new Date(start - 15 * 60000), allowWhileIdle: true },
          channelId: 'grip-tasks',
        });
      }
    }

    // A single gentle daily nudge when the user has no upcoming tasks.
    if (!hasUpcomingTask) {
      const nextReminder = new Date();
      nextReminder.setHours(10, 0, 0, 0);
      if (nextReminder.getTime() <= now + 60000) nextReminder.setDate(nextReminder.getDate() + 1);
      notifications.push({
        id: hash('grip:no-upcoming-task'),
        title: 'Grip فاكر هدفك ✨',
        body: 'لسه ما سجلتش مهمة؟ اختار حاجة واحدة صغيرة وخلّي Grip يفكّرك بيها.',
        schedule: { at: nextReminder, repeats: true, every: 'day', allowWhileIdle: true },
        channelId: 'grip-tasks',
      });
    }

    notifications.sort((a, b) => a.schedule.at.getTime() - b.schedule.at.getTime());
    const limited = notifications.slice(0, 60);
    await LocalNotifications.createChannel({ id: 'grip-tasks', name: 'تنبيهات المهام', importance: 5, vibration: true });
    if (limited.length) await LocalNotifications.schedule({ notifications: limited });
  } catch {
    // Notification failures must not prevent task management from working.
  }
}
