/** Core focus-screen policy. Keep this behavior stable: it is a defining Grip feature. */
export const calculateRequiredHoldSeconds = (
  postponeCount: number,
  baseSeconds = 10,
  middleSeconds = 20,
  maximumSeconds = 30,
): number => {
  const count = Number.isFinite(postponeCount) ? Math.max(0, Math.floor(postponeCount)) : 0;
  if (count < 3) return baseSeconds;
  if (count < 6) return middleSeconds;
  return maximumSeconds;
};

/** Early completion is only valid at least five full minutes before scheduled end. */
export const canMarkTaskDoneEarly = (endTime: string | number | Date, now = Date.now()): boolean => {
  const endMs = endTime instanceof Date ? endTime.getTime() : typeof endTime === 'number' ? endTime : new Date(endTime).getTime();
  return Number.isFinite(endMs) && endMs - now >= 5 * 60 * 1000;
};
