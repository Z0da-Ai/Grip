/**
 * Grip plan design: product policy only, not a billing or entitlement enforcement layer.
 * Do not gate features using this file alone. Subscription status must be verified by a
 * trusted backend / store receipt before paid entitlements are granted.
 */
export type GripPlanId = 'free' | 'plus' | 'pro';

export interface GripPlanDefinition {
  id: GripPlanId;
  name: string;
  /** Hypothesis for pricing research; not a live price. */
  proposedPrice: { currency: 'USD' | 'EGP'; monthly: number; annual?: number } | null;
  localCoreFeatures: 'core';
  cloudAiActionsPerMonth: number | 'high-limit';
  advancedFileAnalysis: boolean;
  extendedAssistantMemory: boolean;
  priorityProcessing: boolean;
}

/** Initial commercial hypotheses. Validate willingness-to-pay and inference cost before launch. */
export const GRIP_PLANS: Record<GripPlanId, GripPlanDefinition> = {
  free: {
    id: 'free',
    name: 'Grip Free',
    proposedPrice: null,
    localCoreFeatures: 'core',
    cloudAiActionsPerMonth: 20,
    advancedFileAnalysis: false,
    extendedAssistantMemory: false,
    priorityProcessing: false,
  },
  plus: {
    id: 'plus',
    name: 'Grip Plus',
    proposedPrice: { currency: 'USD', monthly: 5.99, annual: 49.99 },
    localCoreFeatures: 'core',
    cloudAiActionsPerMonth: 500,
    advancedFileAnalysis: true,
    extendedAssistantMemory: true,
    priorityProcessing: false,
  },
  pro: {
    id: 'pro',
    name: 'Grip Pro',
    proposedPrice: { currency: 'USD', monthly: 9.99, annual: 79.99 },
    localCoreFeatures: 'core',
    cloudAiActionsPerMonth: 'high-limit',
    advancedFileAnalysis: true,
    extendedAssistantMemory: true,
    priorityProcessing: true,
  },
};

/** Keep these tasks available without a subscription. */
export const GRIP_FREE_CORE_FEATURES = [
  'local task and schedule management',
  'local reminders and focus sessions',
  'local expense logging and arithmetic',
  'local data access and export',
] as const;
