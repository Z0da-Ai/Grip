import test from 'node:test';
import assert from 'node:assert/strict';
import { autoRescheduleFlexibleTask } from '../src/services/rescheduleEngine';
import type { GripTask } from '../src/types/grip';

const localIso = (day: number, hour: number, minute = 0) => new Date(2026, 9, day, hour, minute, 0, 0).toISOString();

function task(overrides: Partial<GripTask> = {}): GripTask {
  return {
    id: 'flex-1', title: 'Study', category: 'study',
    startTime: localIso(26, 10), endTime: localIso(26, 11),
    type: 'FLEXIBLE', status: 'pending', postponeCount: 0, ...overrides,
  };
}

test('reschedules within the daytime window and does not cross 22:00', () => {
  const original = task();
  const result = autoRescheduleFlexibleTask(original, [original], new Date(2026, 9, 26, 21, 30, 0, 0));
  assert.equal(new Date(result.startTime).getHours(), 8);
  assert.equal(new Date(result.startTime).getDate(), 27);
  assert.equal(new Date(result.endTime).getHours(), 9);
});

test('jumps to a conflicting task end without skipping a valid quarter-hour slot', () => {
  const original = task({ startTime: localIso(26, 10), endTime: localIso(26, 10, 30) });
  const busy = task({ id: 'busy', type: 'FIXED', startTime: localIso(26, 8, 30), endTime: localIso(26, 9, 15) });
  const result = autoRescheduleFlexibleTask(original, [original, busy], new Date(2026, 9, 26, 8, 30, 0, 0));
  assert.equal(result.startTime, localIso(26, 9, 15));
  assert.equal(result.endTime, localIso(26, 9, 45));
});

test('does not overlap any scheduled task', () => {
  const original = task({ startTime: localIso(26, 8), endTime: localIso(26, 9) });
  const busy = task({ id: 'busy', type: 'FIXED', startTime: localIso(26, 8), endTime: localIso(26, 10) });
  const result = autoRescheduleFlexibleTask(original, [original, busy], new Date(2026, 9, 26, 8, 0, 0, 0));
  assert.ok(new Date(result.startTime).getTime() >= new Date(busy.endTime).getTime());
});

test('leaves invalid task timestamps unchanged', () => {
  const original = task({ startTime: 'not-a-date' });
  assert.equal(autoRescheduleFlexibleTask(original, [original], new Date(2026, 9, 26, 8, 0, 0, 0)), original);
});

test('does not reschedule a fixed task', () => {
  const original = task({ type: 'FIXED' });
  assert.equal(autoRescheduleFlexibleTask(original, [original], new Date(2026, 9, 26, 8, 0, 0, 0)), original);
});
