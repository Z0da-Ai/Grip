import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRequiredHoldSeconds, canMarkTaskDoneEarly } from '../src/services/enforcementPolicy';

test('focus hold escalates after the first three postpones, then after six', () => {
  assert.deepEqual([0, 1, 2].map((n) => calculateRequiredHoldSeconds(n)), [10, 10, 10]);
  assert.deepEqual([3, 4, 5].map((n) => calculateRequiredHoldSeconds(n)), [20, 20, 20]);
  assert.deepEqual([6, 7, 20, 1000].map((n) => calculateRequiredHoldSeconds(n)), [30, 30, 30, 30]);
});

test('early completion requires five full minutes remaining', () => {
  const now = Date.parse('2026-10-27T12:00:00.000Z');
  assert.equal(canMarkTaskDoneEarly('2026-10-27T12:05:00.000Z', now), true);
  assert.equal(canMarkTaskDoneEarly('2026-10-27T12:04:59.999Z', now), false);
  assert.equal(canMarkTaskDoneEarly('invalid', now), false);
});
