import test from 'node:test';
import assert from 'node:assert/strict';
import { findFreeSlot } from '../src/services/planner';
import type { GripTask } from '../src/types/grip';

const localIso = (day: number, hour: number, minute = 0) => new Date(2026, 9, day, hour, minute, 0, 0).toISOString();

function task(overrides: Partial<GripTask> = {}): GripTask {
  return {
    id: 'busy-1', title: 'Lecture', category: 'study',
    startTime: localIso(26, 8), endTime: localIso(26, 9),
    type: 'FIXED', status: 'pending', postponeCount: 0, ...overrides,
  };
}

test('rejects invalid or non-positive requested durations', () => {
  const day = new Date(2026, 9, 26, 0, 0, 0, 0);
  assert.equal(findFreeSlot([], day, 0, undefined, day), null);
  assert.equal(findFreeSlot([], day, -30, undefined, day), null);
  assert.equal(findFreeSlot([], day, Number.NaN, undefined, day), null);
});

test('finds a free slot after an existing event with the configured buffer', () => {
  const day = new Date(2026, 9, 26, 0, 0, 0, 0);
  const result = findFreeSlot([task()], day, 30, undefined, new Date(2026, 9, 25, 0, 0, 0, 0));
  assert.ok(result);
  assert.equal(result.start.getHours(), 9);
  assert.equal(result.start.getMinutes(), 15);
  assert.equal(result.end.getHours(), 9);
  assert.equal(result.end.getMinutes(), 45);
});
